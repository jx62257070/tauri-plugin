const __WHF_PLUGIN_RUNTIME__ = globalThis.__WHF_PLUGIN_RUNTIME__;
if (!__WHF_PLUGIN_RUNTIME__?.vue) {
  throw new Error('宿主运行时桥不可用：__WHF_PLUGIN_RUNTIME__（插件必须在该版本宿主里安装）');
}
const { Fragment, computed, createBlock, createCommentVNode, createElementBlock, createElementVNode, createTextVNode, defineComponent, normalizeClass, openBlock, ref, renderList, resolveDynamicComponent, toDisplayString, unref, withCtx } = __WHF_PLUGIN_RUNTIME__.vue;
//#region plugins/dsh-mainline/constants.ts
/**
* 插件 dsh-mainline（股票主线）· 全部常量
*
* 口径参考本地技能 `a-share-huddle-mainline`（A 股板块抱团主线四阶段判定）：
* 把「抱团主线」从主观感觉变成可复现的状态规则 —— 数据源换成**应用内可直连的接口**：
* - 板块清单与板块日 K（含成交额）：**同花顺为主源**（`q.10jqka.com.cn` / `d.10jqka.com.cn`，GBK 编码）；
* - 兜底源：**东方财富**（`push2his` 板块日 K + `push2delay` 板块快照）——
*   实测（2026-09-18）东财行情域可用但是**突发限速**（间隔 ≥1s 正常、连发即拒连），
*   故只作「同花顺整体不可用」时的整表降级，见 `MAINLINE_SOURCE` 与 L2.5 说明；
* - 沪深两市总成交额：复用宿主既有 `fetchMarketTurnover`（腾讯日 K，含真实成交额，与板块源无关）。
*/
/** 插件 id */
var MAINLINE_PLUGIN_ID = "dsh-mainline";
/** 左侧导航路径（菜单贡献点带 component 时自动注册该路由） */
var MAINLINE_MENU_PATH = "/mainline";
/** 左侧导航标题 */
var MAINLINE_MENU_TITLE = "股票主线";
/** 菜单图标（MenuIcon 的 key） */
var MAINLINE_MENU_ICON = "flame";
/** 同花顺行业板块清单页（GBK HTML，链接里带 `detail/code/881121/` 形式的板块代码） */
var THS_BOARD_LIST_URL = "https://q.10jqka.com.cn/thshy/";
/**
* 清单页分页地址基址（ajax 形态，只返回表格行）
*
* 实测：首页表格每页只给 **50 行**（90 个行业板块要两页），第 2 页返回剩余 40 行，
* 两页并集与首页页脚导航里的 90 个代码**完全一致**（探针 `.ai/tmp/mainline-probe9.mjs`）。
*/
var THS_BOARD_LIST_PAGE_URL_BASE = "https://q.10jqka.com.cn/thshy/index/field/199112/order/desc/page/";
/** 分页地址尾段（`<page>` 与 `/ajax/1/` 之间插页码） */
var THS_BOARD_LIST_PAGE_URL_SUFFIX = "/ajax/1/";
/**
* 同花顺板块日 K 基址（年文件）
*
* 完整形态 `${base}${boardCode}/01/${year}.js`，如
* `https://d.10jqka.com.cn/v6/line/48_881121/01/2026.js`；
* 返回 JSONP `quotebridge_v6_line_48_881121_01_2026({"data":"日期,开,高,低,收,量,额,...;..."})`
*/
var THS_BOARD_KLINE_URL_BASE = "https://d.10jqka.com.cn/v6/line/48_";
/**
* 同花顺板块日 K 的「近端文件」段名（`…/<复权>/last.js`）
*
* 实测（2026-09-18）该文件是**同源同口径**的第二份数据：约 140 个交易日（≈半年）、
* 字段序与年 K 完全一致（`日期,开,高,低,收,量,额`），且与年 K 的重叠日期**数值逐日相同**
* （对比 881121：140 天重叠、0 天不一致）→ 可直接与年 K 序列按日期合并。
*
* 关键价值：502 是**按文件**发生的（年文件由冷缓存节点生成），实测 5 个「年文件 502」的板块
* 其 `01/last.js` 全部 200 → 把它放进回退链能救回绝大部分整板失败，且不引入跨源口径差。
*/
var THS_BOARD_KLINE_FILE_LAST = "last";
/** 同花顺要求带 Referer，否则可能被拒 */
var THS_REFERER = "https://q.10jqka.com.cn/";
/**
* 板块数据源取值
*
* 一次扫描**整表只有一个来源（绝不混排）**：同花顺优先，只在「同花顺整体不可用」时
* 整表切东财。两个来源的日线序列在库里**分开存放**（行键带来源），同花顺恢复后自动切回，
* 切换期间的东财数据不会污染同花顺累积的分位序列。
*/
var MAINLINE_SOURCE = {
	/** 同花顺行业板块（主源：清单页 + 板块年 K / 近端 K） */
	THS: "ths",
	/** 东方财富行业板块（兜底源：板块日 K + 板块快照，按名称映射到同花顺板块） */
	EM: "em"
};
/** 数据源中文名（界面徽标用） */
var MAINLINE_SOURCE_LABEL = {
	ths: "同花顺",
	em: "东方财富"
};
/** 数据源徽标样式（兜底源用主色提示「口径已变」，让用户一眼看见） */
var MAINLINE_SOURCE_BADGE_CLASS = {
	ths: "bg-flat-weak text-text-secondary",
	em: "bg-primary-weak text-primary"
};
/**
* 板块清单（代码 + 名称）的来源
*
* 清单页 `q.10jqka.com.cn` 与日线主机 `d.10jqka.com.cn` 是两个域，可能单独故障 ——
* 清单页挂掉但日线正常时，用缓存清单继续取**同花顺**日线（仍是同源同口径，不切源），
* 只是当日结构快照（宽度 / 净流入）取不到；连缓存都没有才用内置兜底清单。
*/
var MAINLINE_REFS_SOURCE = {
	/** 清单页现取（正常路径） */
	LIVE: "live",
	/** 上次成功扫描时落库的清单（清单页故障时的首选） */
	CACHE: "cache",
	/** 内置兜底清单（`MAINLINE_THS_BOARD_FALLBACK`，首次扫描就撞上清单页故障时用） */
	STATIC: "static",
	/** 东财自带板块清单（东财模式下不再依赖同花顺清单） */
	EM: "em"
};
/** 板块清单来源中文名 */
var MAINLINE_REFS_SOURCE_LABEL = {
	live: "清单页现取",
	cache: "本地缓存清单",
	static: "内置兜底清单",
	em: "东财板块清单"
};
/** 触发整表切换数据源的原因（落库为键，界面按此取文案） */
var MAINLINE_FALLBACK_REASON = { 
/** 同花顺全部板块日线取数失败 → 判定同花顺整体不可用 */
KLINE_ALL_FAILED: "kline_all_failed" };
/**
* 切换原因文案
*
* 只保留**可复现的判定依据**（不写「可能 / 大概」）：整表切换的唯一触发条件是
* 同花顺清单解析出的**全部**板块日线都取不到 —— 单板块失败仍走同源回退链与本地旧数据。
*/
var MAINLINE_FALLBACK_REASON_LABEL = { kline_all_failed: "同花顺全部板块日线取数失败，判定为同花顺整体不可用" };
/** 东财要求带 Referer，否则可能被拒 */
var EM_REFERER = "https://quote.eastmoney.com/";
/** 东财行业板块清单（一次给出涨跌幅 / 成交额 / 主力净流入 / 涨跌家数 / 领涨股） */
var EM_BOARD_LIST_URL = "https://push2delay.eastmoney.com/api/qt/clist/get";
/** 东财板块日 K */
var EM_BOARD_KLINE_URL = "https://push2his.eastmoney.com/api/qt/stock/kline/get";
/**
* 东财行业板块清单的查询串（`{page}` 由调用方替换）
*
* `fs=m:90+t:2` = 行业板块（含一/二/三级混合，实测共 496 个）——
* 我们**不用它当板块全集**，只用它做「同花顺板块名 → 东财板块代码」的映射表。
*/
var EM_BOARD_LIST_QUERY = `pn={page}&pz=100&po=0&np=1&fltt=2&invt=2&fid=f12&fs=m:90+t:2&fields=f12,f14,f3,f6,f62,f104,f105,f128`;
/** 清单查询串里页码的占位符（由取数层替换为实际页码） */
var EM_BOARD_LIST_PAGE_TOKEN = "{page}";
/** 东财日 K 的元信息字段（f1 代码 / f2 名称 / f3 市场，必填但不用其值） */
var EM_KLINE_META_FIELDS = "f1,f2,f3";
/** 清单行里各字段的键（避免在解析层写裸字符串） */
var EM_BOARD_FIELD = {
	CODE: "f12",
	NAME: "f14",
	CHANGE_PERCENT: "f3",
	AMOUNT: "f6",
	NET_INFLOW: "f62",
	RISE: "f104",
	FALL: "f105",
	LEADER: "f128"
};
/** 日 K 要取的字段（f51~f57 = 日期 / 开 / 收 / 高 / 低 / 量 / 额；实测返回顺序即此） */
var EM_KLINE_FIELDS = "f51,f52,f53,f54,f55,f56,f57";
/** 日 K 结束日期（给足够大的值即取到最新） */
var EM_KLINE_END = "20500101";
/** 东财兜底模式的同上游间隔（毫秒）
*
* 实测（2026-09-18）：东财行情域是**突发限速** —— 间隔 ≥1s 时板块日 K 与板块快照都正常返回，
* 短时间连发立刻拒连（curl 退出码 000）、停顿约 20s 后恢复。故兜底轮必须**串行**且留足间隔。
*/
var EM_SCAN_DELAY_MS = 1200;
/** 东财兜底的失败补采间隔（毫秒；比同花顺更长，给限速留恢复时间） */
var EM_SCAN_RETRY_DELAY_MS = 5e3;
/**
* 东财涨停池的行业名 → 同花顺行业板块名（**近似归属**）
*
* 涨停池的 `hybk` 用的是东财（≈申万）行业口径，与同花顺行业板块**不是同一套分类**，
* 且长名会被上游截断到 4 个汉字（`光学光电子` → `光学光电`，由前缀匹配自动兜住）。
* 下表是**分类口径不同、名称也不同**时的兜底映射，只收录语义等价、可确认的对应关系：
*
* - 截断名（光学光电 / 汽车零部 / 计算机设 …）由前缀匹配处理，不在此表；
* - 两套分类下**无法确认**对应板块的（`文娱用品`、`照明设备`）**故意不收录** ——
*   宁可让它们落进「未归属」计数并在界面如实展示，也不猜一个板块出去；
* - 上游分类调整时本表会漂移，故 `scan_meta` 会记录未归属家数，便于发现漂移。
*/
var MAINLINE_INDUSTRY_ALIAS = {
	"工程咨询": "建筑装饰",
	"专业工程": "建筑装饰",
	"装修装饰": "建筑装饰",
	"装修建材": "建筑材料",
	"出版": "文化传媒",
	"广告营销": "文化传媒",
	"一般零售": "零售",
	"炼化及贸": "石油加工贸易",
	"旅游及景": "旅游及酒店",
	"非白酒": "饮料制造",
	"铁路公路": "公路铁路运输",
	"冶钢原料": "钢铁",
	"商用车": "汽车整车",
	"焦炭Ⅱ": "煤炭开采加工",
	"玻璃玻纤": "建筑材料",
	"航运港口": "港口航运"
};
/**
* 同花顺板块名 → 东财板块名（**兜底模式的名称映射表**）
*
* 兜底模式下东财是唯一的板块数据源，所以要把同花顺的 90 个板块名对应到东财板块。
* 自动匹配只做**同层级语义等价**的两级：等值 → 剥罗马数字后缀（优先「Ⅱ」级，
* 因为同花顺 90 板块≈申万二级）。下表是语义等价但**名称不同**的 12 个：
*
* - 词序颠倒：`公路铁路运输` ↔ `铁路公路`、`港口航运` ↔ `航运港口`、`机场航运` ↔ `航空机场`
* - 申万改名 / 纯后缀差：`煤炭开采加工` → `煤炭开采`、`石油加工贸易` → `炼化及贸易`、
*   `油气开采及服务` → `油气开采`、`汽车服务及其他` → `汽车服务`、`文化传媒` → `传媒`、
*   `塑料制品` → `塑料`、`橡胶制品` → `橡胶`、`食品加工制造` → `食品加工`、
*   `种植业与林业` → `种植业`
*
* **故意不收录**的 7 个（宁可让它们落进「未映射」并在页头如实列出，也不硬凑）：
* - `汽车整车`：东财只有一级 `汽车`（含零部件/服务），而零部件已单独映射到 `汽车零部件`
*   → 硬映射会把零部件重复计入整车；
* - `零售`（东财拆成一般零售 / 商贸零售 / 多业态零售）、`旅游及酒店`（拆成旅游及景区 + 酒店餐饮）、
*   `军工装备`（拆成航天/航空/航海/地面兵装）、`其他社会服务`（东财「社会服务」是一级，还含教育/旅游）
*   —— 同花顺做过合并，东财没有一一对应的板块；
* - `化学纤维`（东财只剩三级 `其他化学纤维`）、`饮料制造`（东财为 `饮料乳品`，多出乳品）
*   —— 成分范围不同，映射会给出偏小/偏大的成交额。
*/
var MAINLINE_THS_TO_EM_ALIAS = {
	"公路铁路运输": "铁路公路",
	"港口航运": "航运港口",
	"机场航运": "航空机场",
	"煤炭开采加工": "煤炭开采",
	"石油加工贸易": "炼化及贸易",
	"油气开采及服务": "油气开采",
	"汽车服务及其他": "汽车服务",
	"文化传媒": "传媒",
	"塑料制品": "塑料",
	"橡胶制品": "橡胶",
	"食品加工制造": "食品加工",
	"种植业与林业": "种植业"
};
/**
* 内置兜底板块清单（同花顺 90 个行业板块的快照，2026-09-18 取自清单页）
*
* 只在「清单页故障 **且** 本地没有缓存清单」时使用（首次扫描就撞上故障）。
* 板块代码与名称极少变动；若上游调整分类，靠页头「清单来源：内置兜底清单」提示，
* 并且下一次清单页正常时缓存会被现取清单覆盖。
*/
var MAINLINE_THS_BOARD_FALLBACK = [
	{
		code: "881101",
		name: "种植业与林业"
	},
	{
		code: "881102",
		name: "养殖业"
	},
	{
		code: "881103",
		name: "农产品加工"
	},
	{
		code: "881105",
		name: "煤炭开采加工"
	},
	{
		code: "881107",
		name: "油气开采及服务"
	},
	{
		code: "881108",
		name: "化学原料"
	},
	{
		code: "881109",
		name: "化学制品"
	},
	{
		code: "881112",
		name: "钢铁"
	},
	{
		code: "881114",
		name: "金属新材料"
	},
	{
		code: "881115",
		name: "建筑材料"
	},
	{
		code: "881116",
		name: "建筑装饰"
	},
	{
		code: "881117",
		name: "通用设备"
	},
	{
		code: "881118",
		name: "专用设备"
	},
	{
		code: "881121",
		name: "半导体"
	},
	{
		code: "881122",
		name: "光学光电子"
	},
	{
		code: "881123",
		name: "其他电子"
	},
	{
		code: "881124",
		name: "消费电子"
	},
	{
		code: "881125",
		name: "汽车整车"
	},
	{
		code: "881126",
		name: "汽车零部件"
	},
	{
		code: "881128",
		name: "汽车服务及其他"
	},
	{
		code: "881129",
		name: "通信设备"
	},
	{
		code: "881130",
		name: "计算机设备"
	},
	{
		code: "881131",
		name: "白色家电"
	},
	{
		code: "881132",
		name: "黑色家电"
	},
	{
		code: "881133",
		name: "饮料制造"
	},
	{
		code: "881134",
		name: "食品加工制造"
	},
	{
		code: "881135",
		name: "纺织制造"
	},
	{
		code: "881136",
		name: "服装家纺"
	},
	{
		code: "881137",
		name: "造纸"
	},
	{
		code: "881138",
		name: "包装印刷"
	},
	{
		code: "881139",
		name: "家居用品"
	},
	{
		code: "881140",
		name: "化学制药"
	},
	{
		code: "881141",
		name: "中药"
	},
	{
		code: "881142",
		name: "生物制品"
	},
	{
		code: "881143",
		name: "医药商业"
	},
	{
		code: "881144",
		name: "医疗器械"
	},
	{
		code: "881145",
		name: "电力"
	},
	{
		code: "881146",
		name: "燃气"
	},
	{
		code: "881148",
		name: "港口航运"
	},
	{
		code: "881149",
		name: "公路铁路运输"
	},
	{
		code: "881151",
		name: "机场航运"
	},
	{
		code: "881152",
		name: "物流"
	},
	{
		code: "881153",
		name: "房地产"
	},
	{
		code: "881155",
		name: "银行"
	},
	{
		code: "881156",
		name: "保险"
	},
	{
		code: "881157",
		name: "证券"
	},
	{
		code: "881158",
		name: "零售"
	},
	{
		code: "881159",
		name: "贸易"
	},
	{
		code: "881160",
		name: "旅游及酒店"
	},
	{
		code: "881162",
		name: "通信服务"
	},
	{
		code: "881164",
		name: "文化传媒"
	},
	{
		code: "881165",
		name: "综合"
	},
	{
		code: "881166",
		name: "军工装备"
	},
	{
		code: "881167",
		name: "非金属材料"
	},
	{
		code: "881168",
		name: "工业金属"
	},
	{
		code: "881169",
		name: "贵金属"
	},
	{
		code: "881170",
		name: "小金属"
	},
	{
		code: "881171",
		name: "自动化设备"
	},
	{
		code: "881172",
		name: "电子化学品"
	},
	{
		code: "881173",
		name: "小家电"
	},
	{
		code: "881174",
		name: "厨卫电器"
	},
	{
		code: "881175",
		name: "医疗服务"
	},
	{
		code: "881177",
		name: "互联网电商"
	},
	{
		code: "881178",
		name: "教育"
	},
	{
		code: "881179",
		name: "其他社会服务"
	},
	{
		code: "881180",
		name: "石油加工贸易"
	},
	{
		code: "881181",
		name: "环境治理"
	},
	{
		code: "881182",
		name: "美容护理"
	},
	{
		code: "881263",
		name: "农化制品"
	},
	{
		code: "881264",
		name: "化学纤维"
	},
	{
		code: "881265",
		name: "塑料制品"
	},
	{
		code: "881266",
		name: "橡胶制品"
	},
	{
		code: "881267",
		name: "能源金属"
	},
	{
		code: "881268",
		name: "工程机械"
	},
	{
		code: "881269",
		name: "轨交设备"
	},
	{
		code: "881270",
		name: "元件"
	},
	{
		code: "881271",
		name: "IT服务"
	},
	{
		code: "881272",
		name: "软件开发"
	},
	{
		code: "881273",
		name: "白酒"
	},
	{
		code: "881274",
		name: "影视院线"
	},
	{
		code: "881275",
		name: "游戏"
	},
	{
		code: "881276",
		name: "军工电子"
	},
	{
		code: "881277",
		name: "电机"
	},
	{
		code: "881278",
		name: "电网设备"
	},
	{
		code: "881279",
		name: "光伏设备"
	},
	{
		code: "881280",
		name: "风电设备"
	},
	{
		code: "881281",
		name: "电池"
	},
	{
		code: "881282",
		name: "其他电源设备"
	},
	{
		code: "881283",
		name: "多元金融"
	},
	{
		code: "881284",
		name: "环保设备"
	}
];
/**
* 扫描第二轮补采的间隔（毫秒）
*
* 502 网关错误呈「突发簇」分布（一轮扫描里集中出现），整轮跑完等一小段时间
* 再补采失败板块的自愈率显著更高；第二轮轮内同上游间隔也用该值（比首轮更稀疏）。
*/
var MAINLINE_SCAN_RETRY_DELAY_MS = 2e3;
/**
* 基准交易日的覆盖率门槛（0-1）
*
* 基准日 = 最近一个「有行情 bar 的板块数 ≥ 全清单 × 本比例」的交易日。
* 实测依据：完整交易日稳定在 88/90 ≈ 0.978；盘中只有 68/90 ≈ 0.756 且两市成交额只有半日值，
* 两者不可比（实测同一时点「板块合计 ÷ 两市」= 35.6%，而完整日为 98.5%），故必须整表按同一日截面计算。
*/
var MAINLINE_BENCHMARK_COVERAGE_RATIO = .85;
/** 元 → 亿元 的换算基数（展示用） */
var YUAN_PER_YI = 1e8;
/** 四阶段（+ 无 / 数据不足），取值与技能 JSON 的 `phase` 对齐 */
var MAINLINE_PHASE = {
	/** 萌芽：低位放量，潜在新抱团（多数会证伪，只做观察） */
	GERMINATION: "germination",
	/** 确认：抱团主线成型 */
	CONFIRMED: "confirmed_group",
	/** 狂热：筹码拥挤 + 成交占比历史极值，赔率恶化 */
	MANIA: "mania",
	/** 瓦解：高位放量下跌，景气/筹码松动 */
	COLLAPSE: "collapse",
	/** 未成主线：无明显抱团特征 */
	NONE: "none",
	/** 数据不足：历史样本不够，不下结论 */
	UNKNOWN: "insufficient_data"
};
/** 阶段中文标签 */
var MAINLINE_PHASE_LABEL = {
	germination: "萌芽",
	confirmed_group: "确认",
	mania: "狂热",
	collapse: "瓦解",
	none: "未成主线",
	insufficient_data: "数据不足"
};
/**
* 全部阶段取值（顺序 = 看板徽标的展示顺序，直接取标签表的键序）
*
* 单一事实源：新增阶段只往 `MAINLINE_PHASE_LABEL` 加一项即可，徽标与统计自动跟上。
*/
var MAINLINE_PHASE_LIST = Object.keys(MAINLINE_PHASE_LABEL);
/** 阶段徽标样式（宿主 token：涨红跌绿，狂热用主色提示风险） */
var MAINLINE_PHASE_BADGE_CLASS = {
	germination: "bg-flat-weak text-text-secondary",
	confirmed_group: "bg-up-weak text-up",
	mania: "bg-primary-weak text-primary",
	collapse: "bg-down-weak text-down",
	none: "bg-flat-weak/60 text-text-tertiary",
	insufficient_data: "bg-flat-weak/60 text-text-tertiary"
};
/** 阶段排序权重（越小越靠前，用于看板默认排序） */
var MAINLINE_PHASE_ORDER = {
	mania: 0,
	collapse: 1,
	confirmed_group: 2,
	germination: 3,
	none: 4,
	insufficient_data: 5
};
/** 阶段一句话说明（判定结论文案，只讲状态不讲买卖） */
var MAINLINE_PHASE_DESC = {
	germination: "萌芽期：成交占比自低位快速抬升，但拥挤度尚低。潜在新抱团，多数会证伪，仅作观察。",
	confirmed_group: "确认期：量能持续放大且价格创阶段新高，抱团主线成型。需连续两季业绩验证方能成立。",
	mania: "狂热期：筹码拥挤、成交占比处于历史极值区间，赔率恶化，瓦解风险抬升。",
	collapse: "瓦解期：高位放量下跌，筹码开始松动，容易超预期下跌。",
	none: "无明显抱团特征：成交占比与量能均未抬升。",
	insufficient_data: "历史样本不足，不下阶段结论 —— 缺样本不等于状态正常。"
};
/** 阶段风险提示（可为空数组；一律为状态语言，不含买卖指令） */
var MAINLINE_PHASE_WARNINGS = {
	germination: ["萌芽期多数最终证伪，不能作为入场依据，只做观察池跟踪。"],
	confirmed_group: ["确认期需连续两季业绩验证；本期未接入业绩/估值分位数据，判定置信度受限。"],
	mania: ["成交占比处于历史极值，拥挤度带来的赔率恶化需要正视。", "抱团末期常见「利好钝化」与波动放大，瓦解风险抬升。"],
	collapse: ["高位放量下跌常伴随超预期回撤，注意情绪与流动性的负反馈。"],
	none: [],
	insufficient_data: ["样本天数不足，请继续每日扫描以累积分位序列。"]
};
/** 页面标题 */
var MAINLINE_PAGE_TITLE = "股票主线";
/** 页面副标题（说明工具定位与硬约束） */
var MAINLINE_PAGE_SUBTITLE = "板块抱团主线阶段判定：成交占比分位 / 量能倍数 / 价格分位 → 萌芽·确认·狂热·瓦解。辅助研判工具，只输出阶段与风险提示，不含任何买卖或仓位指令。";
/** 扫描按钮文案 */
var MAINLINE_SCAN_BUTTON = "扫描主线";
/** 扫描中按钮文案前缀 */
var MAINLINE_SCAN_RUNNING = "扫描中";
/** 扫描进度文案模板（已请求数 / 总数） */
var MAINLINE_SCAN_PROGRESS_SUFFIX = "个板块";
/** 首次空态文案 */
var MAINLINE_EMPTY_TEXT = "还没有主线快照，点「扫描主线」拉取行业板块与成交额历史（板块数据优先同花顺，整体不可用时自动切东财兜底）";
/** 筛选后无匹配行的空态文案（与「还没扫描」区分开，别让用户以为数据丢了） */
var MAINLINE_FILTER_EMPTY_TEXT = "当前筛选条件下没有匹配的板块，换个阶段或清除筛选看看";
/** 清除筛选按钮文案 */
var MAINLINE_FILTER_CLEAR = "清除筛选";
/**
* 筛选生效时的行数提示模板
* @param shown 已筛出的行数
* @param total 全部结论行数
* @returns 提示文案
*/
var MAINLINE_FILTER_SUMMARY = (shown, total) => `筛选后 ${shown}/${total} 个板块`;
/**
* 阶段徽标的筛选提示（放在徽标行尾，告知可点）
*
* 阶段徽标本身就是筛选开关（多选，再点一次取消），这里只给一句轻提示。
*/
var MAINLINE_PHASE_FILTER_HINT = "点阶段徽标可多选筛选";
/** 无历史样本提示（表格内） */
var MAINLINE_NO_SAMPLE_TEXT = "无样本";
/** 扫描失败文案前缀 */
var MAINLINE_SCAN_FAILED = "扫描失败";
/** 表格列标题 */
var MAINLINE_COLUMN_LABEL = {
	name: "板块",
	phase: "阶段",
	change: "当日",
	change5: "近5日",
	share: "成交占比",
	sharePercentile: "占比分位",
	amountRatio: "量能倍数",
	pricePercentile: "价格分位",
	limitUp: "涨停",
	breadth: "宽度",
	netInflow: "净流入"
};
/** 明细区小标题 */
var MAINLINE_DETAIL_TITLE = "指标明细";
/** 明细区字段标签 */
var MAINLINE_DETAIL_LABEL = {
	asOf: "数据截止",
	benchmark: "基准交易日",
	source: "数据源",
	historyDays: "历史样本",
	latestChange: "当日涨跌",
	change5: "近 5 日累计",
	change20: "近 20 日累计",
	amount: "当日成交额",
	turnoverShare: "当日成交占比",
	sharePercentile: "成交占比历史分位",
	amountRatio: "量能倍数（5日/前20日）",
	amountRatioOverlap: "量能倍数（旧口径 5日/20日）",
	pricePercentile: "价格分位（60 日）",
	limitUpCount: "涨停家数",
	maxStreak: "最高连板",
	sealFund: "封板资金合计",
	limitUpRatio: "涨停占比",
	riseFall: "上涨 / 下跌家数",
	breadth: "板块宽度",
	netInflow: "主力净流入",
	leader: "领涨股",
	confidence: "置信度"
};
/** 明细区单位与后缀 */
var MAINLINE_DETAIL_UNIT = {
	days: "个交易日",
	times: "×",
	houses: "家",
	boards: "板"
};
/** 缺失输入标题与说明（不静默：缺什么明说） */
var MAINLINE_MISSING_TITLE = "本期未接入的输入";
/** 缺失输入条目（数据现实：这些指标免费源拿不到或本期未实现） */
var MAINLINE_MISSING_INPUTS = [
	"公募基金板块持仓分位（免费源无干净接口，需按报告期自建季度序列）",
	"板块 PE/PB 估值分位（东财板块快照 PE 实测返回空、PB 仅有当日值，需每日累积快照后给分位）",
	"龙头连续两季业绩验证（东财 datacenter 可按行业取，本期未接入）",
	"北向持股环比方向（实测最新披露日为 2026-06-30，属季度频率，日频环比不可得）"
];
/** 已接入输入清单（与「未接入」对照展示，避免用户以为结构指标也没接） */
var MAINLINE_CONNECTED_TITLE = "本期已接入的输入";
/** 已接入输入条目 */
var MAINLINE_CONNECTED_INPUTS = [
	"成交占比历史分位（同花顺行业板块成交额 ÷ 沪深两市总成交额，按基准日截面）",
	"量能倍数（近 5 日均额 ÷ 前 20 日均额，已改滞后口径；界面同时给出旧口径对照）",
	"价格分位（收盘价在近 60 日区间中的分位）",
	"板块内涨停家数 / 最高连板 / 封板资金合计（东财涨停池按行业归属聚合）",
	"板块宽度（上涨 ÷ 上涨+下跌）与主力净流入（同花顺行业清单页快照）",
	"数据源兜底：同花顺清单页/日线可用时一律走同花顺；确认同花顺整体不可用（全部板块日线均失败）时整表降级东财，来源与切换原因在页头明示，两个来源的序列分开存放、不拼接"
];
/** 置信度文案 */
var MAINLINE_CONFIDENCE_LABEL = {
	high: "高（样本充足）",
	medium: "中（样本一般）",
	low: "低（样本不足）"
};
/**
* 免责声明
*
* 三条实测口径必须写明，否则用户会把「12.58%」直接读成全市场占比：
* 板块合计 ≈ 全市场 98.5%（实测 9/15~9/17 为 0.984~0.986，缺口为取数失败板块与口径差）；
* 指标一律取**最近完整交易日**截面（盘中不落半日 bar）；结构指标来自榜单快照与涨停池。
*/
var MAINLINE_DISCLAIMER = "仅历史统计规则下的状态判定，是概率工具而非预言，不构成投资建议，不含任何买卖或仓位指令。成交占比口径为「行业板块成交额 ÷ 沪深两市总成交额」（同花顺口径下板块合计约为全市场成交额的 98.5%，实测 9/15~9/17 为 98.4%~98.6%，故存在约 1.5% 的系统性低估；但分位是同一基准下的相对位置、不受该缺口影响）。全部指标一律取「最近完整交易日」截面：盘中扫描不写入当日半日数据，避免污染占比分位序列。板块日线默认取同花顺；仅在确认同花顺整体不可用时整表降级东财（页头标注来源与切换原因，两个来源的序列分开存放、不拼接）。涨停家数、连板高度、封板资金来自东财涨停池（按行业归属聚合，未归属家数在页头如实列出）；上涨/下跌家数、净流入来自板块清单页快照（同花顺口径为净流入，东财口径为主力净流入，两者不可直接比较）。";
/** 风险提示区标题 */
var MAINLINE_WARNING_TITLE = "风险提示";
/** 主线候选徽标文案 */
var MAINLINE_CANDIDATE_BADGE = "主线候选";
/**
* 数据滞后徽标文案模板
* @param days 滞后交易日数
* @returns 徽标文案
*/
var MAINLINE_STALE_BADGE = (days) => `滞后${days}日`;
/** 基准日完全没有行情 bar 时的徽标文案（滞后天数为 0 但确实不在基准日截面上） */
var MAINLINE_STALE_NO_BAR_BADGE = "无基准日行情";
/** 兜底模式下「东财无同义板块」徽标文案（映射不上 → 空序列） */
var MAINLINE_EM_UNMAPPED_BADGE = "东财无同义板块";
/** 情绪加速徽标文案 */
var MAINLINE_STRUCTURE_HOT_BADGE = "情绪加速";
/**
* 表格行 key
*
* 同一板块在「同花顺」与「东财」两个来源下是**两条不同的序列**（分开存放、绝不拼接），
* 所以行 key 必须带来源，否则切换来源时表格会复用同一行、把两套口径混起来看。
* @param source 数据源
* @param code 板块代码
* @returns 行 key
*/
var mainlineRowKey = (source, code) => `${source}-${code}`;
/** 页头字段标签 */
var MAINLINE_HEADER_LABEL = {
	benchmark: "基准交易日",
	coverage: "覆盖板块",
	boardCount: "板块总数",
	marketAmount: "两市成交额",
	scannedAt: "上次扫描",
	limitUp: "基准日涨停",
	structure: "结构指标",
	source: "数据源",
	refsSource: "板块清单"
};
/**
* 基准日覆盖率文案模板（如「88 / 90 个板块」）
* @param coverage 基准日有行情的板块数
* @param total 板块总数
* @returns 文案
*/
var MAINLINE_COVERAGE_TEXT = (coverage, total) => `${coverage} / ${total} 个板块`;
/**
* 结构指标采集说明模板（涨停家数 + 未归属家数）
* @param total 基准日全市场涨停家数
* @param unmapped 未能归属到板块的涨停家数
* @returns 文案
*/
var MAINLINE_LIMIT_UP_TEXT = (total, unmapped) => unmapped > 0 ? `全市场 ${total} 家（未归属板块 ${unmapped} 家）` : `全市场 ${total} 家`;
/** 结构指标未采集文案 */
var MAINLINE_STRUCTURE_UNAVAILABLE = "未采集（本次取数失败）";
/**
* 盘中未落定提示模板（说明当日 bar 为何没写入）
* @param date 被排除的日期
* @param benchmark 实际采用的基准交易日
* @returns 文案
*/
var MAINLINE_INTRADAY_NOTICE = (date, benchmark) => `${date} 当日数据尚未落定（盘中为半日值），本次未写入当日行情；全部指标按最近完整交易日 ${benchmark} 计算。`;
/**
* 基准日覆盖率不足提示模板（连完整交易日都凑不齐覆盖率时的降级说明）
* @param benchmark 实际采用的基准交易日
* @returns 文案
*/
var MAINLINE_DEGRADED_NOTICE = (benchmark) => `未找到覆盖率达标的交易日，已退回覆盖最全的 ${benchmark}；该日部分板块行情缺失，横截面比较需谨慎。`;
/**
* 整表切换数据源的提示模板
*
* 必须同时给出「为什么切」「上游报了什么错」「口径差在哪」—— 否则用户会把东财口径的
* 12.58% 直接和昨天的同花顺口径比，而两套板块指数不同源，点位与成分都不保证一致。
* @param reason 切换原因（来自 `MAINLINE_FALLBACK_REASON_LABEL`）
* @param error 上游原始报错（可为空串）
* @returns 提示文案
*/
var MAINLINE_FALLBACK_NOTICE = (reason, error) => `本次已整表切换为东方财富口径。原因：${reason}${error ? `（上游报错：${error}）` : ""}。东财板块指数与同花顺不同源：点位不可比、成分不保证一致，因此指标只保证「同一次扫描内横向自洽」，请勿与同花顺口径的历史数值直接比较。两个来源的日线在库里分开存放、绝不拼接；同花顺恢复后会自动切回，切换期间的东财数据也不会污染同花顺累积的分位序列。`;
/**
* 兜底模式的净流入口径提示（东财 `f62` 是主力净流入，与同花顺清单页口径不同）
*/
var MAINLINE_EM_CALIBER_NOTICE = "兜底模式下「净流入」为东财主力净流入（大单口径），与同花顺清单页的净流入不可直接比较；涨停家数 / 连板高度 / 封板资金仍来自东财涨停池，与同花顺模式下一致。";
/**
* 兜底模式未映射板块提示模板（东财没有同义板块的同花顺板块，如实列出、不猜）
* @param names 未映射的同花顺板块名
* @returns 提示文案
*/
var MAINLINE_EM_UNMAPPED_TEXT = (names) => `有 ${names.length} 个同花顺板块在东财找不到同义板块（两套分类口径不同），本次按「无数据」处理而非猜测映射：${names.join("、")}。`;
/**
* 清单页故障但日线仍可用的提示模板（不切源，只是拿不到当日结构快照）
* @param error 清单页原始报错
* @param refsLabel 实际使用的清单来源文案
* @returns 提示文案
*/
var MAINLINE_LIST_ONLY_NOTICE = (error, refsLabel) => `同花顺板块清单页取数失败（${error}），本次改用${refsLabel}继续取同花顺日线：数据口径未变，但当日结构指标（宽度 / 净流入）与涨停池行业归属本期未采集。`;
/** 兜底扫描耗时提示（东财必须串行 ≥1.1s，比同花顺慢得多） */
var MAINLINE_EM_SLOW_NOTICE = "东财兜底必须串行请求（同上游间隔 ≥1.1s），一次扫描约需 2 分钟，请勿重复点击「扫描主线」。";
/**
* 滞后板块的风险提示模板
* @param days 滞后交易日数
* @returns 提示文案
*/
var MAINLINE_WARNING_STALE = (days) => `该板块行情滞后基准日 ${days} 个交易日，指标非同一截面，本行不参与阶段判定（等取数恢复后自动回到正常判定）。`;
/** 结构指标缺失时的风险提示 */
var MAINLINE_WARNING_NO_STRUCTURE = "本期未采集到板块内涨停与宽度数据，结构门槛未参与本次判定。";
/**
* 确认期被结构门槛否决时的提示模板
* @param limitUpCount 板块内涨停家数
* @param breadth 板块宽度（%）
* @returns 提示文案
*/
var MAINLINE_WARNING_STRUCTURE_FAIL = (limitUpCount, breadth) => `量价与拥挤度特征具备，但板块内涨停 ${limitUpCount} 家、宽度 ${breadth.toFixed(1)}%，内部结构不支持抱团主线，故不判「确认」。`;
/**
* 情绪加速的风险提示模板
* @param maxStreak 板块内最高连板数
* @param limitUpRatio 涨停占比（%）
* @returns 提示文案
*/
var MAINLINE_WARNING_STRUCTURE_HOT = (maxStreak, limitUpRatio) => `板块内最高 ${maxStreak} 板、涨停占比 ${limitUpRatio.toFixed(1)}%，个股层面已进入情绪加速段，波动通常同步放大。`;
/**
* 确认期板块无涨停的提示模板
* @param breadth 板块宽度（%）
* @returns 提示文案
*/
var MAINLINE_WARNING_NO_LIMIT_UP = (breadth) => `板块内无涨停个股（宽度 ${breadth.toFixed(1)}%），确认期的个股参与度偏弱，需继续观察。`;
//#endregion
//#region plugins/dsh-mainline/filter.ts
/**
* 插件 dsh-mainline（股票主线）· 看板筛选（纯函数）
*
* 抽成纯函数是为了守住一条容易做砸的不变量：**徽标上的数字 = 点它之后表里的行数**。
* 界面把「阶段计数」和「阶段过滤」分开写时极易漂移（计数用了全量、过滤用了候选后的量，
* 或计数含阶段筛选而过滤不含），用户就会看到「显示 39、点进去 12」。
* 这里把两个动作放在同一份 `MainlineFilterOptions` 语义下，并由冒烟断言锁死。
*/
/**
* 按筛选条件过滤判定结论
*
* 「候选」与「阶段」是**与**关系（两个条件同时满足才留下）；
* 阶段本身是**多选**，多选之间是**或**（并集）—— 选了「狂热 + 确认」应同时看到两类。
* `phases` 为空数组表示不按阶段筛选（而不是「一个都不要」）。
* @param verdicts 全部判定结论
* @param options 筛选条件
* @returns 命中条件的判定结论（保持原顺序）
*/
var filterVerdicts = (verdicts, options) => verdicts.filter((verdict) => {
	if (options.candidateOnly && !verdict.candidate) return false;
	if (options.phases.length === 0) return true;
	return options.phases.includes(verdict.phase);
});
/**
* 按阶段统计板块数（未出现的阶段给 0，不留 `undefined` 让界面去兜）
* @param verdicts 判定结论
* @returns 每个阶段的板块数
*/
var countByPhase = (verdicts) => {
	const counts = Object.fromEntries(MAINLINE_PHASE_LIST.map((phase) => [phase, 0]));
	for (const verdict of verdicts) counts[verdict.phase] += 1;
	return counts;
};
/**
* 是否存在任一筛选条件（界面据此决定是否露出「清除筛选」与行数提示）
* @param options 筛选条件
* @returns 是否有筛选生效
*/
var isFilterActive = (options) => options.candidateOnly || options.phases.length > 0;
/**
* 切换某个阶段的选中态（多选；已选中则取消）
*
* 返回新数组而不是原地改，保证 Vue 的响应式依赖能正确触发。
* @param phases 当前选中的阶段
* @param phase 要切换的阶段
* @returns 新的选中阶段列表（保持「原有顺序 + 新项追加」）
*/
var togglePhase = (phases, phase) => phases.includes(phase) ? phases.filter((item) => item !== phase) : [...phases, phase];
//#endregion
//#region plugins/dsh-mainline/benchmark.ts
/**
* 插件 dsh-mainline（股票主线）· 数据完整性层（**纯函数**，可冒烟断言）
*
* 解决的问题（实测依据见 `.ai/开发方案/2026-09-18-股票主线指标优化与数据源评估.md`）：
* 1. **基准日不统一**：原先每个指标各取「自己序列的最后一天」，而板块年 K 的更新是异步的
*    （2026-09-10 仅 20/90 板块有当日 bar、09-18 盘中仅 68/90）→ 有的板块在算 09-17、
*    有的在算 09-16，asOf 取众数把差异掩盖掉了，横截面比较是错的。
* 2. **盘中半日 bar 污染历史**：盘中扫描时分子是「部分板块的半日/整日混合」、分母是半日全市场，
*    实测「板块合计 ÷ 两市」= 35.6%，而完整交易日稳定在 98.5%；半日 bar 一旦落库会覆盖同日，
*    收盘后不重扫就永久污染占比分位序列（且不会自愈）→ 未落定日的 bar 一律不写入。
*/
/**
* 本地日期字符串（YYYY-MM-DD，本地时区）
* @param date 时间
* @returns 本地日期串
*/
var toLocalDateString = (date) => {
	return `${date.getFullYear()}-${`${date.getMonth() + 1}`.padStart(2, "0")}-${`${date.getDate()}`.padStart(2, "0")}`;
};
/**
* 当日数据是否已落定（本地时间 ≥ 收盘 + 落定缓冲）
* @param now 当前时间
* @returns true 表示当日 bar 可信
*/
var isDataSettled = (now) => now.getHours() * 60 + now.getMinutes() >= 930;
/**
* 统计每个交易日「有行情 bar 的板块数」（同一板块同日重复计一次）
* @param boards 全部板块序列
* @returns 日期 → 板块数
*/
var buildCoverageMap = (boards) => {
	const coverage = /* @__PURE__ */ new Map();
	for (const series of boards) {
		const seen = /* @__PURE__ */ new Set();
		for (const day of series.days) {
			if (!day.date || seen.has(day.date)) continue;
			seen.add(day.date);
			coverage.set(day.date, (coverage.get(day.date) ?? 0) + 1);
		}
	}
	return coverage;
};
/**
* 解析全板块统一的基准交易日
*
* 取「最近一个（排除未落定日）有行情板块数 ≥ 板块总数 × 覆盖率门槛」的交易日；
* 都不达标时退回覆盖最全的一天并把 `degraded` 置真（界面据此提示，不静默当正常用）。
* @param boards 全部板块序列
* @param market 沪深成交额序列（提供交易日日历）
* @param now 当前时间（用于判定当日是否已落定）
* @returns 基准日解析结果
*/
var resolveBenchmark = (boards, market, now) => {
	const total = boards.length;
	const coverage = buildCoverageMap(boards);
	const marketDates = market.map((point) => point.date).filter((date) => date.length > 0).sort();
	const today = toLocalDateString(now);
	const excludedDate = marketDates.includes(today) && !isDataSettled(now) ? today : "";
	const threshold = Math.ceil(total * MAINLINE_BENCHMARK_COVERAGE_RATIO);
	let best = "";
	let bestCoverage = 0;
	for (let index = marketDates.length - 1; index >= 0; index -= 1) {
		const date = marketDates[index];
		if (date === excludedDate) continue;
		const count = coverage.get(date) ?? 0;
		if (count > bestCoverage) {
			best = date;
			bestCoverage = count;
		}
		if (count >= threshold) return {
			date,
			coverage: count,
			total,
			excludedDate,
			degraded: false
		};
	}
	return {
		date: best,
		coverage: bestCoverage,
		total,
		excludedDate,
		degraded: best !== ""
	};
};
/**
* 统计两个日期之间的交易日数（`from` 不含、`to` 含）
* @param marketDates 交易日历（升序）
* @param from 起始日期（不含）
* @param to 结束日期（含）
* @returns 交易日数
*/
var countTradingDaysBetween = (marketDates, from, to) => marketDates.filter((date) => date > from && date <= to).length;
/**
* 裁掉基准日之后的行情（未落定日的半日 bar 一律不写入历史）
*
* 没有任何行需要裁时原样返回同一引用，避免无谓的响应式更新。
* @param boards 全部板块序列
* @param date 基准交易日（空串表示不裁剪）
* @returns 裁剪后的板块序列
*/
var trimAfter = (boards, date) => {
	if (date.length === 0) return [...boards];
	return boards.map((series) => series.days.some((day) => day.date > date) ? {
		...series,
		days: series.days.filter((day) => day.date <= date)
	} : series);
};
//#endregion
//#region plugins/dsh-mainline/judge.ts
/**
* 插件 dsh-mainline（股票主线）· 判定层（**纯函数**，可冒烟断言、可回测）
*
* 与技能 `a-share-huddle-mainline/scripts/huddle_judge.py` 同一定位：
* 只吃数据、只吐结论，不碰网络与存储。规则对应技能 `references/phase-rules.md`
* 里**可自动计算**的那部分（成交占比分位 / 量能倍数 / 价格分位 / 板块内涨停结构），
* 需要人工输入的（公募持仓分位、估值分位、业绩验证）本期不接入 ——
* 判定层因此把置信度降档并在界面「本期未接入的输入」里明说，**不静默**。
*
* 三条铁律（技能原文，代码里落实）：
* 1. 只输出阶段标签与风险提示，不出现任何买卖 / 仓位指令；
* 2. 只有价格上涨、没有业绩验证 → 不判「确认抱团」，本层的「确认」仅代表
*    「量价与拥挤度特征具备」，风险提示里明确写出「需连续两季业绩验证」；
* 3. 必须把原始指标面板一并给出（`BoardMetrics` 原样透出，不做二次加工）。
*
* 口径要点（2026-09-18 按实测重做，依据见 `.ai/开发方案/2026-09-18-股票主线指标优化与数据源评估.md`）：
* - **一切指标取基准交易日截面**（不是「各板块自己序列的最后一天」），滞后板块标 `stale`
*   并排除出阶段判定 —— 否则 9/10 只有 20/90 板块有 bar 时会出现「有的板块在算 9/17、
*   有的在算 9/16」而 asOf 用众数把差异掩盖掉；
* - 量能倍数改**滞后口径**（近 5 日均额 ÷ 前 20 日均额，分母不含分子），旧口径保留作对照；
* - 结构指标（涨停家数 / 宽度）在确认期做**正向门槛**：只有价格强、内部无涨停也无宽度的
*   板块更可能是权重拉抬，不判「确认」；连板高度/涨停占比则只做**情绪加速标记**，不改阶段。
*/
/**
* 计算某个值在一串历史值中的分位（0-100）
*
* 口径：`≤ 该值的历史样本数 ÷ 样本总数 × 100`，即「今天的水平在历史上压过多少天」。
* @param history 历史值（可含当天）
* @param value 待定位的值
* @returns 分位（0-100）；历史为空时返回 null
*/
var percentileRank = (history, value) => {
	const usable = history.filter((item) => Number.isFinite(item));
	if (usable.length === 0 || !Number.isFinite(value)) return null;
	return usable.filter((item) => item <= value).length / usable.length * 100;
};
/**
* 构建「交易日 → 沪深两市总成交额（元）」映射
* @param market 沪深成交额序列
* @returns 日期映射
*/
var buildMarketMap = (market) => new Map(market.filter((point) => point.date && Number.isFinite(point.totalAmount) && point.totalAmount > 0).map((point) => [point.date, point.totalAmount]));
/**
* 取序列尾部窗口的均值
* @param values 数值序列
* @param window 窗口长度
* @returns 均值；序列为空返回 null
*/
var averageOfTail = (values, window) => {
	const tail = values.slice(-window);
	if (tail.length === 0) return null;
	return tail.reduce((sum, item) => sum + item, 0) / tail.length;
};
/**
* 近 N 个交易日累计涨跌幅（%）
*
* 用收盘价比值而非逐日涨跌幅相加：后者会忽略复利效应，长窗口下偏差可观。
* 样本不足 N+1 天时退化为「可用区间的累计涨跌幅」。
* @param series 板块序列（升序）
* @param window 交易日窗口
* @returns 累计涨跌幅（%）；样本不足 2 天返回 0
*/
var trailingChange = (series, window) => {
	if (series.length < 2) return 0;
	const last = series[series.length - 1];
	const base = series[Math.max(0, series.length - 1 - window)];
	if (!last || !base || base.close <= 0) return 0;
	return (last.close - base.close) / base.close * 100;
};
/**
* 计算单板块的全部原始指标（按基准交易日截面）
* @param series 板块日线序列（升序）
* @param marketMap 交易日 → 沪深总成交额（元）
* @param context 截面上下文（基准日 + 交易日历）
* @returns 指标面板
*/
var computeMetrics = (series, marketMap, context) => {
	const days = series.days;
	const last = days[days.length - 1] ?? null;
	const benchmarkDay = days.find((day) => day.date === context.benchmarkDate) ?? null;
	const stale = benchmarkDay === null;
	const metrics = {
		asOf: "",
		source: series.source ?? MAINLINE_SOURCE.THS,
		benchmarkDate: context.benchmarkDate,
		stale,
		staleDays: 0,
		historyDays: days.length,
		latestChange: 0,
		change5: 0,
		change20: 0,
		amount: null,
		turnoverShare: null,
		sharePercentile: null,
		amountRatio: null,
		amountRatioOverlap: null,
		pricePercentile: null,
		limitUpCount: null,
		maxStreak: null,
		sealFund: null,
		limitUpRatio: null,
		breadth: null,
		riseCount: null,
		fallCount: null,
		netInflow: null,
		leaderName: ""
	};
	if (!last) return metrics;
	const reference = benchmarkDay ?? last;
	metrics.asOf = reference.date;
	metrics.staleDays = stale ? countTradingDaysBetween(context.marketDates, reference.date, context.benchmarkDate) : 0;
	const scoped = days.filter((day) => day.date <= reference.date);
	const shares = [];
	for (const day of scoped) {
		const total = marketMap.get(day.date);
		if (!total || day.amount <= 0) continue;
		shares.push(day.amount / total * 100);
	}
	const referenceTotal = marketMap.get(reference.date);
	const turnoverShare = referenceTotal && reference.amount > 0 ? reference.amount / referenceTotal * 100 : null;
	const amounts = scoped.map((day) => day.amount).filter((amount) => amount > 0);
	const shortAverage = averageOfTail(amounts, 5);
	const laggedAverage = averageOfTail(amounts.slice(0, Math.max(0, amounts.length - 5)), 20);
	const overlapAverage = averageOfTail(amounts, 20);
	const pricePercentile = percentileRank(scoped.map((day) => day.close).slice(-60), reference.close);
	const riseCount = reference.riseCount ?? null;
	const fallCount = reference.fallCount ?? null;
	const counted = riseCount !== null && fallCount !== null ? riseCount + fallCount : 0;
	const limitUpCount = reference.limitUpCount ?? null;
	return {
		...metrics,
		latestChange: reference.changePercent,
		change5: trailingChange(scoped, 5),
		change20: trailingChange(scoped, 20),
		amount: reference.amount > 0 ? reference.amount : null,
		turnoverShare,
		sharePercentile: turnoverShare !== null && shares.length > 0 ? percentileRank(shares, turnoverShare) : null,
		amountRatio: shortAverage !== null && laggedAverage !== null && laggedAverage > 0 ? shortAverage / laggedAverage : null,
		amountRatioOverlap: shortAverage !== null && overlapAverage !== null && overlapAverage > 0 ? shortAverage / overlapAverage : null,
		pricePercentile,
		limitUpCount,
		maxStreak: reference.maxStreak ?? null,
		sealFund: reference.sealFund ?? null,
		limitUpRatio: limitUpCount !== null && counted > 0 ? limitUpCount / counted * 100 : null,
		breadth: riseCount !== null && counted > 0 ? riseCount / counted * 100 : null,
		riseCount,
		fallCount,
		netInflow: reference.netInflow ?? null,
		leaderName: reference.leaderName ?? ""
	};
};
/**
* 由样本天数推置信度（样本不足 → 低档，界面据此提示）
* @param historyDays 历史样本交易日数
* @returns 置信度档位
*/
var resolveConfidence = (historyDays) => {
	if (historyDays >= 120) return "high";
	if (historyDays >= 60) return "medium";
	return "low";
};
/**
* 板块内部结构是否支持「确认期」
*
* 结构数据未采集（`limitUpCount === null`）时**不因此否决**（不能让取数失败变成降级判定）；
* 采到了就要求「至少 1 家涨停」或「宽度 ≥ 60%」—— 内部普跌的板块即便价格强也不是抱团主线。
* @param metrics 指标面板
* @returns 是否支持
*/
var isStructureSupporting = (metrics) => {
	if (metrics.limitUpCount === null) return true;
	if (metrics.limitUpCount >= 1) return true;
	return metrics.breadth !== null && metrics.breadth >= 60;
};
/**
* 板块是否处于「情绪加速」（连板梯队成型 / 涨停占比到档）
*
* 只用于展示与追加风险提示，**不参与阶段判定** —— 目前只有单日结构样本，不足以定阶段门槛。
* @param metrics 指标面板
* @returns 是否情绪加速
*/
var isStructureHot = (metrics) => (metrics.maxStreak ?? 0) >= 3 || (metrics.limitUpRatio ?? 0) >= 2;
/**
* 阶段判定（按「先极端、后成型、再萌芽」的顺序短路）
* @param metrics 指标面板
* @returns 阶段
*/
var resolvePhase = (metrics) => {
	const { sharePercentile, turnoverShare, change5, change20, amountRatio, pricePercentile, historyDays } = metrics;
	if (metrics.stale) return MAINLINE_PHASE.UNKNOWN;
	if (historyDays < 30 || sharePercentile === null) return MAINLINE_PHASE.UNKNOWN;
	if (sharePercentile >= 70 && turnoverShare !== null && turnoverShare >= 1 && pricePercentile !== null && pricePercentile >= 50 && change5 <= -5) return MAINLINE_PHASE.COLLAPSE;
	if (sharePercentile >= 90 && turnoverShare !== null && turnoverShare >= 1 && (pricePercentile !== null && pricePercentile >= 70 || change20 >= 15)) return MAINLINE_PHASE.MANIA;
	if (amountRatio !== null && amountRatio >= 1.35 && change5 > 0 && pricePercentile !== null && pricePercentile >= 97 && sharePercentile >= 50 && isStructureSupporting(metrics)) return MAINLINE_PHASE.CONFIRMED;
	if (amountRatio !== null && amountRatio >= 1.7 && sharePercentile < 50 && change5 > 0 && change5 <= 15) return MAINLINE_PHASE.GERMINATION;
	return MAINLINE_PHASE.NONE;
};
/**
* 组装风险提示（阶段固定文案 + 本期实测到的上下文提示，一律状态语言）
* @param metrics 指标面板
* @param phase 已判定阶段
* @param structureSupports 内部结构是否支持确认期
* @returns 提示数组
*/
var buildWarnings = (metrics, phase, structureSupports) => {
	const warnings = [];
	if (metrics.stale) warnings.push(MAINLINE_WARNING_STALE(metrics.staleDays));
	if (metrics.limitUpCount === null && !metrics.stale) warnings.push(MAINLINE_WARNING_NO_STRUCTURE);
	warnings.push(...MAINLINE_PHASE_WARNINGS[phase]);
	if (phase === MAINLINE_PHASE.NONE && !structureSupports && metrics.limitUpCount !== null && metrics.breadth !== null) warnings.push(MAINLINE_WARNING_STRUCTURE_FAIL(metrics.limitUpCount, metrics.breadth));
	if (phase === MAINLINE_PHASE.CONFIRMED && metrics.limitUpCount === 0 && metrics.breadth !== null) warnings.push(MAINLINE_WARNING_NO_LIMIT_UP(metrics.breadth));
	if (isStructureHot(metrics)) warnings.push(MAINLINE_WARNING_STRUCTURE_HOT(metrics.maxStreak ?? 0, metrics.limitUpRatio ?? 0));
	return warnings;
};
/**
* 判定单个板块
* @param series 板块日线序列
* @param marketMap 交易日 → 沪深总成交额（元）
* @param context 截面上下文
* @returns 判定结论（阶段 + 风险提示 + 原始指标面板）
*/
var judgeBoard = (series, marketMap, context) => {
	const metrics = computeMetrics(series, marketMap, context);
	const phase = resolvePhase(metrics);
	const structureSupports = isStructureSupporting(metrics);
	const candidate = metrics.sharePercentile !== null && metrics.sharePercentile >= 70 || metrics.amountRatio !== null && metrics.amountRatio >= 1.7;
	return {
		code: series.code,
		name: series.name,
		phase,
		phaseLabel: MAINLINE_PHASE_LABEL[phase],
		phaseDesc: MAINLINE_PHASE_DESC[phase],
		candidate,
		confidence: resolveConfidence(metrics.historyDays),
		structureHot: isStructureHot(metrics),
		warnings: buildWarnings(metrics, phase, structureSupports),
		metrics
	};
};
/**
* 判定全部板块并排序（阶段严重度优先，同阶段按成交占比分位降序）
* @param boards 全部板块序列
* @param market 沪深成交额序列
* @param now 当前时间（决定基准日；缺省取当前时刻，测试可传入固定时间）
* @returns 判定结论数组
*/
var judgeAll = (boards, market, now = /* @__PURE__ */ new Date()) => {
	const marketMap = buildMarketMap(market);
	const context = {
		benchmarkDate: resolveBenchmark(boards, market, now).date,
		marketDates: market.map((point) => point.date).sort()
	};
	return boards.map((series) => judgeBoard(series, marketMap, context)).sort((a, b) => {
		const byPhase = MAINLINE_PHASE_ORDER[a.phase] - MAINLINE_PHASE_ORDER[b.phase];
		if (byPhase !== 0) return byPhase;
		return (b.metrics.sharePercentile ?? -1) - (a.metrics.sharePercentile ?? -1);
	});
};
//#endregion
//#region plugins/dsh-mainline/board-merge.ts
/**
* 合并同一日的两条行情（新数据覆盖价量，但**保留已采到的结构字段**）
*
* ⚠️ `undefined` 与 `0` 语义不同：未采集是 `undefined`，采到且确实为 0 家涨停是 `0`，
* 所以这里用 `??` 而不是 `||` —— 新数据明确给了 0 就以 0 为准。
* @param previous 本地已有行
* @param incoming 本次年 K 行
* @returns 合并后的行
*/
var mergeDaily = (previous, incoming) => ({
	...incoming,
	riseCount: incoming.riseCount ?? previous.riseCount,
	fallCount: incoming.fallCount ?? previous.fallCount,
	netInflow: incoming.netInflow ?? previous.netInflow,
	leaderName: incoming.leaderName ?? previous.leaderName,
	limitUpCount: incoming.limitUpCount ?? previous.limitUpCount,
	maxStreak: incoming.maxStreak ?? previous.maxStreak,
	sealFund: incoming.sealFund ?? previous.sealFund
});
/**
* 合并新旧日线序列（按日期去重，新数据覆盖旧数据，升序返回）
* @param existing 本地已有序列
* @param incoming 本次拉取序列
* @returns 合并后的序列
*/
var mergeDays = (existing, incoming) => {
	const merged = /* @__PURE__ */ new Map();
	for (const day of existing) merged.set(day.date, day);
	for (const day of incoming) {
		const previous = merged.get(day.date);
		merged.set(day.date, previous ? mergeDaily(previous, day) : day);
	}
	return [...merged.values()].sort((a, b) => a.date < b.date ? -1 : a.date > b.date ? 1 : 0);
};
/**
* 把结构指标写到基准日那一行
*
* 只有该板块**确实有基准日的行情 bar** 才写：滞后板块不硬塞（否则等于用别的日期的
* 结构数据冒充基准日），它会在判定层被标 `stale` 并排除出阶段判定。
* @param series 板块序列
* @param date 基准交易日
* @param structure 结构数据
* @returns 富化后的序列（无需改动时返回原引用）
*/
var enrichBenchmarkDay = (series, date, structure) => {
	const index = series.days.findIndex((day) => day.date === date);
	if (index < 0) return series;
	const previous = series.days[index];
	const snapshot = structure.snapshots.get(series.code);
	const stat = structure.limitUp?.get(series.code);
	const enriched = {
		...previous,
		riseCount: snapshot?.riseCount ?? previous.riseCount,
		fallCount: snapshot?.fallCount ?? previous.fallCount,
		netInflow: snapshot?.netInflow ?? previous.netInflow,
		leaderName: snapshot?.leaderName || previous.leaderName,
		limitUpCount: structure.limitUp ? stat?.count ?? 0 : previous.limitUpCount,
		maxStreak: structure.limitUp ? stat?.maxStreak ?? 0 : previous.maxStreak,
		sealFund: structure.limitUp ? stat?.sealFund ?? 0 : previous.sealFund
	};
	const days = [...series.days];
	days[index] = enriched;
	return {
		...series,
		days
	};
};
//#endregion
//#region plugins/dsh-mainline/em-data.ts
/**
* 插件 dsh-mainline（股票主线）· 东方财富兜底取数层（L2.5）
*
* 岗位：**只在「同花顺整体不可用」时上岗**（清单页与全部板块日线都取不到），整表降级为东财口径。
* 单板块失败不走这里 —— 那属于同花顺自己的同源回退链（`ths-data.ts` 的 last.js / 去年文件）
* 与本地旧数据（L0）的职责，为个别板块引入跨源台阶得不偿失。
*
* 纯函数（`parseEmBoardListJson` / `parseEmKlineJson` / `matchThsToEm`）与 fetch 包装分开，
* 前者可离线冒烟断言（见 `.ai/tmp/mainline-ab-smoke.mjs`）。
*
* 数据源与字段（实测 2026-09-18，证据见 `.ai/开发方案/2026-09-18-数据源兜底方案.md`）：
* - 板块清单 `push2delay.eastmoney.com/api/qt/clist/get?fs=m:90+t:2`：
*   `data.diff` 每行 `f12` 代码 / `f14` 名称 / `f3` 涨跌幅 / `f6` 成交额(元) /
*   `f62` 主力净流入(元) / `f104` 上涨家数 / `f105` 下跌家数 / `f128` 领涨股。
*   实测共 496 个板块（一/二/三级混合）→ **不当板块全集用**，只当「名称 → 代码」映射表。
* - 板块日 K `push2his.eastmoney.com/api/qt/stock/kline/get?secid=90.<code>`：
*   `data.klines` 每行 `日期,开,收,高,低,成交量,成交额`（f51~f57，顺序实测如此；
*   成交额单位元、日期已是 `YYYY-MM-DD`）。
* - ⚠️ 东财行情域是**突发限速**：间隔 ≥1s 正常、短时连发立刻拒连（停顿约 20s 恢复）
*   → 兜底轮必须串行（`EM_SCAN_CONCURRENCY = 1`）且间隔 ≥ `EM_SCAN_DELAY_MS`。
* - 两处都要带东财 Referer；请求统一经 `proxyFetch`（`eastmoney.com` 已在代理白名单与
*   Tauri capabilities 内）。
*/
/** 东财板块名尾部的罗马数字（Ⅱ / Ⅲ 等，用来标注二级 / 三级行业） */
var EM_BOARD_ROMAN_SUFFIX_PATTERN = /[\u2160-\u2169]+$/;
/** 二级行业标记（剥后缀重名时优先它：同花顺 90 个板块 ≈ 申万二级） */
var EM_BOARD_ROMAN_LEVEL_II = "Ⅱ";
/** 三级行业标记 */
var EM_BOARD_ROMAN_LEVEL_III = "Ⅲ";
/** 日 K 行的最少字段数（少于 7 段视为脏行丢弃） */
var EM_KLINE_MIN_FIELDS = 7;
/** 日 K 行内字段下标（实测顺序：日期 / 开 / 收 / 高 / 低 / 量 / 额） */
var EM_KLINE_FIELD = {
	DATE: 0,
	OPEN: 1,
	CLOSE: 2,
	HIGH: 3,
	LOW: 4,
	VOLUME: 5,
	AMOUNT: 6
};
/** 日 K 日期字段形态：YYYY-MM-DD */
var EM_KLINE_DATE_PATTERN = /^\d{4}-\d{2}-\d{2}$/;
/** 一日涨跌幅计算基数（百分比） */
var PERCENT_SCALE$1 = 100;
/**
* 罗马后缀的优先级别（0 = 无后缀，1 = Ⅱ，2 = Ⅲ，3 = 其它）
* @param name 东财板块名
* @returns 优先级（越小越优先）
*/
var romanRank = (name) => {
	const match = EM_BOARD_ROMAN_SUFFIX_PATTERN.exec(name);
	if (!match) return 0;
	if (match[0] === EM_BOARD_ROMAN_LEVEL_II) return 1;
	if (match[0] === EM_BOARD_ROMAN_LEVEL_III) return 2;
	return 3;
};
/**
* 数值字段（`"-"` / 空 / 非数一律 null —— 绝不把「无数据」当 0）
* @param value 原始字段值
* @returns 数值；无法解析为 null
*/
var toNumber = (value) => {
	if (typeof value === "number") return Number.isFinite(value) ? value : null;
	if (typeof value === "string") {
		const text = value.trim();
		if (text === "" || text === "-") return null;
		const parsed = Number(text);
		return Number.isFinite(parsed) ? parsed : null;
	}
	return null;
};
/**
* 文本字段（非字符串一律空串）
* @param value 原始字段值
* @returns 去空白后的文本
*/
var toText = (value) => typeof value === "string" ? value.trim() : "";
/**
* 解析东财板块清单 JSON（纯函数，同时给出 `total`）
*
* `data.diff` 在带 `np=1` 时是数组，历史形态也可能是对象映射，两种都兼容。
* `data.total` 是**上游自报的全表行数**，用来校验分页有没有漏收（配合稳定排序，
* 实测 total 与全表去重行数一致；漏收时宁可报错也不静默少收，否则「未映射」名单会凭空变长）。
* @param text 响应文本（UTF-8 JSON）
* @returns `{ rows, total }`；rows 为板块快照（按代码去重，保持返回顺序），total 解析不到时为 null
*/
var parseEmBoardListPageJson = (text) => {
	let payload;
	try {
		payload = JSON.parse(text);
	} catch {
		return {
			rows: [],
			total: null
		};
	}
	const total = toNumber(payload.data?.total);
	const diff = payload.data?.diff;
	const rawRows = Array.isArray(diff) ? diff : diff && typeof diff === "object" ? Object.values(diff) : [];
	const snapshots = [];
	const seen = /* @__PURE__ */ new Set();
	for (const raw of rawRows) {
		if (!raw || typeof raw !== "object") continue;
		const row = raw;
		const code = toText(row[EM_BOARD_FIELD.CODE]);
		const name = toText(row[EM_BOARD_FIELD.NAME]);
		if (!code || !name || seen.has(code)) continue;
		seen.add(code);
		snapshots.push({
			code,
			name,
			source: MAINLINE_SOURCE.EM,
			changePercent: toNumber(row[EM_BOARD_FIELD.CHANGE_PERCENT]),
			amount: toNumber(row[EM_BOARD_FIELD.AMOUNT]),
			netInflow: toNumber(row[EM_BOARD_FIELD.NET_INFLOW]),
			riseCount: toNumber(row[EM_BOARD_FIELD.RISE]),
			fallCount: toNumber(row[EM_BOARD_FIELD.FALL]),
			leaderName: toText(row[EM_BOARD_FIELD.LEADER])
		});
	}
	return {
		rows: snapshots,
		total
	};
};
/**
* 解析东财板块日 K JSON（纯函数）
*
* 涨跌幅与同花顺侧一致：由**相邻收盘价比值**算出（不用接口的涨跌幅字段），
* 首日无前收 → 记 0，避免污染累计涨幅。
* @param text 响应文本（UTF-8 JSON）
* @returns 逐日行情（升序）；无数据返回空数组
*/
var parseEmKlineJson = (text) => {
	let payload;
	try {
		payload = JSON.parse(text);
	} catch {
		return [];
	}
	const klines = payload.data?.klines;
	if (!Array.isArray(klines)) return [];
	const days = [];
	let previousClose = null;
	for (const raw of klines) {
		if (typeof raw !== "string") continue;
		const fields = raw.split(",");
		if (fields.length < EM_KLINE_MIN_FIELDS) continue;
		const date = fields[EM_KLINE_FIELD.DATE];
		const close = Number(fields[EM_KLINE_FIELD.CLOSE]);
		const amount = Number(fields[EM_KLINE_FIELD.AMOUNT]);
		if (!EM_KLINE_DATE_PATTERN.test(date) || !Number.isFinite(close) || close <= 0) continue;
		days.push({
			date,
			close,
			changePercent: previousClose !== null && previousClose > 0 ? (close - previousClose) / previousClose * PERCENT_SCALE$1 : 0,
			amount: Number.isFinite(amount) && amount > 0 ? amount : 0
		});
		previousClose = close;
	}
	return days;
};
/**
* 把同花顺板块清单映射到东财板块（纯函数）
*
* 匹配只做**同层级语义等价**的两级 + 人工别名表：
* ① 名称等值；② 剥掉东财的罗马数字后缀（重名时优先「Ⅱ」——同花顺 90 板块≈申万二级）；
* ③ `MAINLINE_THS_TO_EM_ALIAS` 里语义等价但名称不同的（词序颠倒 / 申万改名）。
* 不做「唯一前缀」兜底：实测它命中的全是「东财比同花顺粗一级」的板块
* （`汽车整车` → 东财一级 `汽车`，而零部件已单独映射 → 会把零部件重复计入），
* 映射不上就**不猜**，落进 `unmapped` 由界面如实列出。
* @param refs 同花顺板块清单
* @param emBoards 东财板块清单
* @returns 映射结果（含未映射名单）
*/
var matchThsToEm = (refs, emBoards) => {
	const exact = /* @__PURE__ */ new Map();
	for (const board of emBoards) if (!exact.has(board.name)) exact.set(board.name, board);
	const stripped = /* @__PURE__ */ new Map();
	for (const board of emBoards) {
		const base = board.name.replace(EM_BOARD_ROMAN_SUFFIX_PATTERN, "");
		if (base === board.name) continue;
		const current = stripped.get(base);
		if (!current || romanRank(board.name) < romanRank(current.name)) stripped.set(base, board);
	}
	/**
	* 名称 → 东财板块（等值 → 剥后缀）
	* @param name 待解析的名称（同花顺板块名，或别名表给出的东财名）
	* @returns 命中的东财板块；未命中 undefined
	*/
	const resolve = (name) => exact.get(name) ?? stripped.get(name);
	const mapped = /* @__PURE__ */ new Map();
	const unmapped = [];
	for (const ref of refs) {
		const target = resolve(ref.name) ?? resolve(MAINLINE_THS_TO_EM_ALIAS[ref.name] ?? "");
		if (target) mapped.set(ref.code, target);
		else unmapped.push(ref.name);
	}
	return {
		mapped,
		unmapped
	};
};
/**
* 是否应当整表降级东财（L2.5 触发条件，纯函数便于断言）
*
* 判定依据是「清单里的**全部**板块日线都取不到」—— 单板块失败属于同花顺自己的
* 同源回退链（last.js / 去年文件）与本地旧数据该管的事，不该把整表切到另一个口径。
* @param refCount 本次板块清单长度
* @param failures 取数失败的板块代码
* @returns 是否需要整表降级
*/
var shouldFallbackToEm = (refCount, failures) => refCount > 0 && failures.length === refCount;
/**
* 拉取东财板块清单的指定页（连接被掐断时原地重试）
* @param deps 宿主能力集合（http / format / market / ui）
* @param page 页码（从 1 开始）
* @returns 该页快照行与上游自报的全表行数
*/
var fetchEmBoardListPage = async (deps, page) => {
	const url = `${EM_BOARD_LIST_URL}?${EM_BOARD_LIST_QUERY.replace(EM_BOARD_LIST_PAGE_TOKEN, String(page))}`;
	let lastError = "未知错误";
	for (let attempt = 0; attempt < 3; attempt += 1) {
		if (attempt > 0) await deps.format.delay(EM_SCAN_DELAY_MS);
		try {
			const response = await deps.http.fetch(url, { headers: { Referer: EM_REFERER } });
			if (!response.ok) {
				lastError = `HTTP ${response.status}`;
				continue;
			}
			return parseEmBoardListPageJson(await response.text());
		} catch (error) {
			lastError = error instanceof Error ? error.message : String(error);
		}
	}
	throw new Error(`东财板块清单第 ${page} 页不可用（${lastError}）`);
};
/**
* 拉取东财板块清单全表（分页 + 串行间隔 + 完整性校验）
*
* 两道防线，都是为了「不静默少收」—— 清单不完整会让「未映射」名单凭空变长，
* 把「其实有对应板块」误报成「东财没有同义板块」，直接影响整表降级的可信度：
* 1. 排序用稳定字段（`EM_BOARD_LIST_SORT_FIELD`），行不会在页边界搬家；
* 2. 收完与上游自报的 `total` 对账，短了就把整轮重跑一次（`EM_UNIVERSE_ROUNDS`），
*    仍短则**抛错**，让上层如实报「兜底失败」而不是报「东财无同义板块」。
* @param deps 宿主能力集合（http / format / market / ui）
* @returns 全部板块快照（按代码去重）
*/
var fetchEmBoardUniverse = async (deps) => {
	let lastShort = "";
	for (let round = 0; round < 2; round += 1) {
		if (round > 0) await deps.format.delay(EM_SCAN_RETRY_DELAY_MS);
		const merged = /* @__PURE__ */ new Map();
		let total = null;
		for (let page = 1; page <= 6; page += 1) {
			if (page > 1) await deps.format.delay(EM_SCAN_DELAY_MS);
			const pageData = await fetchEmBoardListPage(deps, page);
			if (pageData.total !== null) total = pageData.total;
			if (pageData.rows.length === 0) break;
			for (const row of pageData.rows) {
				if (merged.has(row.code)) continue;
				merged.set(row.code, row);
			}
		}
		const rows = [...merged.values()];
		if (total === null || rows.length >= total) return rows;
		lastShort = `上游自报 ${total} 个板块，实收 ${rows.length} 个`;
	}
	throw new Error(`东财板块清单不完整（${lastShort}）`);
};
/**
* 拉取单个东财板块的日 K（连接被掐断时原地重试 `EM_FETCH_ATTEMPTS` 次）
* @param deps 宿主能力集合（http / format / market / ui）
* @param emCode 东财板块代码（BKxxxx）
* @param year 当前年份（起始日期从 `year - EM_KLINE_YEARS_BACK` 年初算）
* @returns 逐日行情（升序）；全部尝试都失败时抛错
*/
var fetchEmBoardKline = async (deps, emCode, year) => {
	const url = `${EM_BOARD_KLINE_URL}?secid=90.${emCode}&fields1=${EM_KLINE_META_FIELDS}&fields2=${EM_KLINE_FIELDS}&klt=101&fqt=1&beg=${`${year - 1}0101`}&end=${EM_KLINE_END}`;
	let lastError = "未知错误";
	for (let attempt = 0; attempt < 3; attempt += 1) {
		if (attempt > 0) await deps.format.delay(EM_SCAN_DELAY_MS);
		try {
			const response = await deps.http.fetch(url, { headers: { Referer: EM_REFERER } });
			if (!response.ok) {
				lastError = `HTTP ${response.status}`;
				continue;
			}
			const days = parseEmKlineJson(await response.text());
			if (days.length > 0) return days;
			lastError = "空数据";
		} catch (error) {
			lastError = error instanceof Error ? error.message : String(error);
		}
	}
	throw new Error(`东财板块日K不可用：${emCode}（${lastError}）`);
};
//#endregion
//#region plugins/dsh-mainline/limit-up.ts
/**
* 插件 dsh-mainline（股票主线）· 涨停结构层
*
* 给每个行业板块补上「内部结构」指标：涨停家数 / 最高连板 / 封板资金合计。
*
* 数据源：东财涨停池（宿主 `fetchZtPool`，`push2ex.eastmoney.com/getTopicZTPool`）——
* 实测 2026-09-18 返回 63 家涨停，字段含 `hybk`(行业) `lbc`(连板数) `fund`(封板资金)。
* `date` 参数**确实生效**（实测同一只票连板数逐日递进：9/15 = 1 板 → 9/16 = 2 板 → 9/17 = 3 板），
* 但只覆盖近端池子（一个月前的日期返回空池）→ 只能取「基准日当天」的池子。
*
* ⚠️ 归属映射的诚实边界：涨停池的 `hybk` 是**东财（≈申万）行业**口径，与同花顺行业板块
* 不是同一套分类，且长名被上游截断到 4 个汉字。本模块按「等值 → 前缀（双向）→ 人工别名表」
* 三级匹配，**匹配不到的一律计入未归属并返回给上层展示**，不做静默猜测 ——
* 界面页头会写「全市场 N 家（未归属板块 M 家）」，让口径缺口可见。
*/
/**
* 构造「东财行业名 → 同花顺板块」的匹配器
*
* 匹配顺序（每一级都要求唯一命中，避免把资金记到错误板块）：
* 1. 等值：`半导体` → `半导体`
* 2. 前缀：上游截断名 `光学光电` → `光学光电子`；以及带后缀的 `IT服务Ⅱ` → `IT服务`
* 3. 别名：分类口径不同但语义等价（见 `MAINLINE_INDUSTRY_ALIAS` 的说明）
* @param boards 板块清单
* @returns 匹配函数（未命中返回 null）
*/
var createIndustryMatcher = (boards) => {
	const byName = new Map(boards.map((board) => [board.name, board]));
	return (industry) => {
		if (!industry) return null;
		const exact = byName.get(industry);
		if (exact) return exact;
		let forward = null;
		let forwardCount = 0;
		let backward = null;
		let backwardCount = 0;
		for (const board of boards) if (board.name.startsWith(industry)) {
			forward = board;
			forwardCount += 1;
		} else if (industry.startsWith(board.name)) {
			backward = board;
			backwardCount += 1;
		}
		if (forward && forwardCount === 1) return forward;
		if (backward && backwardCount === 1) return backward;
		const alias = MAINLINE_INDUSTRY_ALIAS[industry];
		return alias ? byName.get(alias) ?? null : null;
	};
};
/**
* 把涨停池按板块聚合（未归属的单独统计，不并入任何板块）
* @param items 涨停池成员
* @param boards 板块清单
* @returns 聚合结果
*/
var aggregateLimitUp = (items, boards) => {
	const match = createIndustryMatcher(boards);
	const byCode = /* @__PURE__ */ new Map();
	const unmapped = /* @__PURE__ */ new Map();
	for (const item of items) {
		const board = match(item.industry ?? "");
		if (!board) {
			const key = item.industry || "(无行业)";
			unmapped.set(key, (unmapped.get(key) ?? 0) + 1);
			continue;
		}
		const stat = byCode.get(board.code) ?? {
			count: 0,
			maxStreak: 0,
			sealFund: 0
		};
		stat.count += 1;
		stat.maxStreak = Math.max(stat.maxStreak, item.continuousBoardCount ?? 1);
		stat.sealFund += item.boardAmount ?? 0;
		byCode.set(board.code, stat);
	}
	let unmappedCount = 0;
	for (const count of unmapped.values()) unmappedCount += count;
	return {
		byCode,
		unmappedCount,
		unmappedIndustries: [...unmapped.keys()].sort(),
		total: items.length
	};
};
/**
* 拉取指定交易日的涨停池
* @param deps 宿主能力集合（http / format / market / ui）
* @param date 基准交易日（`YYYY-MM-DD`）
* @returns 涨停池成员（上游对该日期无池子时返回空数组）
*/
var fetchLimitUpPool = async (deps, date) => deps.market.fetchLimitUpPool(date);
//#endregion
//#region plugins/dsh-mainline/ths-data.ts
/** 清单页里板块链接的代码提取（`detail/code/<6 位数字>/`） */
var BOARD_LIST_CODE_PATTERN = /\/thshy\/detail\/code\/(\d{6})\//g;
/** 清单页里 `…/detail/code/881121/" … >半导体</a>` 的名称提取 */
var BOARD_LIST_ANCHOR_PATTERN = /href="[^"]*\/thshy\/detail\/code\/(\d{6})\/"[^>]*>([^<]{1,20})<\/a>/g;
/** 清单页表格行（快照解析用） */
var BOARD_ROW_PATTERN = /<tr[^>]*>([\s\S]*?)<\/tr>/g;
/** 行内的单元格 */
var BOARD_CELL_PATTERN = /<td[^>]*>([\s\S]*?)<\/td>/g;
/** 行内 HTML 标签（取纯文本用） */
var HTML_TAG_PATTERN = /<[^>]*>/g;
/** 快照行识别用的板块代码（行内锚点） */
var BOARD_ROW_CODE_PATTERN = /\/thshy\/detail\/code\/(\d{6})\//;
/** 快照行的最少单元格数（列：序号/板块/涨跌幅/量/额/净流入/上涨/下跌/均价/领涨股/最新价/涨跌幅） */
var BOARD_ROW_MIN_CELLS = 12;
/** 快照行单元格下标（实测列头顺序固定） */
var BOARD_CELL_INDEX = {
	NAME: 1,
	CHANGE_PERCENT: 2,
	AMOUNT: 4,
	NET_INFLOW: 5,
	RISE: 6,
	FALL: 7,
	LEADER: 9
};
/** 快照行里代表「无数据」的占位文本 */
var VALUE_PLACEHOLDER = /* @__PURE__ */ new Set([
	"-",
	"--",
	"",
	"—"
]);
/** 年 K 行内字段下标（0 起）：日期 / 开 / 高 / 低 / 收 / 成交量 / 成交额 */
var KLINE_FIELD = {
	DATE: 0,
	OPEN: 1,
	HIGH: 2,
	LOW: 3,
	CLOSE: 4,
	VOLUME: 5,
	AMOUNT: 6
};
/** 年 K 行的最少字段数（少于 7 段视为脏行丢弃） */
var KLINE_MIN_FIELDS = 7;
/** 年 K 日期字段形态：YYYYMMDD */
var KLINE_DATE_LENGTH = 8;
/** 一日涨跌幅计算基数（百分比） */
var PERCENT_SCALE = 100;
/**
* 按 GBK 解码响应体（同花顺清单页为 GBK；Node 侧无 TextDecoder('gbk') 时退回 UTF-8）
* @param buffer 响应原始字节
* @returns 解码后的文本
*/
var decodeGbk = (buffer) => {
	try {
		return new TextDecoder("gbk").decode(buffer);
	} catch {
		return new TextDecoder("utf-8").decode(buffer);
	}
};
/**
* 解析同花顺行业板块清单 HTML（纯函数）
*
* 同一板块会在页面里出现多次（字母分组导航 + 内容区），按代码去重后返回。
* 只保留 88 开头（行业板块）的代码，概念板块（885xxx / 30xxxx）不在本期范围。
* @param html 清单页 HTML 文本（已按 GBK 解码）
* @returns 板块清单（按页面出现顺序去重）
*/
var parseBoardListHtml = (html) => {
	const seen = /* @__PURE__ */ new Set();
	const boards = [];
	for (const match of html.matchAll(BOARD_LIST_ANCHOR_PATTERN)) {
		const code = match[1];
		const name = match[2].trim();
		if (!code.startsWith("88") || !name || seen.has(code)) continue;
		seen.add(code);
		boards.push({
			code,
			name
		});
	}
	if (boards.length === 0) for (const match of html.matchAll(BOARD_LIST_CODE_PATTERN)) {
		const code = match[1];
		if (!code.startsWith("88") || seen.has(code)) continue;
		seen.add(code);
		boards.push({
			code,
			name: code
		});
	}
	return boards;
};
/**
* 解析同花顺板块年 K 的 JSONP 文本（纯函数）
*
* 涨跌幅不取接口字段（该接口里为空），一律由**相邻收盘价比值**算出，
* 首日无前收 → 涨跌幅记 0，避免污染累计涨幅。
* @param text 年 K JSONP 文本
* @returns 逐日行情（升序）；空数据返回空数组
*/
var parseKlineJsonp = (text) => {
	const start = text.indexOf("(");
	const end = text.lastIndexOf(")");
	if (start < 0 || end <= start) return [];
	let payload;
	try {
		payload = JSON.parse(text.slice(start + 1, end));
	} catch {
		return [];
	}
	if (typeof payload.data !== "string" || payload.data.length === 0) return [];
	const days = [];
	let previousClose = null;
	for (const row of payload.data.split(";")) {
		const fields = row.split(",");
		if (fields.length < KLINE_MIN_FIELDS) continue;
		const rawDate = fields[KLINE_FIELD.DATE];
		const close = Number(fields[KLINE_FIELD.CLOSE]);
		const amount = Number(fields[KLINE_FIELD.AMOUNT]);
		if (rawDate.length !== KLINE_DATE_LENGTH || !Number.isFinite(close) || close <= 0) continue;
		const date = `${rawDate.slice(0, 4)}-${rawDate.slice(4, 6)}-${rawDate.slice(6, 8)}`;
		const changePercent = previousClose !== null && previousClose > 0 ? (close - previousClose) / previousClose * PERCENT_SCALE : 0;
		previousClose = close;
		days.push({
			date,
			close,
			changePercent,
			amount: Number.isFinite(amount) && amount > 0 ? amount : 0
		});
	}
	return days;
};
/**
* 单元格纯文本（去标签、解码常见实体、收空白）
* @param html 单元格 HTML
* @returns 纯文本
*/
var cellText = (html) => html.replace(HTML_TAG_PATTERN, "").replace(/&nbsp;/gi, " ").replace(/&amp;/gi, "&").replace(/&lt;/gi, "<").replace(/&gt;/gi, ">").replace(/&quot;/gi, "\"").replace(/&#39;/g, "'").trim();
/**
* 单元格数值（占位符与非数一律 null，绝不当 0 用）
* @param html 单元格 HTML
* @returns 数值；无法解析为 null
*/
var cellNumber = (html) => {
	const text = cellText(html).replace(/,/g, "");
	if (VALUE_PLACEHOLDER.has(text)) return null;
	const value = Number(text);
	return Number.isFinite(value) ? value : null;
};
/**
* 解析同花顺行业清单页的**快照行**（纯函数）
*
* 实测行结构（2026-09-18）：`序号 | 板块(带 detail/code 锚点) | 涨跌幅 | 总成交量(万手) |
* 总成交额(亿元) | 净流入(亿元) | 上涨家数 | 下跌家数 | 均价 | 领涨股 | 最新价 | 涨跌幅`。
* 这一页一次给全 90 个行业板块（第二页实测为空），所以涨跌家数与净流入是**零额外请求**拿到的。
* @param html 清单页 HTML（已按 GBK 解码）
* @returns 每个板块一行的快照（按页面顺序去重）
*/
var parseBoardListSnapshotHtml = (html) => {
	const rows = [];
	const seen = /* @__PURE__ */ new Set();
	for (const rowMatch of html.matchAll(BOARD_ROW_PATTERN)) {
		const rowHtml = rowMatch[1];
		const codeMatch = BOARD_ROW_CODE_PATTERN.exec(rowHtml);
		if (!codeMatch) continue;
		const code = codeMatch[1];
		if (!code.startsWith("88") || seen.has(code)) continue;
		const cells = [...rowHtml.matchAll(BOARD_CELL_PATTERN)].map((cell) => cell[1]);
		if (cells.length < BOARD_ROW_MIN_CELLS) continue;
		seen.add(code);
		const amountYi = cellNumber(cells[BOARD_CELL_INDEX.AMOUNT]);
		const netInflowYi = cellNumber(cells[BOARD_CELL_INDEX.NET_INFLOW]);
		rows.push({
			code,
			name: cellText(cells[BOARD_CELL_INDEX.NAME]) || code,
			source: MAINLINE_SOURCE.THS,
			changePercent: cellNumber(cells[BOARD_CELL_INDEX.CHANGE_PERCENT]),
			amount: amountYi === null ? null : amountYi * YUAN_PER_YI,
			netInflow: netInflowYi === null ? null : netInflowYi * YUAN_PER_YI,
			riseCount: cellNumber(cells[BOARD_CELL_INDEX.RISE]),
			fallCount: cellNumber(cells[BOARD_CELL_INDEX.FALL]),
			leaderName: cellText(cells[BOARD_CELL_INDEX.LEADER])
		});
	}
	return rows;
};
/**
* 拉取同花顺行业清单页 HTML（GBK 解码后的文本）
* @param deps 宿主能力集合（http / format / market / ui）
* @returns 清单页 HTML
*/
var fetchBoardListHtml = async (deps) => {
	const response = await deps.http.fetch(THS_BOARD_LIST_URL, { headers: { Referer: THS_REFERER } });
	if (!response.ok) throw new Error(`同花顺板块清单 HTTP ${response.status}`);
	return decodeGbk(await response.arrayBuffer());
};
/**
* 合并多页快照行（按代码去重，保持页序）
* @param pages 每页的快照行
* @returns 合并后的快照行
*/
var mergeSnapshotRows = (pages) => {
	const seen = /* @__PURE__ */ new Set();
	const merged = [];
	for (const page of pages) for (const row of page) {
		if (seen.has(row.code)) continue;
		seen.add(row.code);
		merged.push(row);
	}
	return merged;
};
/**
* 拉取同花顺行业清单页的指定分页（ajax 形态，只返回表格行）
* @param deps 宿主能力集合（http / format / market / ui）
* @param page 页码（从 2 开始）
* @returns 该页 HTML（已按 GBK 解码）
*/
var fetchBoardListPageHtml = async (deps, page) => {
	const url = `${THS_BOARD_LIST_PAGE_URL_BASE}${page}${THS_BOARD_LIST_PAGE_URL_SUFFIX}`;
	const response = await deps.http.fetch(url, { headers: { Referer: THS_REFERER } });
	if (!response.ok) throw new Error(`同花顺板块清单第 ${page} 页 HTTP ${response.status}`);
	return decodeGbk(await response.arrayBuffer());
};
/**
* 取某一页清单快照（含同上游间隔；失败返回 null 由调用方降级处理）
* @param deps 宿主能力集合（http / format / market / ui）
* @param page 页码
* @returns 该页快照行；取数或解析失败为 null
*/
var tryFetchBoardListPage = async (deps, page) => {
	try {
		await deps.format.delay(500);
		return parseBoardListSnapshotHtml(await fetchBoardListPageHtml(deps, page));
	} catch (error) {
		console.warn(`[plugin] dsh-mainline 清单页第 ${page} 页取数失败`, error);
		return null;
	}
};
/**
* 拉取同花顺行业清单页（**板块清单 + 全部分页的当日结构快照**）
*
* 首页一次请求拿到板块清单（锚点，90 个）与第一页表格（50 行），再翻页补齐剩余行 ——
* 实测 90 个行业板块分布在 2 页（50 + 40）。
*
* 两种解析各自兜底：表格结构若被上游改版，`rows` 变少而 `refs` 仍在 ——
* 扫描照常进行，只是结构指标覆盖不全（下层按「未采集」处理，界面如实标注），
* 不会因为一个新字段解析失败就整轮扫描失败。翻页失败同样只降级、不抛错。
* @param deps 宿主能力集合（http / format / market / ui）
* @returns 板块清单与全部分页的快照行
*/
var fetchThsBoardPage = async (deps) => {
	const html = await fetchBoardListHtml(deps);
	const refs = parseBoardListHtml(html);
	const pages = [parseBoardListSnapshotHtml(html)];
	for (let page = 2; page <= 4; page += 1) {
		const pageRows = await tryFetchBoardListPage(deps, page);
		if (pageRows === null) break;
		const known = new Set(mergeSnapshotRows(pages).map((row) => row.code));
		if (pageRows.every((row) => known.has(row.code))) break;
		pages.push(pageRows);
	}
	const rows = mergeSnapshotRows(pages);
	if (refs.length === 0 && rows.length === 0) throw new Error("同花顺板块清单解析为空");
	return {
		refs: refs.length > 0 ? refs : rows.map((row) => ({
			code: row.code,
			name: row.name
		})),
		rows
	};
};
/**
* 构造板块日 K 的候选 URL 段（纯函数，便于冒烟断言回退顺序）
*
* 顺序：当年 01 → 当年 00 → **近端 01/last → 近端 00/last** → 去年 01 → 去年 00。
* 近端文件排在去年之前：它是同源同口径的热点文件，实测能救回「年文件 502」的板块，
* 且近半年数据对 5/20 日量能与 60 日价格分位比去年的旧数据更有用。
* @param year 年份（如 2026）
* @returns 候选列表（按尝试优先级）
*/
var buildKlineCandidates = (year) => {
	const candidates = [];
	const pushFile = (file) => {
		candidates.push({
			file,
			adjust: "01"
		}, {
			file,
			adjust: "00"
		});
	};
	pushFile(String(year));
	pushFile(THS_BOARD_KLINE_FILE_LAST);
	for (let back = 1; back <= 1; back += 1) pushFile(String(year - back));
	return candidates;
};
/**
* 拉取单个板块的年度日 K（同花顺）
*
* 回退链见 `buildKlineCandidates`（当年/近端/去年的前复权与不复权共 6 个候选），
* 首个解析出行的胜出；同一候选 URL 遇 5xx 网关错误会在原地小步重试一次。
* @param deps 宿主能力集合（http / format / market / ui）
* @param code 板块代码（88xxxx）
* @param year 年份（如 2026）
* @returns 逐日行情（升序）；全部候选都取不到时抛错
*/
var fetchThsBoardKline = async (deps, code, year) => {
	const candidates = buildKlineCandidates(year);
	let lastError = "";
	for (const candidate of candidates) {
		const url = `${THS_BOARD_KLINE_URL_BASE}${code}/${candidate.adjust}/${candidate.file}.js`;
		for (let attempt = 0; attempt < 2; attempt += 1) try {
			const response = await deps.http.fetch(url, { headers: { Referer: THS_REFERER } });
			if (!response.ok) {
				lastError = `HTTP ${response.status}`;
				if (response.status >= 500 && attempt + 1 < 2) {
					await deps.format.delay(500);
					continue;
				}
				break;
			}
			const days = parseKlineJsonp(decodeGbk(await response.arrayBuffer()));
			if (days.length > 0) return days;
			lastError = "空数据";
			break;
		} catch (error) {
			lastError = error instanceof Error ? error.message : String(error);
			break;
		}
	}
	throw new Error(`同花顺板块日K不可用：${code}（${lastError}）`);
};
//#endregion
//#region plugins/dsh-mainline/scan.ts
/**
* 插件 dsh-mainline（股票主线）· 扫描编排
*
* 一次扫描 = 板块清单（清单页 / 本地缓存 / 内置兜底）+ 沪深成交额 + 每板块日 K
* + 基准日涨停池 → 统一按**基准交易日**截面落库。
*
* 数据源策略（L2.5 简化版，见 `.ai/开发方案/2026-09-18-数据源兜底方案.md`）：
* 1. 板块清单：清单页现取 → 本地缓存（上次成功扫描落库）→ 内置兜底清单。
*    清单页（`q.10jqka.com.cn`）与日线主机（`d.10jqka.com.cn`）是两个域，可以单独故障，
*    所以清单页挂掉**不等于**要换源：仍用缓存清单取同花顺日线，只是缺当日结构快照。
* 2. 日线：一律先按**同花顺**取（单板块失败走同源回退链 last.js / 去年文件 + 本地旧数据）；
* 3. 只有「清单解析出的**全部**板块日线都失败」才判定同花顺整体不可用 → **整表降级东财**
*    （逐板块跨源混排是禁区：接缝处成交额口径会跳变，直接污染量能倍数与占比分位）。
*    切换后两个来源的序列在库里分开存放，同花顺恢复后自动切回且历史不丢。
*
* 频率红线（AGENTS / SERVER_API 硬性要求）：
* - 同花顺：同上游并发 ≤ `MAINLINE_SCAN_CONCURRENCY`（3），连续请求间隔 `MAINLINE_SCAN_DELAY_MS`；
* - 东财：**必须串行**（`EM_SCAN_CONCURRENCY` = 1）且间隔 ≥ `EM_SCAN_DELAY_MS`（突发限速）；
* - 两条路径都**只在用户点击时触发**，不进轮询。
*
* 增量策略：日 K 每次全量重取，与**同源**的本地历史按日期合并去重；
* 结构字段（涨停/宽度/净流入）只可能落在基准日那一行，合并时以保留为默认
* （日 K 不含这些字段，直接覆盖会把上次采到的结构数据抹掉）。
*/
/** 空聚合（涨停池不可用时占位， 为 0 但不会被采用） */
var EMPTY_LIMIT_UP = {
	byCode: /* @__PURE__ */ new Map(),
	unmappedCount: 0,
	unmappedIndustries: [],
	total: 0
};
/**
* 取板块清单：清单页现取 → 本地缓存 → 内置兜底
*
* 三级都失败不可能发生（内置兜底是常量），故本函数不抛错 —— 清单是扫描的**前提**，
* 拿不到清单就没有任何可扫对象，那才是真失败；「清单从哪来」只影响结构指标是否可得。
* @param deps 宿主能力集合（http / format / market / ui）
* @param snapshot 本地快照（提供上次成功扫描缓存的清单）
* @returns 清单解析结果
*/
var resolveBoardRefs = async (deps, snapshot) => {
	try {
		const page = await fetchThsBoardPage(deps);
		return {
			refs: page.refs,
			rows: page.rows,
			refsSource: MAINLINE_REFS_SOURCE.LIVE,
			listError: ""
		};
	} catch (error) {
		const listError = error instanceof Error ? error.message : String(error);
		console.warn("[plugin] dsh-mainline 板块清单页取数失败，改用缓存/内置清单", error);
		if (snapshot.refs.length > 0) return {
			refs: snapshot.refs,
			rows: [],
			refsSource: MAINLINE_REFS_SOURCE.CACHE,
			listError
		};
		return {
			refs: [...MAINLINE_THS_BOARD_FALLBACK],
			rows: [],
			refsSource: MAINLINE_REFS_SOURCE.STATIC,
			listError
		};
	}
};
/**
* 并发拉取全部板块日线（带并发上限与同上游间隔）
*
* 两级容错：
* - 单板块失败不中断整轮（代码记进 failures，上层保留其本地旧序列）；
* - 整轮跑完对失败板块**补采一轮**（网关 502 呈突发簇分布，稍等即自愈）。
* 但「**全部**板块都失败」时不做补采：这是上游整体不可用的信号，补采只是再等一轮，
* 上层会据此决定是否整表降级东财。
* @param deps 宿主能力集合（http / format / market / ui）
* @param options 取数参数
* @returns 合并后的序列、失败清单与最后一条报错
*/
var fetchAllBoardSeries = async (deps, options) => {
	const { refs, existingByCode, source, fetchDays, concurrency, delayMs, retryDelayMs } = options;
	const onProgress = options.onProgress;
	const results = /* @__PURE__ */ new Map();
	const failed = /* @__PURE__ */ new Set();
	let lastError = "";
	let done = 0;
	const runPass = async (passRefs, passDelayMs, reportProgress) => {
		let cursor = 0;
		const worker = async () => {
			while (cursor < passRefs.length) {
				const ref = passRefs[cursor];
				cursor += 1;
				try {
					const incoming = await fetchDays(ref);
					const existing = existingByCode.get(ref.code)?.days ?? [];
					results.set(ref.code, {
						code: ref.code,
						name: ref.name,
						source,
						days: mergeDays(existing, incoming)
					});
					failed.delete(ref.code);
				} catch (error) {
					failed.add(ref.code);
					lastError = error instanceof Error ? error.message : String(error);
					console.warn(`[plugin] dsh-mainline 板块取数失败（${source}）：${ref.code}`, error);
				}
				done += 1;
				if (reportProgress) onProgress?.({
					done,
					total: refs.length
				});
				await deps.format.delay(passDelayMs);
			}
		};
		await Promise.all(Array.from({ length: Math.min(concurrency, passRefs.length) }, () => worker()));
	};
	await runPass(refs, delayMs, true);
	if (failed.size > 0 && failed.size < refs.length) {
		const retryRefs = refs.filter((ref) => failed.has(ref.code));
		await deps.format.delay(retryDelayMs);
		await runPass(retryRefs, retryDelayMs, false);
	}
	const boards = [...results.values()];
	for (const code of failed) {
		const existing = existingByCode.get(code);
		if (existing) boards.push(existing);
	}
	return {
		boards,
		failures: [...failed],
		lastError
	};
};
/**
* 东财整表兜底（L2.5 核心）
*
* 流程：东财板块清单全表 → 名称映射（同花顺 90 → 东财代码）→ 按映射逐板块取日线。
* 映射不上的板块**保留为空序列**（不猜、但也别凭空消失），界面按「东财无同义板块」提示。
* @param deps 宿主能力集合（http / format / market / ui）
* @param refs 同花顺板块清单
* @param year 当前年份
* @param existingByCode 东财来源的本地已有序列
* @param onProgress 进度回调
* @returns 取数结果（清单取数失败会抛错，由上层如实报「兜底也失败」）
*/
var runEmScan = async (deps, refs, year, existingByCode, onProgress) => {
	const { mapped, unmapped } = matchThsToEm(refs, await fetchEmBoardUniverse(deps));
	const snapshots = /* @__PURE__ */ new Map();
	for (const [code, board] of mapped) snapshots.set(code, board);
	const result = await fetchAllBoardSeries(deps, {
		refs: refs.filter((ref) => mapped.has(ref.code)),
		existingByCode,
		source: MAINLINE_SOURCE.EM,
		fetchDays: (ref) => {
			return fetchEmBoardKline(deps, mapped.get(ref.code)?.code ?? "", year);
		},
		concurrency: 1,
		delayMs: EM_SCAN_DELAY_MS,
		retryDelayMs: EM_SCAN_RETRY_DELAY_MS,
		onProgress
	});
	const boards = [...result.boards];
	for (const ref of refs) {
		if (mapped.has(ref.code)) continue;
		boards.push({
			code: ref.code,
			name: ref.name,
			source: MAINLINE_SOURCE.EM,
			days: []
		});
	}
	return {
		...result,
		boards,
		snapshots,
		unmapped
	};
};
/**
* 执行一次主线扫描并落库
* @param repo 快照仓储
* @param snapshot 当前本地快照（提供板块清单缓存与分来源的历史序列）
* @param deps 宿主能力集合（http / format / market / ui）
* @param onProgress 进度回调
* @returns 扫描结果
*/
var runMainlineScan = async (repo, snapshot, deps, onProgress) => {
	const year = (/* @__PURE__ */ new Date()).getFullYear();
	const { refs, rows, refsSource, listError } = await resolveBoardRefs(deps, snapshot);
	const market = (await deps.market.fetchMarketTurnover()).map((item) => ({
		date: item.date,
		totalAmount: item.totalAmount
	}));
	const ths = await fetchAllBoardSeries(deps, {
		refs,
		existingByCode: new Map(repo.seriesFor(MAINLINE_SOURCE.THS).map((series) => [series.code, series])),
		source: MAINLINE_SOURCE.THS,
		fetchDays: (ref) => fetchThsBoardKline(deps, ref.code, year),
		concurrency: 3,
		delayMs: 500,
		retryDelayMs: MAINLINE_SCAN_RETRY_DELAY_MS,
		onProgress
	});
	const thsAllFailed = shouldFallbackToEm(refs.length, ths.failures);
	let boards = ths.boards;
	let failures = ths.failures;
	let snapshots = new Map(rows.map((row) => [row.code, row]));
	let source = MAINLINE_SOURCE.THS;
	let effectiveRefsSource = refsSource;
	let fallbackReason = "";
	let fallbackError = "";
	let emUnmapped = [];
	if (thsAllFailed) {
		const emExisting = new Map(repo.seriesFor(MAINLINE_SOURCE.EM).map((series) => [series.code, series]));
		try {
			const em = await runEmScan(deps, refs, year, emExisting, onProgress);
			boards = em.boards;
			failures = em.failures;
			snapshots = em.snapshots;
			emUnmapped = em.unmapped;
			source = MAINLINE_SOURCE.EM;
			effectiveRefsSource = MAINLINE_REFS_SOURCE.EM;
			fallbackReason = MAINLINE_FALLBACK_REASON.KLINE_ALL_FAILED;
			fallbackError = ths.lastError;
		} catch (error) {
			const emError = error instanceof Error ? error.message : String(error);
			throw new Error(`同花顺整体不可用（${ths.lastError}）；东财兜底取数失败（${emError}）`, { cause: error });
		}
	}
	const benchmark = resolveBenchmark(boards, market, /* @__PURE__ */ new Date());
	const benchmarkDate = benchmark.date;
	const trimmed = trimAfter(boards, benchmarkDate);
	let limitUp = EMPTY_LIMIT_UP;
	let limitUpOk = false;
	if (benchmarkDate.length > 0) try {
		const pool = await fetchLimitUpPool(deps, benchmarkDate);
		if (pool.length > 0) {
			limitUp = aggregateLimitUp(pool, refs);
			limitUpOk = true;
		}
	} catch (error) {
		console.warn("[plugin] dsh-mainline 涨停池取数失败", error);
	}
	const latestMarketDate = market[market.length - 1]?.date ?? "";
	const snapshotMatches = benchmarkDate.length > 0 && benchmark.excludedDate === "" && benchmarkDate === latestMarketDate;
	const structure = {
		snapshots: snapshotMatches ? snapshots : /* @__PURE__ */ new Map(),
		limitUp: limitUpOk ? limitUp.byCode : null
	};
	const enriched = trimmed.map((series) => enrichBenchmarkDay(series, benchmarkDate, structure));
	const benchmarkMarket = market.find((point) => point.date === benchmarkDate) ?? null;
	const meta = {
		scannedAt: Date.now(),
		asOf: benchmarkDate,
		boardCount: enriched.length,
		coverage: benchmark.coverage,
		degraded: benchmark.degraded,
		excludedDate: benchmark.excludedDate,
		marketAmount: benchmarkMarket ? benchmarkMarket.totalAmount : null,
		limitUpTotal: limitUpOk ? limitUp.total : null,
		limitUpUnmapped: limitUpOk ? limitUp.unmappedCount : null,
		structureReady: snapshotMatches || limitUpOk,
		source,
		refsSource: effectiveRefsSource,
		listError,
		fallbackReason,
		fallbackError,
		emUnmapped
	};
	await repo.saveScan(enriched, market, meta);
	return {
		boards: enriched,
		market,
		meta,
		failures,
		degraded: benchmark.degraded,
		structureFailed: !snapshotMatches || !limitUpOk,
		unmappedIndustries: limitUp.unmappedIndustries,
		source,
		refsSource: effectiveRefsSource,
		emUnmapped
	};
};
//#endregion
//#region plugins/dsh-mainline/MainlineBoardView.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1 = { class: "space-y-4" };
var _hoisted_2 = { class: "flex flex-wrap items-start justify-between gap-3" };
var _hoisted_3 = { class: "min-w-0 flex-1" };
var _hoisted_4 = { class: "flex items-center gap-1.5 text-base font-semibold text-text" };
var _hoisted_5 = { class: "mt-1 text-xs leading-relaxed text-text-secondary" };
var _hoisted_6 = { class: "flex shrink-0 items-center gap-2" };
var _hoisted_7 = {
	key: 0,
	class: "text-xs tabular-nums text-text-tertiary"
};
var _hoisted_8 = { class: "mt-3 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-text-tertiary" };
var _hoisted_9 = { class: "inline-flex items-center gap-1" };
var _hoisted_10 = { key: 0 };
var _hoisted_11 = { key: 1 };
var _hoisted_12 = {
	key: 0,
	class: "mt-2 rounded-lg bg-flat-weak px-2 py-1.5 text-xs leading-relaxed text-text-secondary"
};
var _hoisted_13 = {
	key: 1,
	class: "mt-2 rounded-lg bg-primary-weak px-2 py-1.5 text-xs leading-relaxed text-primary"
};
var _hoisted_14 = {
	key: 2,
	class: "mt-2 rounded-lg bg-primary-weak px-2 py-1.5 text-xs text-primary"
};
var _hoisted_15 = {
	key: 3,
	class: "mt-3"
};
var _hoisted_16 = { class: "flex flex-wrap items-center gap-1.5" };
var _hoisted_17 = [
	"aria-pressed",
	"title",
	"onClick"
];
var _hoisted_18 = ["aria-pressed"];
var _hoisted_19 = { class: "mt-1.5 flex flex-wrap items-center gap-x-2 gap-y-1 text-[11px] text-text-tertiary" };
var _hoisted_20 = {
	key: 0,
	class: "tabular-nums"
};
var _hoisted_21 = { key: 2 };
var _hoisted_22 = { key: 0 };
var _hoisted_23 = {
	key: 0,
	class: "pb-4 text-center"
};
var _hoisted_24 = { class: "flex items-center gap-1.5" };
var _hoisted_25 = { class: "text-text" };
var _hoisted_26 = {
	key: 0,
	class: "rounded bg-primary-weak px-1 py-0.5 text-[10px] text-primary"
};
var _hoisted_27 = {
	key: 1,
	class: "rounded bg-primary-weak px-1 py-0.5 text-[10px] text-primary"
};
var _hoisted_28 = {
	key: 2,
	class: "rounded bg-primary-weak px-1 py-0.5 text-[10px] text-primary"
};
var _hoisted_29 = {
	key: 3,
	class: "rounded bg-flat-weak px-1 py-0.5 text-[10px] text-text-tertiary"
};
var _hoisted_30 = { class: "space-y-3" };
var _hoisted_31 = { class: "text-xs leading-relaxed text-text-secondary" };
var _hoisted_32 = { class: "grid grid-cols-2 gap-x-6 gap-y-1.5 text-xs sm:grid-cols-3 md:grid-cols-4" };
var _hoisted_33 = { class: "text-text-tertiary" };
var _hoisted_34 = { class: "tabular-nums text-text" };
var _hoisted_35 = { class: "text-text-tertiary" };
var _hoisted_36 = { class: "tabular-nums text-text" };
var _hoisted_37 = { class: "text-text-tertiary" };
var _hoisted_38 = { class: "text-text-tertiary" };
var _hoisted_39 = { class: "tabular-nums text-text" };
var _hoisted_40 = { class: "text-text-tertiary" };
var _hoisted_41 = { class: "tabular-nums text-text" };
var _hoisted_42 = { class: "text-text-tertiary" };
var _hoisted_43 = { class: "tabular-nums text-text" };
var _hoisted_44 = { class: "text-text-tertiary" };
var _hoisted_45 = { class: "tabular-nums text-text" };
var _hoisted_46 = { class: "text-text-tertiary" };
var _hoisted_47 = { class: "tabular-nums text-text" };
var _hoisted_48 = { class: "text-text-tertiary" };
var _hoisted_49 = { class: "tabular-nums text-text-tertiary" };
var _hoisted_50 = { class: "text-text-tertiary" };
var _hoisted_51 = { class: "tabular-nums text-text" };
var _hoisted_52 = { class: "text-text-tertiary" };
var _hoisted_53 = { class: "text-text-tertiary" };
var _hoisted_54 = { class: "tabular-nums text-text" };
var _hoisted_55 = { class: "text-text-tertiary" };
var _hoisted_56 = { class: "tabular-nums text-text" };
var _hoisted_57 = { class: "text-text-tertiary" };
var _hoisted_58 = { class: "tabular-nums text-text" };
var _hoisted_59 = { class: "text-text-tertiary" };
var _hoisted_60 = { class: "tabular-nums text-text" };
var _hoisted_61 = { class: "text-text-tertiary" };
var _hoisted_62 = { class: "tabular-nums text-text" };
var _hoisted_63 = { class: "text-text-tertiary" };
var _hoisted_64 = { class: "tabular-nums text-text" };
var _hoisted_65 = { class: "text-text-tertiary" };
var _hoisted_66 = { class: "text-text-tertiary" };
var _hoisted_67 = { class: "truncate text-text" };
var _hoisted_68 = { class: "text-text-tertiary" };
var _hoisted_69 = { class: "text-text" };
var _hoisted_70 = { key: 0 };
var _hoisted_71 = { class: "mb-1 text-xs font-medium text-text-secondary" };
var _hoisted_72 = { class: "space-y-1" };
var _hoisted_73 = { class: "space-y-1" };
var _hoisted_74 = { class: "space-y-1" };
var _hoisted_75 = { class: "mt-2 text-xs leading-relaxed text-text-tertiary" };
//#endregion
//#region plugins/dsh-mainline/MainlineBoardView.vue
var MainlineBoardView_default = /* @__PURE__ */ defineComponent({
	__name: "MainlineBoardView",
	props: {
		repo: {},
		deps: {}
	},
	setup(__props) {
		const props = __props;
		/** 宿主格式化服务（模板里写 `format.percent(...)` 比 `deps.format.percent(...)` 好读） */
		const format = props.deps.format;
		/** 是否正在扫描 */
		const scanning = ref(false);
		/** 扫描进度（null = 未进行中） */
		const progress = ref(null);
		/** 取数告警文案（空串 = 无告警） */
		const scanNotice = ref("");
		/** 是否只看主线候选 */
		const candidateOnly = ref(false);
		/** 选中的阶段（多选；空数组 = 不按阶段筛选） */
		const activePhases = ref([]);
		/** 当前展开的板块代码（受控展开行） */
		const expandedKeys = ref([]);
		/** 全部板块判定结论（读快照重算，无网络请求） */
		const verdicts = computed(() => {
			const snapshot = props.repo.snapshot();
			return judgeAll(snapshot.boards, snapshot.market);
		});
		/** 当前筛选条件（候选开关 + 选中阶段） */
		const filterOptions = computed(() => ({
			candidateOnly: candidateOnly.value,
			phases: activePhases.value
		}));
		/** 只应用「候选」这一个条件的结论（作为阶段计数的基数） */
		const candidateFiltered = computed(() => filterVerdicts(verdicts.value, {
			candidateOnly: candidateOnly.value,
			phases: []
		}));
		/**
		* 表格行（候选 + 阶段筛选后）
		*
		* 阶段计数以 `candidateFiltered` 为基数，所以**徽标上的数字就是点下去后的行数**，
		* 不会出现「显示 39 点进去只剩 12」这种对不上的情况。
		*/
		const rows = computed(() => filterVerdicts(verdicts.value, filterOptions.value));
		/** 是否有任一筛选条件生效（决定是否露出「清除筛选」与行数提示） */
		const filterActive = computed(() => isFilterActive(filterOptions.value));
		/**
		* 切换某个阶段的筛选态（多选：再点一次取消该阶段）
		* @param phase 阶段取值
		*/
		const onTogglePhase = (phase) => {
			activePhases.value = togglePhase(activePhases.value, phase);
		};
		/** 清除全部筛选（候选 + 阶段），与「再点一次取消」互为兜底 */
		const onClearFilters = () => {
			candidateOnly.value = false;
			activePhases.value = [];
		};
		/** 扫描元信息 */
		const meta = computed(() => props.repo.snapshot().meta);
		/** 当前数据源（未扫描过默认同花顺；两个来源的序列分开存放，界面永远只看一套） */
		const currentSource = computed(() => props.repo.snapshot().source);
		/** 基准日覆盖率是否降级（没有任何交易日达到覆盖率门槛，已退回覆盖最全的一天） */
		const degraded = computed(() => meta.value?.degraded === true);
		/** 板块清单来源文案（清单页现取 / 本地缓存 / 内置兜底 / 东财） */
		const refsSourceLabel = computed(() => {
			const info = meta.value;
			if (!info) return "";
			return MAINLINE_REFS_SOURCE_LABEL[info.refsSource ?? MAINLINE_REFS_SOURCE.LIVE];
		});
		/** 整表切换数据源的原因文案（空串 = 未切换） */
		const fallbackReasonText = computed(() => {
			const key = meta.value?.fallbackReason;
			if (!key) return "";
			return key in MAINLINE_FALLBACK_REASON_LABEL ? MAINLINE_FALLBACK_REASON_LABEL[key] : key;
		});
		/** 页头数据源提示（切换原因 / 口径差 / 清单降级），空数组 = 一切正常 */
		const sourceNotices = computed(() => {
			const info = meta.value;
			if (!info) return [];
			const notices = [];
			if (info.source === MAINLINE_SOURCE.EM) {
				notices.push({
					tone: "primary",
					text: MAINLINE_FALLBACK_NOTICE(fallbackReasonText.value, info.fallbackError ?? "")
				});
				notices.push({
					tone: "primary",
					text: MAINLINE_EM_CALIBER_NOTICE
				});
				notices.push({
					tone: "flat",
					text: MAINLINE_EM_SLOW_NOTICE
				});
				const unmapped = info.emUnmapped ?? [];
				if (unmapped.length > 0) notices.push({
					tone: "primary",
					text: MAINLINE_EM_UNMAPPED_TEXT(unmapped)
				});
			} else if (info.listError) notices.push({
				tone: "flat",
				text: MAINLINE_LIST_ONLY_NOTICE(info.listError, refsSourceLabel.value)
			});
			return notices;
		});
		/**
		* 各阶段数量统计（看板顶部速览，同时充当阶段筛选开关）
		*
		* 计数基数 = 候选过滤后的结论（不含阶段筛选），这样徽标数字 = 点它之后的行数。
		*/
		const phaseSummary = computed(() => {
			const counts = countByPhase(candidateFiltered.value);
			return MAINLINE_PHASE_LIST.map((phase) => ({
				phase,
				label: MAINLINE_PHASE_LABEL[phase],
				badgeClass: MAINLINE_PHASE_BADGE_CLASS[phase],
				count: counts[phase]
			}));
		});
		/** 表格列配置 */
		const columns = [
			{
				key: "name",
				label: MAINLINE_COLUMN_LABEL.name
			},
			{
				key: "phase",
				label: MAINLINE_COLUMN_LABEL.phase
			},
			{
				key: "change",
				label: MAINLINE_COLUMN_LABEL.change,
				align: "right",
				sortable: true,
				sortValue: (row) => row.metrics.latestChange
			},
			{
				key: "change5",
				label: MAINLINE_COLUMN_LABEL.change5,
				align: "right",
				sortable: true,
				sortValue: (row) => row.metrics.change5
			},
			{
				key: "share",
				label: MAINLINE_COLUMN_LABEL.share,
				align: "right",
				sortable: true,
				sortValue: (row) => row.metrics.turnoverShare
			},
			{
				key: "sharePercentile",
				label: MAINLINE_COLUMN_LABEL.sharePercentile,
				align: "right",
				sortable: true,
				sortValue: (row) => row.metrics.sharePercentile
			},
			{
				key: "amountRatio",
				label: MAINLINE_COLUMN_LABEL.amountRatio,
				align: "right",
				sortable: true,
				sortValue: (row) => row.metrics.amountRatio
			},
			{
				key: "pricePercentile",
				label: MAINLINE_COLUMN_LABEL.pricePercentile,
				align: "right",
				sortable: true,
				sortValue: (row) => row.metrics.pricePercentile
			},
			{
				key: "limitUp",
				label: MAINLINE_COLUMN_LABEL.limitUp,
				align: "right",
				sortable: true,
				sortValue: (row) => row.metrics.limitUpCount
			},
			{
				key: "breadth",
				label: MAINLINE_COLUMN_LABEL.breadth,
				align: "right",
				sortable: true,
				sortValue: (row) => row.metrics.breadth
			},
			{
				key: "netInflow",
				label: MAINLINE_COLUMN_LABEL.netInflow,
				align: "right",
				sortable: true,
				sortValue: (row) => row.metrics.netInflow
			}
		];
		/**
		* 行 key（展开行与排序都用它；带数据源 —— 切换来源时不会复用同一行、把两套口径混着看）
		* @param row 判定结论
		* @returns 行 key
		*/
		const rowKey = (row) => mainlineRowKey(row.metrics.source, row.code);
		/**
		* 该行是否为「兜底模式下东财无同义板块」（映射不上 → 空序列 → 历史样本为 0）
		* @param row 判定结论
		* @returns 是否
		*/
		const isEmUnmapped = (row) => row.metrics.source === MAINLINE_SOURCE.EM && row.metrics.historyDays === 0;
		/**
		* 数据滞后徽标文案
		*
		* 分三种情形：「滞后 N 日」/「无基准日行情」（有序列但基准日缺 bar）/
		* 空串（EM 无同义板块的行由自己的徽标表达，不重复）。
		* @param row 判定结论
		* @returns 徽标文案；不需要展示时为空串
		*/
		const staleBadge = (row) => {
			if (!row.metrics.stale || isEmUnmapped(row)) return "";
			return row.metrics.staleDays > 0 ? MAINLINE_STALE_BADGE(row.metrics.staleDays) : MAINLINE_STALE_NO_BAR_BADGE;
		};
		/**
		* 涨跌幅文案样式（跟全站涨跌色一致）
		* @param value 涨跌幅（%）
		* @returns 文本色类名
		*/
		const changeClass = (value) => props.deps.format.trendClass(props.deps.format.trend(value));
		/**
		* 金额文案样式（净流入等带方向的金额）
		* @param value 金额（元）
		* @returns 文本色类名
		*/
		const amountClass = (value) => value === null || value === 0 ? "text-text-secondary" : props.deps.format.trendClass(props.deps.format.trend(value));
		/**
		* 格式化分位（分位不可得时给「无样本」而不是 0）
		* @param value 分位（0-100）
		* @returns 文案
		*/
		const formatPercentile = (value) => {
			if (value === null || !Number.isFinite(value)) return MAINLINE_NO_SAMPLE_TEXT;
			return `${value.toFixed(1)}%`;
		};
		/**
		* 格式化百分比（占比 / 宽度 / 涨停占比）
		* @param value 百分比值
		* @returns 文案
		*/
		const formatPercentValue = (value) => value === null || !Number.isFinite(value) ? "—" : `${value.toFixed(1)}%`;
		/**
		* 格式化成交占比（%）
		* @param value 成交占比
		* @returns 文案
		*/
		const formatShare = (value) => value === null || !Number.isFinite(value) ? "—" : `${value.toFixed(2)}%`;
		/**
		* 格式化倍数
		* @param value 倍数
		* @returns 文案
		*/
		const formatRatio = (value) => value === null || !Number.isFinite(value) ? "—" : `${value.toFixed(2)}${MAINLINE_DETAIL_UNIT.times}`;
		/**
		* 格式化成交额（元 → 亿元，保留一位）
		* @param value 成交额（元）
		* @returns 文案
		*/
		const formatYuanToYi = (value) => value === null || !Number.isFinite(value) ? "—" : `${(value / YUAN_PER_YI).toFixed(1)}亿`;
		/**
		* 格式化净流入（元 → 亿元，带正负号）
		* @param value 净流入（元）
		* @returns 文案
		*/
		const formatNetInflow = (value) => {
			if (value === null || !Number.isFinite(value)) return "—";
			const yi = value / YUAN_PER_YI;
			return `${yi > 0 ? "+" : ""}${yi.toFixed(1)}亿`;
		};
		/**
		* 格式化涨停列（家数，连板高度到档时补注）
		* @param row 判定结论
		* @returns 文案
		*/
		const formatLimitUp = (row) => {
			const { limitUpCount, maxStreak } = row.metrics;
			if (limitUpCount === null) return "—";
			if (maxStreak !== null && maxStreak >= 3) return `${limitUpCount}${MAINLINE_DETAIL_UNIT.houses}（${maxStreak}${MAINLINE_DETAIL_UNIT.boards}）`;
			return `${limitUpCount}${MAINLINE_DETAIL_UNIT.houses}`;
		};
		/**
		* 格式化家数对（上涨 / 下跌）
		* @param rise 上涨家数
		* @param fall 下跌家数
		* @returns 文案
		*/
		const formatRiseFall = (rise, fall) => rise === null && fall === null ? "—" : `${rise ?? "—"} / ${fall ?? "—"}`;
		/**
		* 扫描时间文案
		* @param value 毫秒时间戳
		* @returns 本地时间文案
		*/
		const formatScannedAt = (value) => new Date(value).toLocaleString("zh-CN");
		/**
		* 阶段徽标配色
		*
		* 之所以包一层而不在模板里直接索引常量：`app:ui.Table` 以 `<component :is>` 渲染后
		* 插槽入参没有类型，模板里 `RECORD[row.phase]` 会被推断成隐式 any 索引；
		* 收进带类型签名的函数后，类型检查照旧生效。
		* @param row 判定结论
		* @returns 徽标类名
		*/
		const phaseBadgeClass = (row) => MAINLINE_PHASE_BADGE_CLASS[row.phase];
		/**
		* 数据源徽标配色
		* @param row 判定结论
		* @returns 徽标类名
		*/
		const sourceBadgeClass = (row) => MAINLINE_SOURCE_BADGE_CLASS[row.metrics.source];
		/**
		* 数据源文案
		* @param row 判定结论
		* @returns 数据源名
		*/
		const sourceLabel = (row) => MAINLINE_SOURCE_LABEL[row.metrics.source];
		/**
		* 置信度文案
		* @param row 判定结论
		* @returns 置信度说明
		*/
		const confidenceLabel = (row) => MAINLINE_CONFIDENCE_LABEL[row.confidence];
		/**
		* 切换某行的展开态
		* @param row 判定结论
		*/
		const onToggleExpand = (row) => {
			const key = rowKey(row);
			expandedKeys.value = expandedKeys.value.includes(key) ? expandedKeys.value.filter((item) => item !== key) : [key];
		};
		/**
		* 触发一次主线扫描（点击触发，不轮询）
		*/
		const onScan = async () => {
			if (scanning.value) return;
			scanning.value = true;
			scanNotice.value = "";
			progress.value = {
				done: 0,
				total: 0
			};
			try {
				const snapshot = props.repo.snapshot();
				const result = await runMainlineScan(props.repo, snapshot, props.deps, (next) => {
					progress.value = next;
				});
				const notices = [];
				if (result.failures.length > 0) notices.push(`有 ${result.failures.length} 个板块取数失败（已保留本地旧数据）：${result.failures.join("、")}`);
				if (result.structureFailed) notices.push(`结构指标（涨停 / 宽度 / 净流入）本期未采集完整${result.unmappedIndustries.length > 0 ? `，未归属行业：${result.unmappedIndustries.join("、")}` : ""}`);
				scanNotice.value = notices.join("；");
			} catch (error) {
				scanNotice.value = `${MAINLINE_SCAN_FAILED}：${error instanceof Error ? error.message : String(error)}`;
			} finally {
				scanning.value = false;
				progress.value = null;
			}
		};
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", _hoisted_1, [
				(openBlock(), createBlock(resolveDynamicComponent(__props.deps.ui.Card), null, {
					default: withCtx(() => [
						createElementVNode("div", _hoisted_2, [createElementVNode("div", _hoisted_3, [createElementVNode("h1", _hoisted_4, [(openBlock(), createBlock(resolveDynamicComponent(__props.deps.ui.Icon), {
							name: unref(MAINLINE_MENU_ICON),
							size: 16
						}, null, 8, ["name"])), createTextVNode(" " + toDisplayString(unref(MAINLINE_PAGE_TITLE)), 1)]), createElementVNode("p", _hoisted_5, toDisplayString(unref(MAINLINE_PAGE_SUBTITLE)), 1)]), createElementVNode("div", _hoisted_6, [progress.value ? (openBlock(), createElementBlock("span", _hoisted_7, toDisplayString(unref(MAINLINE_SCAN_RUNNING)) + " " + toDisplayString(progress.value.done) + "/" + toDisplayString(progress.value.total) + " " + toDisplayString(unref(MAINLINE_SCAN_PROGRESS_SUFFIX)), 1)) : createCommentVNode("v-if", true), (openBlock(), createBlock(resolveDynamicComponent(__props.deps.ui.Button), {
							disabled: scanning.value,
							onClick: onScan
						}, {
							default: withCtx(() => [(openBlock(), createBlock(resolveDynamicComponent(__props.deps.ui.Icon), {
								name: "flame",
								size: 14
							})), createTextVNode(" " + toDisplayString(unref(MAINLINE_SCAN_BUTTON)), 1)]),
							_: 1
						}, 8, ["disabled"]))])]),
						createCommentVNode(" 口径信息：基准交易日是全部指标的截面日，数据源与清单来源一并如实给出 "),
						createElementVNode("div", _hoisted_8, [
							createElementVNode("span", _hoisted_9, [createTextVNode(toDisplayString(unref(MAINLINE_HEADER_LABEL).source) + "： ", 1), createElementVNode("span", { class: normalizeClass(["rounded px-1.5 py-0.5 text-[11px] font-medium", unref(MAINLINE_SOURCE_BADGE_CLASS)[currentSource.value]]) }, toDisplayString(unref(MAINLINE_SOURCE_LABEL)[currentSource.value]), 3)]),
							meta.value ? (openBlock(), createElementBlock("span", _hoisted_10, toDisplayString(unref(MAINLINE_HEADER_LABEL).refsSource) + "：" + toDisplayString(refsSourceLabel.value), 1)) : createCommentVNode("v-if", true),
							createElementVNode("span", null, toDisplayString(unref(MAINLINE_HEADER_LABEL).benchmark) + "：" + toDisplayString(meta.value?.asOf || unref("—")), 1),
							createElementVNode("span", null, toDisplayString(unref(MAINLINE_HEADER_LABEL).coverage) + "：" + toDisplayString(meta.value ? unref(MAINLINE_COVERAGE_TEXT)(meta.value.coverage, meta.value.boardCount) : unref("—")), 1),
							createElementVNode("span", null, toDisplayString(unref(MAINLINE_HEADER_LABEL).boardCount) + "：" + toDisplayString(meta.value?.boardCount ?? 0), 1),
							createElementVNode("span", null, toDisplayString(unref(MAINLINE_HEADER_LABEL).marketAmount) + "：" + toDisplayString(formatYuanToYi(meta.value?.marketAmount ?? null)), 1),
							createElementVNode("span", null, toDisplayString(unref(MAINLINE_HEADER_LABEL).limitUp) + "：" + toDisplayString(meta.value && meta.value.limitUpTotal !== null ? unref(MAINLINE_LIMIT_UP_TEXT)(meta.value.limitUpTotal, meta.value.limitUpUnmapped ?? 0) : unref(MAINLINE_STRUCTURE_UNAVAILABLE)), 1),
							meta.value ? (openBlock(), createElementBlock("span", _hoisted_11, toDisplayString(unref(MAINLINE_HEADER_LABEL).scannedAt) + "：" + toDisplayString(formatScannedAt(meta.value.scannedAt)), 1)) : createCommentVNode("v-if", true)
						]),
						meta.value && meta.value.excludedDate ? (openBlock(), createElementBlock("p", _hoisted_12, toDisplayString(unref(MAINLINE_INTRADAY_NOTICE)(meta.value.excludedDate, meta.value.asOf)), 1)) : createCommentVNode("v-if", true),
						meta.value && degraded.value ? (openBlock(), createElementBlock("p", _hoisted_13, toDisplayString(unref(MAINLINE_DEGRADED_NOTICE)(meta.value.asOf)), 1)) : createCommentVNode("v-if", true),
						createCommentVNode(" 数据源提示：切换原因 / 口径差 / 清单降级，一律显式说明，不静默换源 "),
						(openBlock(true), createElementBlock(Fragment, null, renderList(sourceNotices.value, (notice, index) => {
							return openBlock(), createElementBlock("p", {
								key: `source-${index}`,
								class: normalizeClass(["mt-2 rounded-lg px-2 py-1.5 text-xs leading-relaxed", notice.tone === "primary" ? "bg-primary-weak text-primary" : "bg-flat-weak text-text-secondary"])
							}, toDisplayString(notice.text), 3);
						}), 128)),
						scanNotice.value ? (openBlock(), createElementBlock("p", _hoisted_14, toDisplayString(scanNotice.value), 1)) : createCommentVNode("v-if", true),
						createCommentVNode(" 阶段徽标即筛选开关：数字是「点下去后的行数」，多选，再点一次取消 "),
						verdicts.value.length > 0 ? (openBlock(), createElementBlock("div", _hoisted_15, [createElementVNode("div", _hoisted_16, [(openBlock(true), createElementBlock(Fragment, null, renderList(phaseSummary.value, (item) => {
							return openBlock(), createElementBlock("button", {
								key: item.phase,
								type: "button",
								class: normalizeClass(["pressable rounded-md px-1.5 py-0.5 text-[11px] tabular-nums transition active:scale-95", [item.badgeClass, activePhases.value.includes(item.phase) ? "ring-1 ring-current font-medium" : filterActive.value ? "opacity-50" : ""]]),
								"aria-pressed": activePhases.value.includes(item.phase),
								title: `${unref(MAINLINE_PHASE_FILTER_HINT)}：${item.label}`,
								onClick: ($event) => onTogglePhase(item.phase)
							}, toDisplayString(item.label) + " " + toDisplayString(item.count), 11, _hoisted_17);
						}), 128)), createElementVNode("button", {
							type: "button",
							class: normalizeClass(["pressable ml-1 rounded-md px-1.5 py-0.5 text-[11px] active:scale-95", candidateOnly.value ? "bg-primary-weak text-primary" : "bg-flat-weak text-text-secondary"]),
							"aria-pressed": candidateOnly.value,
							onClick: _cache[0] || (_cache[0] = ($event) => candidateOnly.value = !candidateOnly.value)
						}, toDisplayString(unref(MAINLINE_CANDIDATE_BADGE)) + toDisplayString(candidateOnly.value ? "（已筛选）" : ` ${verdicts.value.filter((item) => item.candidate).length}`), 11, _hoisted_18)]), createElementVNode("div", _hoisted_19, [filterActive.value ? (openBlock(), createElementBlock("span", _hoisted_20, toDisplayString(unref(MAINLINE_FILTER_SUMMARY)(rows.value.length, verdicts.value.length)), 1)) : createCommentVNode("v-if", true), filterActive.value ? (openBlock(), createElementBlock("button", {
							key: 1,
							type: "button",
							class: "pressable rounded px-1 py-0.5 text-primary active:scale-95",
							onClick: onClearFilters
						}, toDisplayString(unref(MAINLINE_FILTER_CLEAR)), 1)) : (openBlock(), createElementBlock("span", _hoisted_21, toDisplayString(unref(MAINLINE_PHASE_FILTER_HINT)), 1))])])) : createCommentVNode("v-if", true)
					]),
					_: 1
				})),
				(openBlock(), createBlock(resolveDynamicComponent(__props.deps.ui.Card), { title: unref(MAINLINE_DETAIL_TITLE) }, {
					extra: withCtx(() => [..._cache[1] || (_cache[1] = [createElementVNode("span", { class: "text-xs text-text-tertiary" }, "点行首箭头看原始指标与风险提示", -1)])]),
					default: withCtx(() => [rows.value.length === 0 ? (openBlock(), createElementBlock("div", _hoisted_22, [(openBlock(), createBlock(resolveDynamicComponent(__props.deps.ui.Empty), { text: verdicts.value.length === 0 ? unref(MAINLINE_EMPTY_TEXT) : unref(MAINLINE_FILTER_EMPTY_TEXT) }, null, 8, ["text"])), verdicts.value.length > 0 && filterActive.value ? (openBlock(), createElementBlock("p", _hoisted_23, [createElementVNode("button", {
						type: "button",
						class: "pressable rounded-md bg-primary-weak px-2 py-1 text-xs text-primary active:scale-95",
						onClick: onClearFilters
					}, toDisplayString(unref(MAINLINE_FILTER_CLEAR)), 1)])) : createCommentVNode("v-if", true)])) : (openBlock(), createBlock(resolveDynamicComponent(__props.deps.ui.Table), {
						key: 1,
						columns,
						rows: rows.value,
						"row-key": rowKey,
						"row-clickable": true,
						expandable: true,
						"expanded-keys": expandedKeys.value,
						"min-width": "1080px",
						onRowClick: onToggleExpand,
						onToggleExpand
					}, {
						name: withCtx(({ row }) => [createElementVNode("span", _hoisted_24, [
							createElementVNode("span", _hoisted_25, toDisplayString(row.name), 1),
							row.candidate ? (openBlock(), createElementBlock("span", _hoisted_26, toDisplayString(unref(MAINLINE_CANDIDATE_BADGE)), 1)) : createCommentVNode("v-if", true),
							row.structureHot ? (openBlock(), createElementBlock("span", _hoisted_27, toDisplayString(unref(MAINLINE_STRUCTURE_HOT_BADGE)), 1)) : createCommentVNode("v-if", true),
							isEmUnmapped(row) ? (openBlock(), createElementBlock("span", _hoisted_28, toDisplayString(unref(MAINLINE_EM_UNMAPPED_BADGE)), 1)) : createCommentVNode("v-if", true),
							staleBadge(row) ? (openBlock(), createElementBlock("span", _hoisted_29, toDisplayString(staleBadge(row)), 1)) : createCommentVNode("v-if", true)
						])]),
						phase: withCtx(({ row }) => [createElementVNode("span", { class: normalizeClass(["rounded-md px-1.5 py-0.5 text-[11px] font-medium", phaseBadgeClass(row)]) }, toDisplayString(row.phaseLabel), 3)]),
						change: withCtx(({ row }) => [createElementVNode("span", { class: normalizeClass(changeClass(row.metrics.latestChange)) }, toDisplayString(unref(format).percent(row.metrics.latestChange)), 3)]),
						change5: withCtx(({ row }) => [createElementVNode("span", { class: normalizeClass(changeClass(row.metrics.change5)) }, toDisplayString(unref(format).percent(row.metrics.change5)), 3)]),
						share: withCtx(({ row }) => [createTextVNode(toDisplayString(formatShare(row.metrics.turnoverShare)), 1)]),
						sharePercentile: withCtx(({ row }) => [createTextVNode(toDisplayString(formatPercentile(row.metrics.sharePercentile)), 1)]),
						amountRatio: withCtx(({ row }) => [createTextVNode(toDisplayString(formatRatio(row.metrics.amountRatio)), 1)]),
						pricePercentile: withCtx(({ row }) => [createTextVNode(toDisplayString(formatPercentile(row.metrics.pricePercentile)), 1)]),
						limitUp: withCtx(({ row }) => [createTextVNode(toDisplayString(formatLimitUp(row)), 1)]),
						breadth: withCtx(({ row }) => [createTextVNode(toDisplayString(formatPercentValue(row.metrics.breadth)), 1)]),
						netInflow: withCtx(({ row }) => [createElementVNode("span", { class: normalizeClass(amountClass(row.metrics.netInflow)) }, toDisplayString(formatNetInflow(row.metrics.netInflow)), 3)]),
						expanded: withCtx(({ row }) => [createElementVNode("div", _hoisted_30, [
							createElementVNode("p", _hoisted_31, toDisplayString(row.phaseDesc), 1),
							createElementVNode("dl", _hoisted_32, [
								createElementVNode("div", null, [createElementVNode("dt", _hoisted_33, toDisplayString(unref(MAINLINE_DETAIL_LABEL).asOf), 1), createElementVNode("dd", _hoisted_34, toDisplayString(row.metrics.asOf || "—"), 1)]),
								createElementVNode("div", null, [createElementVNode("dt", _hoisted_35, toDisplayString(unref(MAINLINE_DETAIL_LABEL).benchmark), 1), createElementVNode("dd", _hoisted_36, toDisplayString(row.metrics.benchmarkDate || "—"), 1)]),
								createElementVNode("div", null, [createElementVNode("dt", _hoisted_37, toDisplayString(unref(MAINLINE_DETAIL_LABEL).source), 1), createElementVNode("dd", null, [createElementVNode("span", { class: normalizeClass(["rounded px-1 py-0.5 text-[10px]", sourceBadgeClass(row)]) }, toDisplayString(sourceLabel(row)), 3)])]),
								createElementVNode("div", null, [createElementVNode("dt", _hoisted_38, toDisplayString(unref(MAINLINE_DETAIL_LABEL).historyDays), 1), createElementVNode("dd", _hoisted_39, toDisplayString(row.metrics.historyDays) + toDisplayString(unref(MAINLINE_DETAIL_UNIT).days), 1)]),
								createElementVNode("div", null, [createElementVNode("dt", _hoisted_40, toDisplayString(unref(MAINLINE_DETAIL_LABEL).amount), 1), createElementVNode("dd", _hoisted_41, toDisplayString(formatYuanToYi(row.metrics.amount)), 1)]),
								createElementVNode("div", null, [createElementVNode("dt", _hoisted_42, toDisplayString(unref(MAINLINE_DETAIL_LABEL).turnoverShare), 1), createElementVNode("dd", _hoisted_43, toDisplayString(formatShare(row.metrics.turnoverShare)), 1)]),
								createElementVNode("div", null, [createElementVNode("dt", _hoisted_44, toDisplayString(unref(MAINLINE_DETAIL_LABEL).sharePercentile), 1), createElementVNode("dd", _hoisted_45, toDisplayString(formatPercentile(row.metrics.sharePercentile)), 1)]),
								createElementVNode("div", null, [createElementVNode("dt", _hoisted_46, toDisplayString(unref(MAINLINE_DETAIL_LABEL).amountRatio), 1), createElementVNode("dd", _hoisted_47, toDisplayString(formatRatio(row.metrics.amountRatio)), 1)]),
								createElementVNode("div", null, [createElementVNode("dt", _hoisted_48, toDisplayString(unref(MAINLINE_DETAIL_LABEL).amountRatioOverlap), 1), createElementVNode("dd", _hoisted_49, toDisplayString(formatRatio(row.metrics.amountRatioOverlap)), 1)]),
								createElementVNode("div", null, [createElementVNode("dt", _hoisted_50, toDisplayString(unref(MAINLINE_DETAIL_LABEL).pricePercentile), 1), createElementVNode("dd", _hoisted_51, toDisplayString(formatPercentile(row.metrics.pricePercentile)), 1)]),
								createElementVNode("div", null, [createElementVNode("dt", _hoisted_52, toDisplayString(unref(MAINLINE_DETAIL_LABEL).change20), 1), createElementVNode("dd", { class: normalizeClass(["tabular-nums", changeClass(row.metrics.change20)]) }, toDisplayString(unref(format).percent(row.metrics.change20)), 3)]),
								createElementVNode("div", null, [createElementVNode("dt", _hoisted_53, toDisplayString(unref(MAINLINE_DETAIL_LABEL).limitUpCount), 1), createElementVNode("dd", _hoisted_54, toDisplayString(formatLimitUp(row)), 1)]),
								createElementVNode("div", null, [createElementVNode("dt", _hoisted_55, toDisplayString(unref(MAINLINE_DETAIL_LABEL).maxStreak), 1), createElementVNode("dd", _hoisted_56, toDisplayString(row.metrics.maxStreak === null ? unref("—") : `${row.metrics.maxStreak}${unref(MAINLINE_DETAIL_UNIT).boards}`), 1)]),
								createElementVNode("div", null, [createElementVNode("dt", _hoisted_57, toDisplayString(unref(MAINLINE_DETAIL_LABEL).sealFund), 1), createElementVNode("dd", _hoisted_58, toDisplayString(formatYuanToYi(row.metrics.sealFund)), 1)]),
								createElementVNode("div", null, [createElementVNode("dt", _hoisted_59, toDisplayString(unref(MAINLINE_DETAIL_LABEL).limitUpRatio), 1), createElementVNode("dd", _hoisted_60, toDisplayString(formatPercentValue(row.metrics.limitUpRatio)), 1)]),
								createElementVNode("div", null, [createElementVNode("dt", _hoisted_61, toDisplayString(unref(MAINLINE_DETAIL_LABEL).riseFall), 1), createElementVNode("dd", _hoisted_62, toDisplayString(formatRiseFall(row.metrics.riseCount, row.metrics.fallCount)), 1)]),
								createElementVNode("div", null, [createElementVNode("dt", _hoisted_63, toDisplayString(unref(MAINLINE_DETAIL_LABEL).breadth), 1), createElementVNode("dd", _hoisted_64, toDisplayString(formatPercentValue(row.metrics.breadth)), 1)]),
								createElementVNode("div", null, [createElementVNode("dt", _hoisted_65, toDisplayString(unref(MAINLINE_DETAIL_LABEL).netInflow), 1), createElementVNode("dd", { class: normalizeClass(["tabular-nums", amountClass(row.metrics.netInflow)]) }, toDisplayString(formatNetInflow(row.metrics.netInflow)), 3)]),
								createElementVNode("div", null, [createElementVNode("dt", _hoisted_66, toDisplayString(unref(MAINLINE_DETAIL_LABEL).leader), 1), createElementVNode("dd", _hoisted_67, toDisplayString(row.metrics.leaderName || unref("—")), 1)]),
								createElementVNode("div", null, [createElementVNode("dt", _hoisted_68, toDisplayString(unref(MAINLINE_DETAIL_LABEL).confidence), 1), createElementVNode("dd", _hoisted_69, toDisplayString(confidenceLabel(row)), 1)])
							]),
							row.warnings.length > 0 ? (openBlock(), createElementBlock("div", _hoisted_70, [createElementVNode("p", _hoisted_71, toDisplayString(unref(MAINLINE_WARNING_TITLE)), 1), createElementVNode("ul", _hoisted_72, [(openBlock(true), createElementBlock(Fragment, null, renderList(row.warnings, (warning, index) => {
								return openBlock(), createElementBlock("li", {
									key: index,
									class: "flex gap-1.5 text-xs leading-relaxed text-text-secondary"
								}, [_cache[2] || (_cache[2] = createElementVNode("span", { class: "text-text-tertiary" }, "•", -1)), createElementVNode("span", null, toDisplayString(warning), 1)]);
							}), 128))])])) : createCommentVNode("v-if", true)
						])]),
						_: 1
					}, 40, ["rows", "expanded-keys"]))]),
					_: 1
				}, 8, ["title"])),
				(openBlock(), createBlock(resolveDynamicComponent(__props.deps.ui.Card), { title: unref(MAINLINE_CONNECTED_TITLE) }, {
					default: withCtx(() => [createElementVNode("ul", _hoisted_73, [(openBlock(true), createElementBlock(Fragment, null, renderList(unref(MAINLINE_CONNECTED_INPUTS), (item, index) => {
						return openBlock(), createElementBlock("li", {
							key: index,
							class: "flex gap-1.5 text-xs leading-relaxed text-text-secondary"
						}, [_cache[3] || (_cache[3] = createElementVNode("span", { class: "text-text-tertiary" }, "•", -1)), createElementVNode("span", null, toDisplayString(item), 1)]);
					}), 128))])]),
					_: 1
				}, 8, ["title"])),
				(openBlock(), createBlock(resolveDynamicComponent(__props.deps.ui.Card), { title: unref(MAINLINE_MISSING_TITLE) }, {
					default: withCtx(() => [createElementVNode("ul", _hoisted_74, [(openBlock(true), createElementBlock(Fragment, null, renderList(unref(MAINLINE_MISSING_INPUTS), (item, index) => {
						return openBlock(), createElementBlock("li", {
							key: index,
							class: "flex gap-1.5 text-xs leading-relaxed text-text-secondary"
						}, [_cache[4] || (_cache[4] = createElementVNode("span", { class: "text-text-tertiary" }, "•", -1)), createElementVNode("span", null, toDisplayString(item), 1)]);
					}), 128))]), createElementVNode("p", _hoisted_75, toDisplayString(unref(MAINLINE_DISCLAIMER)), 1)]),
					_: 1
				}, 8, ["title"]))
			]);
		};
	}
});
//#endregion
//#region plugins/dsh-mainline/storage.ts
/**
* 插件 dsh-mainline（股票主线）· 本地快照仓储
*
* 两张表（插件独立表，落 `plugin_dsh_mainline_*`；Tauri 端 SQLite / 浏览器端 appStorage 仿真）：
* - `board_history`：每板块**每数据源**一行，日线序列整体存 `json` 列 ——
*   一次扫描最多写 90 行（避免「一年 × 90 板块」上万行的逐条插入），
*   读出来即可本地重算分位与阶段，不联网；
* - `scan_meta`：键值行，存扫描元信息、沪深成交额序列、**同花顺板块清单缓存**。
*
* ⚠️ 两个数据源（同花顺 / 东财）的序列**分开存放、永不拼接**：
* 行唯一键是 `来源:板块代码`，水合与 upsert 都必须用同形键 ——
* 否则要么误把另一来源的行当重复行删掉，要么重启后首扫整批重复插入。
*
* 与技能的 `snapshot` 设计同源：**分位序列靠自己累积**，样本不足时判定层如实降置信度。
*/
/** 板块历史表名（物理表 `plugin_dsh_mainline_board_history`） */
var MAINLINE_BOARD_TABLE = "board_history";
/** 扫描元信息表名（物理表 `plugin_dsh_mainline_scan_meta`） */
var MAINLINE_META_TABLE = "scan_meta";
/** 扫描元信息在表里的键 */
var MAINLINE_META_KEY = "last_scan";
/** 沪深成交额序列在表里的键 */
var MAINLINE_MARKET_KEY = "market_turnover";
/** 同花顺板块清单缓存在表里的键（清单页故障时用它继续取同花顺日线） */
var MAINLINE_REFS_KEY = "board_refs";
/**
* 板块历史表的列声明
*
* ⚠️ 只声明**业务列**：`id` / `created_at` / `updated_at` 由宿主自动维护并固定写进建表语句，
* 插件重复声明会让建表语句出现两个同名列（SQLite 报 `duplicate column name`）——
* 宿主已在 `toColumnMap` 里拒绝保留列，冒烟也用真 SQLite 执行过一次建表。
*/
var MAINLINE_BOARD_COLUMNS = [
	{
		name: "board_code",
		type: "text",
		indexed: true
	},
	{
		name: "board_name",
		type: "text"
	},
	{
		name: "source",
		type: "text",
		indexed: true
	},
	{
		name: "days",
		type: "json"
	}
];
/** 扫描元信息表的列声明（键值行，同样只声明业务列） */
var MAINLINE_META_COLUMNS = [{
	name: "meta_key",
	type: "text",
	indexed: true
}, {
	name: "meta_value",
	type: "json"
}];
/**
* 行内数据源（早于来源标记的历史行按同花顺处理）
* @param value 库里的来源字段
* @returns 数据源
*/
var toSource = (value) => value === MAINLINE_SOURCE.EM ? MAINLINE_SOURCE.EM : MAINLINE_SOURCE.THS;
/**
* 把库里读出的 json 值还原成日线序列（脏数据一律过滤成空序列）
* @param value json 列值
* @returns 日线序列（升序）
*/
var parseDays = (value) => {
	if (!Array.isArray(value)) return [];
	return value.filter((item) => typeof item === "object" && item !== null && typeof item.date === "string" && Number.isFinite(item.close));
};
/**
* 把库里读出的 json 值还原成板块清单（脏数据一律过滤）
* @param value json 列值
* @returns 板块清单
*/
var parseRefs = (value) => {
	if (!Array.isArray(value)) return [];
	return value.filter((item) => typeof item === "object" && item !== null && typeof item.code === "string" && typeof item.name === "string");
};
/**
* 建表并水合快照
* @param db 插件通用数据库（`ctx.db`）
* @returns 主题快照仓储
*/
var createMainlineRepo = async (db) => {
	await db.ensureTable(MAINLINE_BOARD_TABLE, MAINLINE_BOARD_COLUMNS);
	await db.ensureTable(MAINLINE_META_TABLE, MAINLINE_META_COLUMNS);
	const boards = ref({
		[MAINLINE_SOURCE.THS]: [],
		[MAINLINE_SOURCE.EM]: []
	});
	const market = ref([]);
	const meta = ref(null);
	const refs = ref([]);
	/** `来源:板块代码` → 数据表行主键（upsert 定位） */
	const rowIds = /* @__PURE__ */ new Map();
	const boardRows = await db.select(MAINLINE_BOARD_TABLE, { orderBy: { column: "board_code" } });
	const newestByKey = /* @__PURE__ */ new Map();
	const redundantIds = [];
	for (const row of boardRows) {
		if (!row.board_code) continue;
		const key = `${toSource(row.source)}:${row.board_code}`;
		const current = newestByKey.get(key);
		if (!current) {
			newestByKey.set(key, row);
			continue;
		}
		const keep = row.updatedAt >= current.updatedAt ? row : current;
		redundantIds.push(keep === row ? current.id : row.id);
		newestByKey.set(key, keep);
	}
	for (const id of redundantIds) await db.remove(MAINLINE_BOARD_TABLE, id);
	for (const row of newestByKey.values()) {
		const source = toSource(row.source);
		rowIds.set(`${MAINLINE_BOARD_TABLE}:${source}:${row.board_code}`, row.id);
		boards.value[source].push({
			code: row.board_code,
			name: row.board_name || row.board_code,
			source,
			days: parseDays(row.days)
		});
	}
	const metaRows = await db.select(MAINLINE_META_TABLE, { orderBy: { column: "meta_key" } });
	const newestMetaByKey = /* @__PURE__ */ new Map();
	const redundantMetaIds = [];
	for (const row of metaRows) {
		if (!row.meta_key) continue;
		const current = newestMetaByKey.get(row.meta_key);
		if (!current) {
			newestMetaByKey.set(row.meta_key, row);
			continue;
		}
		const keep = row.updatedAt >= current.updatedAt ? row : current;
		redundantMetaIds.push(keep === row ? current.id : row.id);
		newestMetaByKey.set(row.meta_key, keep);
	}
	for (const id of redundantMetaIds) await db.remove(MAINLINE_META_TABLE, id);
	for (const row of newestMetaByKey.values()) {
		rowIds.set(`${MAINLINE_META_TABLE}:${row.meta_key}`, row.id);
		if (row.meta_key === "last_scan" && row.meta_value && typeof row.meta_value === "object") meta.value = row.meta_value;
		if (row.meta_key === MAINLINE_MARKET_KEY && Array.isArray(row.meta_value)) market.value = row.meta_value;
		if (row.meta_key === MAINLINE_REFS_KEY) refs.value = parseRefs(row.meta_value);
	}
	/**
	* 写一行（存在则更新，不存在则插入并登记主键）
	* @param table 表名
	* @param key 业务键
	* @param columns 列值
	*/
	const upsert = async (table, key, columns) => {
		const lookupKey = `${table}:${key}`;
		const id = rowIds.get(lookupKey);
		if (id === void 0) {
			rowIds.set(lookupKey, await db.insert(table, columns));
			return;
		}
		await db.update(table, id, columns);
	};
	/**
	* 写元信息表的某个键（存在则更新 meta_value，不存在则插入）
	* @param key 元信息键
	* @param value 元信息值（json 列）
	*/
	const upsertMeta = async (key, value) => {
		await upsert(MAINLINE_META_TABLE, key, {
			meta_key: key,
			meta_value: value
		});
	};
	return {
		snapshot: () => {
			const source = toSource(meta.value?.source);
			return {
				boards: boards.value[source],
				market: market.value,
				meta: meta.value,
				refs: refs.value,
				source
			};
		},
		seriesFor: (source) => boards.value[source],
		saveScan: async (nextBoards, nextMarket, nextMeta) => {
			const source = toSource(nextMeta.source);
			for (const series of nextBoards) {
				const days = series.days.slice(-260);
				await upsert(MAINLINE_BOARD_TABLE, `${source}:${series.code}`, {
					board_code: series.code,
					board_name: series.name,
					source,
					days
				});
			}
			await upsertMeta(MAINLINE_MARKET_KEY, nextMarket);
			await upsertMeta(MAINLINE_META_KEY, nextMeta);
			if (source === MAINLINE_SOURCE.THS && nextBoards.length > 0) {
				const nextRefs = nextBoards.map((series) => ({
					code: series.code,
					name: series.name
				}));
				refs.value = nextRefs;
				await upsertMeta(MAINLINE_REFS_KEY, nextRefs);
			}
			boards.value = {
				...boards.value,
				[source]: nextBoards.map((series) => ({
					...series,
					source,
					days: series.days.slice(-260)
				}))
			};
			market.value = nextMarket;
			meta.value = nextMeta;
		}
	};
};
//#endregion
//#region plugins/dsh-mainline/plugin.ts
/**
* 插件 dsh-mainline（股票主线）
*
* 左侧导航新增「股票主线」页面：把「板块抱团主线」从主观感觉变成状态判定 ——
* 一线四阶段（萌芽 / 确认 / 狂热 / 瓦解）+ 原始指标面板（成交占比分位、量能倍数、
* 价格分位），口径参考本地技能 `a-share-huddle-mainline`，数据源换成本应用可直连的
* 同花顺板块日 K + 腾讯沪深成交额。
*
* 硬约束（技能三条铁律，界面已落实）：
* 1. 只输出阶段标签与风险提示，不出现任何买卖 / 仓位指令；
* 2. 只有价格上涨、没有业绩验证不判「确认抱团」——「确认」仅代表量价与拥挤度特征，
*    风险提示里明写「需连续两季业绩验证」；
* 3. 原始指标面板与自动标签**同时展示**，并列出本期未接入的输入。
*
* 数据落地：`ctx.db` 两张插件表（`board_history` / `scan_meta`），
* 扫描一次后重进页面只读库重算，不联网；重接口只在用户点击时触发。
*/
/**
* 股票主线插件定义
*/
var mainlinePlugin = {
	id: MAINLINE_PLUGIN_ID,
	name: "股票主线",
	version: "1.0.0",
	description: "左侧导航新增「股票主线」看板：同花顺行业板块成交占比分位 / 量能倍数 / 价格分位 → 抱团主线四阶段（萌芽·确认·狂热·瓦解）判定，只给阶段与风险提示，不含买卖指令。",
	author: "内置",
	apply: async (ctx) => {
		const http = ctx.consume("app:http");
		const format = ctx.consume("app:format");
		const market = ctx.consume("app:market");
		const ui = ctx.consume("app:ui");
		if (!http || !format || !market || !ui) throw new Error("宿主未提供 app:http / app:format / app:market / app:ui 服务");
		const deps = {
			http,
			format,
			market,
			ui
		};
		const repo = await createMainlineRepo(ctx.db);
		ctx.provide("mainline:repo", repo);
		ctx.menu.add({
			path: MAINLINE_MENU_PATH,
			title: MAINLINE_MENU_TITLE,
			icon: MAINLINE_MENU_ICON,
			component: MainlineBoardView_default,
			props: {
				repo,
				deps
			}
		});
		ctx.logger.info("已注册「股票主线」导航项与看板页面");
	}
};
//#endregion
export { mainlinePlugin as default, mainlinePlugin };
