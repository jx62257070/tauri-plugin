const __WHF_PLUGIN_RUNTIME__ = globalThis.__WHF_PLUGIN_RUNTIME__;
if (!__WHF_PLUGIN_RUNTIME__?.vue) {
  throw new Error('宿主运行时桥不可用：__WHF_PLUGIN_RUNTIME__（插件必须在该版本宿主里安装）');
}
const { Fragment, computed, createBlock, createCommentVNode, createElementBlock, createElementVNode, createTextVNode, createVNode, defineComponent, getCurrentInstance, h, isRef, nextTick, normalizeClass, onMounted, onUnmounted, openBlock, reactive, ref, renderList, resolveDynamicComponent, toDisplayString, toRefs, unref, vModelSelect, vModelText, watch, withCtx, withDirectives, withModifiers } = __WHF_PLUGIN_RUNTIME__.vue;
//#region node_modules/.pnpm/vue-draggable-plus@0.6.1_@types+sortablejs@1.15.9/node_modules/vue-draggable-plus/dist/vue-draggable-plus.js
var an = Object.defineProperty;
var Pe = Object.getOwnPropertySymbols;
var yt = Object.prototype.hasOwnProperty;
var wt = Object.prototype.propertyIsEnumerable;
var bt = (t, e, n) => e in t ? an(t, e, {
	enumerable: !0,
	configurable: !0,
	writable: !0,
	value: n
}) : t[e] = n;
var fe = (t, e) => {
	for (var n in e || (e = {})) yt.call(e, n) && bt(t, n, e[n]);
	if (Pe) for (var n of Pe(e)) wt.call(e, n) && bt(t, n, e[n]);
	return t;
};
var $e = (t, e) => {
	var n = {};
	for (var o in t) yt.call(t, o) && e.indexOf(o) < 0 && (n[o] = t[o]);
	if (t != null && Pe) for (var o of Pe(t)) e.indexOf(o) < 0 && wt.call(t, o) && (n[o] = t[o]);
	return n;
};
var Ht = "[vue-draggable-plus]: ";
function mn(t) {
	console.warn(Ht + t);
}
function vn(t) {
	console.error(Ht + t);
}
function St(t, e, n) {
	return n >= 0 && n < t.length && t.splice(n, 0, t.splice(e, 1)[0]), t;
}
function bn(t) {
	return t.replace(/-(\w)/g, (e, n) => n ? n.toUpperCase() : "");
}
function yn(t) {
	return Object.keys(t).reduce((e, n) => (typeof t[n] != "undefined" && (e[bn(n)] = t[n]), e), {});
}
function Dt(t, e) {
	return Array.isArray(t) && t.splice(e, 1), t;
}
function _t(t, e, n) {
	return Array.isArray(t) && t.splice(e, 0, n), t;
}
function wn(t) {
	return typeof t == "undefined";
}
function En(t) {
	return typeof t == "string";
}
function Tt(t, e, n) {
	const o = t.children[n];
	t.insertBefore(e, o);
}
function Ke(t) {
	t.parentNode && t.parentNode.removeChild(t);
}
function Sn(t, e = document) {
	var o;
	let n = null;
	return typeof (e == null ? void 0 : e.querySelector) == "function" ? n = (o = e == null ? void 0 : e.querySelector) == null ? void 0 : o.call(e, t) : n = document.querySelector(t), n || mn(`Element not found: ${t}`), n;
}
function Dn(t, e, n = null) {
	return function(...o) {
		return t.apply(n, o), e.apply(n, o);
	};
}
function _n(t, e) {
	const n = fe({}, t);
	return Object.keys(e).forEach((o) => {
		n[o] ? n[o] = Dn(t[o], e[o]) : n[o] = e[o];
	}), n;
}
function Tn(t) {
	return t instanceof HTMLElement;
}
function Ct(t, e) {
	Object.keys(t).forEach((n) => {
		e(n, t[n]);
	});
}
function Cn(t) {
	return t.charCodeAt(0) === 111 && t.charCodeAt(1) === 110 && (t.charCodeAt(2) > 122 || t.charCodeAt(2) < 97);
}
var On = Object.assign;
/**!
* Sortable 1.15.2
* @author	RubaXa   <trash@rubaxa.org>
* @author	owenm    <owen23355@gmail.com>
* @license MIT
*/
function Ot(t, e) {
	var n = Object.keys(t);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(t);
		e && (o = o.filter(function(r) {
			return Object.getOwnPropertyDescriptor(t, r).enumerable;
		})), n.push.apply(n, o);
	}
	return n;
}
function ne(t) {
	for (var e = 1; e < arguments.length; e++) {
		var n = arguments[e] != null ? arguments[e] : {};
		e % 2 ? Ot(Object(n), !0).forEach(function(o) {
			In(t, o, n[o]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : Ot(Object(n)).forEach(function(o) {
			Object.defineProperty(t, o, Object.getOwnPropertyDescriptor(n, o));
		});
	}
	return t;
}
function Ye(t) {
	"@babel/helpers - typeof";
	return typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? Ye = function(e) {
		return typeof e;
	} : Ye = function(e) {
		return e && typeof Symbol == "function" && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
	}, Ye(t);
}
function In(t, e, n) {
	return e in t ? Object.defineProperty(t, e, {
		value: n,
		enumerable: !0,
		configurable: !0,
		writable: !0
	}) : t[e] = n, t;
}
function ie() {
	return ie = Object.assign || function(t) {
		for (var e = 1; e < arguments.length; e++) {
			var n = arguments[e];
			for (var o in n) Object.prototype.hasOwnProperty.call(n, o) && (t[o] = n[o]);
		}
		return t;
	}, ie.apply(this, arguments);
}
function An(t, e) {
	if (t == null) return {};
	var n = {}, o = Object.keys(t), r, i = 0;
	for (; i < o.length; i++) r = o[i], !(e.indexOf(r) >= 0) && (n[r] = t[r]);
	return n;
}
function xn(t, e) {
	if (t == null) return {};
	var n = An(t, e), o, r;
	if (Object.getOwnPropertySymbols) {
		var i = Object.getOwnPropertySymbols(t);
		for (r = 0; r < i.length; r++) o = i[r], !(e.indexOf(o) >= 0) && Object.prototype.propertyIsEnumerable.call(t, o) && (n[o] = t[o]);
	}
	return n;
}
var Nn = "1.15.2";
function re(t) {
	if (typeof window != "undefined" && window.navigator) return !!/* @__PURE__ */ navigator.userAgent.match(t);
}
var ae = re(/(?:Trident.*rv[ :]?11\.|msie|iemobile|Windows Phone)/i);
var xe = re(/Edge/i);
var It = re(/firefox/i);
var Te = re(/safari/i) && !re(/chrome/i) && !re(/android/i);
var Lt = re(/iP(ad|od|hone)/i);
var Wt = re(/chrome/i) && re(/android/i);
var Gt = {
	capture: !1,
	passive: !1
};
function S(t, e, n) {
	t.addEventListener(e, n, !ae && Gt);
}
function E(t, e, n) {
	t.removeEventListener(e, n, !ae && Gt);
}
function We(t, e) {
	if (e) {
		if (e[0] === ">" && (e = e.substring(1)), t) try {
			if (t.matches) return t.matches(e);
			if (t.msMatchesSelector) return t.msMatchesSelector(e);
			if (t.webkitMatchesSelector) return t.webkitMatchesSelector(e);
		} catch (n) {
			return !1;
		}
		return !1;
	}
}
function Pn(t) {
	return t.host && t !== document && t.host.nodeType ? t.host : t.parentNode;
}
function Q(t, e, n, o) {
	if (t) {
		n = n || document;
		do {
			if (e != null && (e[0] === ">" ? t.parentNode === n && We(t, e) : We(t, e)) || o && t === n) return t;
			if (t === n) break;
		} while (t = Pn(t));
	}
	return null;
}
var At = /\s+/g;
function V(t, e, n) {
	if (t && e) if (t.classList) t.classList[n ? "add" : "remove"](e);
	else t.className = ((" " + t.className + " ").replace(At, " ").replace(" " + e + " ", " ") + (n ? " " + e : "")).replace(At, " ");
}
function h$1(t, e, n) {
	var o = t && t.style;
	if (o) {
		if (n === void 0) return document.defaultView && document.defaultView.getComputedStyle ? n = document.defaultView.getComputedStyle(t, "") : t.currentStyle && (n = t.currentStyle), e === void 0 ? n : n[e];
		!(e in o) && e.indexOf("webkit") === -1 && (e = "-webkit-" + e), o[e] = n + (typeof n == "string" ? "" : "px");
	}
}
function ye(t, e) {
	var n = "";
	if (typeof t == "string") n = t;
	else do {
		var o = h$1(t, "transform");
		o && o !== "none" && (n = o + " " + n);
	} while (!e && (t = t.parentNode));
	var r = window.DOMMatrix || window.WebKitCSSMatrix || window.CSSMatrix || window.MSCSSMatrix;
	return r && new r(n);
}
function jt(t, e, n) {
	if (t) {
		var o = t.getElementsByTagName(e), r = 0, i = o.length;
		if (n) for (; r < i; r++) n(o[r], r);
		return o;
	}
	return [];
}
function te() {
	return document.scrollingElement || document.documentElement;
}
function P(t, e, n, o, r) {
	if (!(!t.getBoundingClientRect && t !== window)) {
		var i, a, l, s, u, d, f;
		if (t !== window && t.parentNode && t !== te() ? (i = t.getBoundingClientRect(), a = i.top, l = i.left, s = i.bottom, u = i.right, d = i.height, f = i.width) : (a = 0, l = 0, s = window.innerHeight, u = window.innerWidth, d = window.innerHeight, f = window.innerWidth), (e || n) && t !== window && (r = r || t.parentNode, !ae)) do
			if (r && r.getBoundingClientRect && (h$1(r, "transform") !== "none" || n && h$1(r, "position") !== "static")) {
				var m = r.getBoundingClientRect();
				a -= m.top + parseInt(h$1(r, "border-top-width")), l -= m.left + parseInt(h$1(r, "border-left-width")), s = a + i.height, u = l + i.width;
				break;
			}
		while (r = r.parentNode);
		if (o && t !== window) {
			var y = ye(r || t), b = y && y.a, w = y && y.d;
			y && (a /= w, l /= b, f /= b, d /= w, s = a + d, u = l + f);
		}
		return {
			top: a,
			left: l,
			bottom: s,
			right: u,
			width: f,
			height: d
		};
	}
}
function xt(t, e, n) {
	for (var o = ce(t, !0), r = P(t)[e]; o;) {
		var i = P(o)[n], a = void 0;
		if (a = r >= i, !a) return o;
		if (o === te()) break;
		o = ce(o, !1);
	}
	return !1;
}
function we(t, e, n, o) {
	for (var r = 0, i = 0, a = t.children; i < a.length;) {
		if (a[i].style.display !== "none" && a[i] !== p.ghost && (o || a[i] !== p.dragged) && Q(a[i], n.draggable, t, !1)) {
			if (r === e) return a[i];
			r++;
		}
		i++;
	}
	return null;
}
function ht(t, e) {
	for (var n = t.lastElementChild; n && (n === p.ghost || h$1(n, "display") === "none" || e && !We(n, e));) n = n.previousElementSibling;
	return n || null;
}
function J(t, e) {
	var n = 0;
	if (!t || !t.parentNode) return -1;
	for (; t = t.previousElementSibling;) t.nodeName.toUpperCase() !== "TEMPLATE" && t !== p.clone && (!e || We(t, e)) && n++;
	return n;
}
function Nt(t) {
	var e = 0, n = 0, o = te();
	if (t) do {
		var r = ye(t), i = r.a, a = r.d;
		e += t.scrollLeft * i, n += t.scrollTop * a;
	} while (t !== o && (t = t.parentNode));
	return [e, n];
}
function Mn(t, e) {
	for (var n in t) if (t.hasOwnProperty(n)) {
		for (var o in e) if (e.hasOwnProperty(o) && e[o] === t[n][o]) return Number(n);
	}
	return -1;
}
function ce(t, e) {
	if (!t || !t.getBoundingClientRect) return te();
	var n = t, o = !1;
	do
		if (n.clientWidth < n.scrollWidth || n.clientHeight < n.scrollHeight) {
			var r = h$1(n);
			if (n.clientWidth < n.scrollWidth && (r.overflowX == "auto" || r.overflowX == "scroll") || n.clientHeight < n.scrollHeight && (r.overflowY == "auto" || r.overflowY == "scroll")) {
				if (!n.getBoundingClientRect || n === document.body) return te();
				if (o || e) return n;
				o = !0;
			}
		}
	while (n = n.parentNode);
	return te();
}
function Fn(t, e) {
	if (t && e) for (var n in e) e.hasOwnProperty(n) && (t[n] = e[n]);
	return t;
}
function Je(t, e) {
	return Math.round(t.top) === Math.round(e.top) && Math.round(t.left) === Math.round(e.left) && Math.round(t.height) === Math.round(e.height) && Math.round(t.width) === Math.round(e.width);
}
var Ce;
function zt(t, e) {
	return function() {
		if (!Ce) {
			var n = arguments, o = this;
			n.length === 1 ? t.call(o, n[0]) : t.apply(o, n), Ce = setTimeout(function() {
				Ce = void 0;
			}, e);
		}
	};
}
function Rn() {
	clearTimeout(Ce), Ce = void 0;
}
function Ut(t, e, n) {
	t.scrollLeft += e, t.scrollTop += n;
}
function Vt(t) {
	var e = window.Polymer, n = window.jQuery || window.Zepto;
	return e && e.dom ? e.dom(t).cloneNode(!0) : n ? n(t).clone(!0)[0] : t.cloneNode(!0);
}
function $t(t, e, n) {
	var o = {};
	return Array.from(t.children).forEach(function(r) {
		var i, a, l, s;
		if (!(!Q(r, e.draggable, t, !1) || r.animated || r === n)) {
			var u = P(r);
			o.left = Math.min((i = o.left) !== null && i !== void 0 ? i : 1 / 0, u.left), o.top = Math.min((a = o.top) !== null && a !== void 0 ? a : 1 / 0, u.top), o.right = Math.max((l = o.right) !== null && l !== void 0 ? l : -1 / 0, u.right), o.bottom = Math.max((s = o.bottom) !== null && s !== void 0 ? s : -1 / 0, u.bottom);
		}
	}), o.width = o.right - o.left, o.height = o.bottom - o.top, o.x = o.left, o.y = o.top, o;
}
var q = "Sortable" + (/* @__PURE__ */ new Date()).getTime();
function Xn() {
	var t = [], e;
	return {
		captureAnimationState: function() {
			if (t = [], !!this.options.animation) [].slice.call(this.el.children).forEach(function(r) {
				if (!(h$1(r, "display") === "none" || r === p.ghost)) {
					t.push({
						target: r,
						rect: P(r)
					});
					var i = ne({}, t[t.length - 1].rect);
					if (r.thisAnimationDuration) {
						var a = ye(r, !0);
						a && (i.top -= a.f, i.left -= a.e);
					}
					r.fromRect = i;
				}
			});
		},
		addAnimationState: function(o) {
			t.push(o);
		},
		removeAnimationState: function(o) {
			t.splice(Mn(t, { target: o }), 1);
		},
		animateAll: function(o) {
			var r = this;
			if (!this.options.animation) {
				clearTimeout(e), typeof o == "function" && o();
				return;
			}
			var i = !1, a = 0;
			t.forEach(function(l) {
				var s = 0, u = l.target, d = u.fromRect, f = P(u), m = u.prevFromRect, y = u.prevToRect, b = l.rect, w = ye(u, !0);
				w && (f.top -= w.f, f.left -= w.e), u.toRect = f, u.thisAnimationDuration && Je(m, f) && !Je(d, f) && (b.top - f.top) / (b.left - f.left) === (d.top - f.top) / (d.left - f.left) && (s = Bn(b, m, y, r.options)), Je(f, d) || (u.prevFromRect = d, u.prevToRect = f, s || (s = r.options.animation), r.animate(u, b, f, s)), s && (i = !0, a = Math.max(a, s), clearTimeout(u.animationResetTimer), u.animationResetTimer = setTimeout(function() {
					u.animationTime = 0, u.prevFromRect = null, u.fromRect = null, u.prevToRect = null, u.thisAnimationDuration = null;
				}, s), u.thisAnimationDuration = s);
			}), clearTimeout(e), i ? e = setTimeout(function() {
				typeof o == "function" && o();
			}, a) : typeof o == "function" && o(), t = [];
		},
		animate: function(o, r, i, a) {
			if (a) {
				h$1(o, "transition", ""), h$1(o, "transform", "");
				var l = ye(this.el), s = l && l.a, u = l && l.d, d = (r.left - i.left) / (s || 1), f = (r.top - i.top) / (u || 1);
				o.animatingX = !!d, o.animatingY = !!f, h$1(o, "transform", "translate3d(" + d + "px," + f + "px,0)"), this.forRepaintDummy = Yn(o), h$1(o, "transition", "transform " + a + "ms" + (this.options.easing ? " " + this.options.easing : "")), h$1(o, "transform", "translate3d(0,0,0)"), typeof o.animated == "number" && clearTimeout(o.animated), o.animated = setTimeout(function() {
					h$1(o, "transition", ""), h$1(o, "transform", ""), o.animated = !1, o.animatingX = !1, o.animatingY = !1;
				}, a);
			}
		}
	};
}
function Yn(t) {
	return t.offsetWidth;
}
function Bn(t, e, n, o) {
	return Math.sqrt(Math.pow(e.top - t.top, 2) + Math.pow(e.left - t.left, 2)) / Math.sqrt(Math.pow(e.top - n.top, 2) + Math.pow(e.left - n.left, 2)) * o.animation;
}
var ge = [];
var Ze = { initializeByDefault: !0 };
var Ne = {
	mount: function(e) {
		for (var n in Ze) Ze.hasOwnProperty(n) && !(n in e) && (e[n] = Ze[n]);
		ge.forEach(function(o) {
			if (o.pluginName === e.pluginName) throw "Sortable: Cannot mount plugin ".concat(e.pluginName, " more than once");
		}), ge.push(e);
	},
	pluginEvent: function(e, n, o) {
		var r = this;
		this.eventCanceled = !1, o.cancel = function() {
			r.eventCanceled = !0;
		};
		var i = e + "Global";
		ge.forEach(function(a) {
			n[a.pluginName] && (n[a.pluginName][i] && n[a.pluginName][i](ne({ sortable: n }, o)), n.options[a.pluginName] && n[a.pluginName][e] && n[a.pluginName][e](ne({ sortable: n }, o)));
		});
	},
	initializePlugins: function(e, n, o, r) {
		ge.forEach(function(l) {
			var s = l.pluginName;
			if (!(!e.options[s] && !l.initializeByDefault)) {
				var u = new l(e, n, e.options);
				u.sortable = e, u.options = e.options, e[s] = u, ie(o, u.defaults);
			}
		});
		for (var i in e.options) if (e.options.hasOwnProperty(i)) {
			var a = this.modifyOption(e, i, e.options[i]);
			typeof a != "undefined" && (e.options[i] = a);
		}
	},
	getEventProperties: function(e, n) {
		var o = {};
		return ge.forEach(function(r) {
			typeof r.eventProperties == "function" && ie(o, r.eventProperties.call(n[r.pluginName], e));
		}), o;
	},
	modifyOption: function(e, n, o) {
		var r;
		return ge.forEach(function(i) {
			e[i.pluginName] && i.optionListeners && typeof i.optionListeners[n] == "function" && (r = i.optionListeners[n].call(e[i.pluginName], o));
		}), r;
	}
};
function kn(t) {
	var e = t.sortable, n = t.rootEl, o = t.name, r = t.targetEl, i = t.cloneEl, a = t.toEl, l = t.fromEl, s = t.oldIndex, u = t.newIndex, d = t.oldDraggableIndex, f = t.newDraggableIndex, m = t.originalEvent, y = t.putSortable, b = t.extraEventProperties;
	if (e = e || n && n[q], !!e) {
		var w, L = e.options, G = "on" + o.charAt(0).toUpperCase() + o.substr(1);
		window.CustomEvent && !ae && !xe ? w = new CustomEvent(o, {
			bubbles: !0,
			cancelable: !0
		}) : (w = document.createEvent("Event"), w.initEvent(o, !0, !0)), w.to = a || n, w.from = l || n, w.item = r || n, w.clone = i, w.oldIndex = s, w.newIndex = u, w.oldDraggableIndex = d, w.newDraggableIndex = f, w.originalEvent = m, w.pullMode = y ? y.lastPutMode : void 0;
		var R = ne(ne({}, b), Ne.getEventProperties(o, e));
		for (var j in R) w[j] = R[j];
		n && n.dispatchEvent(w), L[G] && L[G].call(e, w);
	}
}
var Hn = ["evt"];
var z = function(e, n) {
	var o = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : {}, r = o.evt, i = xn(o, Hn);
	Ne.pluginEvent.bind(p)(e, n, ne({
		dragEl: c,
		parentEl: O,
		ghostEl: g,
		rootEl: T,
		nextEl: pe,
		lastDownEl: Be,
		cloneEl: C,
		cloneHidden: ue,
		dragStarted: Se,
		putSortable: Y,
		activeSortable: p.active,
		originalEvent: r,
		oldIndex: be,
		oldDraggableIndex: Oe,
		newIndex: $,
		newDraggableIndex: se,
		hideGhostForTarget: Zt,
		unhideGhostForTarget: Qt,
		cloneNowHidden: function() {
			ue = !0;
		},
		cloneNowShown: function() {
			ue = !1;
		},
		dispatchSortableEvent: function(l) {
			W({
				sortable: n,
				name: l,
				originalEvent: r
			});
		}
	}, i));
};
function W(t) {
	kn(ne({
		putSortable: Y,
		cloneEl: C,
		targetEl: c,
		rootEl: T,
		oldIndex: be,
		oldDraggableIndex: Oe,
		newIndex: $,
		newDraggableIndex: se
	}, t));
}
var c;
var O;
var g;
var T;
var pe;
var Be;
var C;
var ue;
var be;
var $;
var Oe;
var se;
var Me;
var Y;
var ve = !1;
var Ge = !1;
var je = [];
var de;
var Z;
var Qe;
var et;
var Pt;
var Mt;
var Se;
var me;
var Ie;
var Ae = !1;
var Fe = !1;
var ke;
var H;
var tt = [];
var lt = !1;
var ze = [];
var Ve = typeof document != "undefined";
var Re = Lt;
var Ft = xe || ae ? "cssFloat" : "float";
var Ln = Ve && !Wt && !Lt && "draggable" in document.createElement("div");
var qt = function() {
	if (Ve) {
		if (ae) return !1;
		var t = document.createElement("x");
		return t.style.cssText = "pointer-events:auto", t.style.pointerEvents === "auto";
	}
}();
var Kt = function(e, n) {
	var o = h$1(e), r = parseInt(o.width) - parseInt(o.paddingLeft) - parseInt(o.paddingRight) - parseInt(o.borderLeftWidth) - parseInt(o.borderRightWidth), i = we(e, 0, n), a = we(e, 1, n), l = i && h$1(i), s = a && h$1(a), u = l && parseInt(l.marginLeft) + parseInt(l.marginRight) + P(i).width, d = s && parseInt(s.marginLeft) + parseInt(s.marginRight) + P(a).width;
	if (o.display === "flex") return o.flexDirection === "column" || o.flexDirection === "column-reverse" ? "vertical" : "horizontal";
	if (o.display === "grid") return o.gridTemplateColumns.split(" ").length <= 1 ? "vertical" : "horizontal";
	if (i && l.float && l.float !== "none") {
		var f = l.float === "left" ? "left" : "right";
		return a && (s.clear === "both" || s.clear === f) ? "vertical" : "horizontal";
	}
	return i && (l.display === "block" || l.display === "flex" || l.display === "table" || l.display === "grid" || u >= r && o[Ft] === "none" || a && o[Ft] === "none" && u + d > r) ? "vertical" : "horizontal";
};
var Wn = function(e, n, o) {
	var r = o ? e.left : e.top, i = o ? e.right : e.bottom, a = o ? e.width : e.height, l = o ? n.left : n.top, s = o ? n.right : n.bottom, u = o ? n.width : n.height;
	return r === l || i === s || r + a / 2 === l + u / 2;
};
var Gn = function(e, n) {
	var o;
	return je.some(function(r) {
		var i = r[q].options.emptyInsertThreshold;
		if (!(!i || ht(r))) {
			var a = P(r), l = e >= a.left - i && e <= a.right + i, s = n >= a.top - i && n <= a.bottom + i;
			if (l && s) return o = r;
		}
	}), o;
};
var Jt = function(e) {
	function n(i, a) {
		return function(l, s, u, d) {
			var f = l.options.group.name && s.options.group.name && l.options.group.name === s.options.group.name;
			if (i == null && (a || f)) return !0;
			if (i == null || i === !1) return !1;
			if (a && i === "clone") return i;
			if (typeof i == "function") return n(i(l, s, u, d), a)(l, s, u, d);
			var m = (a ? l : s).options.group.name;
			return i === !0 || typeof i == "string" && i === m || i.join && i.indexOf(m) > -1;
		};
	}
	var o = {}, r = e.group;
	(!r || Ye(r) != "object") && (r = { name: r }), o.name = r.name, o.checkPull = n(r.pull, !0), o.checkPut = n(r.put), o.revertClone = r.revertClone, e.group = o;
};
var Zt = function() {
	!qt && g && h$1(g, "display", "none");
};
var Qt = function() {
	!qt && g && h$1(g, "display", "");
};
Ve && !Wt && document.addEventListener("click", function(t) {
	if (Ge) return t.preventDefault(), t.stopPropagation && t.stopPropagation(), t.stopImmediatePropagation && t.stopImmediatePropagation(), Ge = !1, !1;
}, !0);
var he = function(e) {
	if (c) {
		e = e.touches ? e.touches[0] : e;
		var n = Gn(e.clientX, e.clientY);
		if (n) {
			var o = {};
			for (var r in e) e.hasOwnProperty(r) && (o[r] = e[r]);
			o.target = o.rootEl = n, o.preventDefault = void 0, o.stopPropagation = void 0, n[q]._onDragOver(o);
		}
	}
};
var jn = function(e) {
	c && c.parentNode[q]._isOutsideThisEl(e.target);
};
function p(t, e) {
	if (!(t && t.nodeType && t.nodeType === 1)) throw "Sortable: `el` must be an HTMLElement, not ".concat({}.toString.call(t));
	this.el = t, this.options = e = ie({}, e), t[q] = this;
	var n = {
		group: null,
		sort: !0,
		disabled: !1,
		store: null,
		handle: null,
		draggable: /^[uo]l$/i.test(t.nodeName) ? ">li" : ">*",
		swapThreshold: 1,
		invertSwap: !1,
		invertedSwapThreshold: null,
		removeCloneOnHide: !0,
		direction: function() {
			return Kt(t, this.options);
		},
		ghostClass: "sortable-ghost",
		chosenClass: "sortable-chosen",
		dragClass: "sortable-drag",
		ignore: "a, img",
		filter: null,
		preventOnFilter: !0,
		animation: 0,
		easing: null,
		setData: function(a, l) {
			a.setData("Text", l.textContent);
		},
		dropBubble: !1,
		dragoverBubble: !1,
		dataIdAttr: "data-id",
		delay: 0,
		delayOnTouchOnly: !1,
		touchStartThreshold: (Number.parseInt ? Number : window).parseInt(window.devicePixelRatio, 10) || 1,
		forceFallback: !1,
		fallbackClass: "sortable-fallback",
		fallbackOnBody: !1,
		fallbackTolerance: 0,
		fallbackOffset: {
			x: 0,
			y: 0
		},
		supportPointer: p.supportPointer !== !1 && "PointerEvent" in window && !Te,
		emptyInsertThreshold: 5
	};
	Ne.initializePlugins(this, t, n);
	for (var o in n) !(o in e) && (e[o] = n[o]);
	Jt(e);
	for (var r in this) r.charAt(0) === "_" && typeof this[r] == "function" && (this[r] = this[r].bind(this));
	this.nativeDraggable = e.forceFallback ? !1 : Ln, this.nativeDraggable && (this.options.touchStartThreshold = 1), e.supportPointer ? S(t, "pointerdown", this._onTapStart) : (S(t, "mousedown", this._onTapStart), S(t, "touchstart", this._onTapStart)), this.nativeDraggable && (S(t, "dragover", this), S(t, "dragenter", this)), je.push(this.el), e.store && e.store.get && this.sort(e.store.get(this) || []), ie(this, Xn());
}
p.prototype = {
	constructor: p,
	_isOutsideThisEl: function(e) {
		!this.el.contains(e) && e !== this.el && (me = null);
	},
	_getDirection: function(e, n) {
		return typeof this.options.direction == "function" ? this.options.direction.call(this, e, n, c) : this.options.direction;
	},
	_onTapStart: function(e) {
		if (e.cancelable) {
			var n = this, o = this.el, r = this.options, i = r.preventOnFilter, a = e.type, l = e.touches && e.touches[0] || e.pointerType && e.pointerType === "touch" && e, s = (l || e).target, u = e.target.shadowRoot && (e.path && e.path[0] || e.composedPath && e.composedPath()[0]) || s, d = r.filter;
			if (Zn(o), !c && !(/mousedown|pointerdown/.test(a) && e.button !== 0 || r.disabled) && !u.isContentEditable && !(!this.nativeDraggable && Te && s && s.tagName.toUpperCase() === "SELECT") && (s = Q(s, r.draggable, o, !1), !(s && s.animated) && Be !== s)) {
				if (be = J(s), Oe = J(s, r.draggable), typeof d == "function") {
					if (d.call(this, e, s, this)) {
						W({
							sortable: n,
							rootEl: u,
							name: "filter",
							targetEl: s,
							toEl: o,
							fromEl: o
						}), z("filter", n, { evt: e }), i && e.cancelable && e.preventDefault();
						return;
					}
				} else if (d && (d = d.split(",").some(function(f) {
					if (f = Q(u, f.trim(), o, !1), f) return W({
						sortable: n,
						rootEl: f,
						name: "filter",
						targetEl: s,
						fromEl: o,
						toEl: o
					}), z("filter", n, { evt: e }), !0;
				}), d)) {
					i && e.cancelable && e.preventDefault();
					return;
				}
				r.handle && !Q(u, r.handle, o, !1) || this._prepareDragStart(e, l, s);
			}
		}
	},
	_prepareDragStart: function(e, n, o) {
		var r = this, i = r.el, a = r.options, l = i.ownerDocument, s;
		if (o && !c && o.parentNode === i) {
			var u = P(o);
			if (T = i, c = o, O = c.parentNode, pe = c.nextSibling, Be = o, Me = a.group, p.dragged = c, de = {
				target: c,
				clientX: (n || e).clientX,
				clientY: (n || e).clientY
			}, Pt = de.clientX - u.left, Mt = de.clientY - u.top, this._lastX = (n || e).clientX, this._lastY = (n || e).clientY, c.style["will-change"] = "all", s = function() {
				if (z("delayEnded", r, { evt: e }), p.eventCanceled) {
					r._onDrop();
					return;
				}
				r._disableDelayedDragEvents(), !It && r.nativeDraggable && (c.draggable = !0), r._triggerDragStart(e, n), W({
					sortable: r,
					name: "choose",
					originalEvent: e
				}), V(c, a.chosenClass, !0);
			}, a.ignore.split(",").forEach(function(d) {
				jt(c, d.trim(), nt);
			}), S(l, "dragover", he), S(l, "mousemove", he), S(l, "touchmove", he), S(l, "mouseup", r._onDrop), S(l, "touchend", r._onDrop), S(l, "touchcancel", r._onDrop), It && this.nativeDraggable && (this.options.touchStartThreshold = 4, c.draggable = !0), z("delayStart", this, { evt: e }), a.delay && (!a.delayOnTouchOnly || n) && (!this.nativeDraggable || !(xe || ae))) {
				if (p.eventCanceled) {
					this._onDrop();
					return;
				}
				S(l, "mouseup", r._disableDelayedDrag), S(l, "touchend", r._disableDelayedDrag), S(l, "touchcancel", r._disableDelayedDrag), S(l, "mousemove", r._delayedDragTouchMoveHandler), S(l, "touchmove", r._delayedDragTouchMoveHandler), a.supportPointer && S(l, "pointermove", r._delayedDragTouchMoveHandler), r._dragStartTimer = setTimeout(s, a.delay);
			} else s();
		}
	},
	_delayedDragTouchMoveHandler: function(e) {
		var n = e.touches ? e.touches[0] : e;
		Math.max(Math.abs(n.clientX - this._lastX), Math.abs(n.clientY - this._lastY)) >= Math.floor(this.options.touchStartThreshold / (this.nativeDraggable && window.devicePixelRatio || 1)) && this._disableDelayedDrag();
	},
	_disableDelayedDrag: function() {
		c && nt(c), clearTimeout(this._dragStartTimer), this._disableDelayedDragEvents();
	},
	_disableDelayedDragEvents: function() {
		var e = this.el.ownerDocument;
		E(e, "mouseup", this._disableDelayedDrag), E(e, "touchend", this._disableDelayedDrag), E(e, "touchcancel", this._disableDelayedDrag), E(e, "mousemove", this._delayedDragTouchMoveHandler), E(e, "touchmove", this._delayedDragTouchMoveHandler), E(e, "pointermove", this._delayedDragTouchMoveHandler);
	},
	_triggerDragStart: function(e, n) {
		n = n || e.pointerType == "touch" && e, !this.nativeDraggable || n ? this.options.supportPointer ? S(document, "pointermove", this._onTouchMove) : n ? S(document, "touchmove", this._onTouchMove) : S(document, "mousemove", this._onTouchMove) : (S(c, "dragend", this), S(T, "dragstart", this._onDragStart));
		try {
			document.selection ? He(function() {
				document.selection.empty();
			}) : window.getSelection().removeAllRanges();
		} catch (o) {}
	},
	_dragStarted: function(e, n) {
		if (ve = !1, T && c) {
			z("dragStarted", this, { evt: n }), this.nativeDraggable && S(document, "dragover", jn);
			var o = this.options;
			!e && V(c, o.dragClass, !1), V(c, o.ghostClass, !0), p.active = this, e && this._appendGhost(), W({
				sortable: this,
				name: "start",
				originalEvent: n
			});
		} else this._nulling();
	},
	_emulateDragOver: function() {
		if (Z) {
			this._lastX = Z.clientX, this._lastY = Z.clientY, Zt();
			for (var e = document.elementFromPoint(Z.clientX, Z.clientY), n = e; e && e.shadowRoot && (e = e.shadowRoot.elementFromPoint(Z.clientX, Z.clientY), e !== n);) n = e;
			if (c.parentNode[q]._isOutsideThisEl(e), n) do {
				if (n[q]) {
					var o = void 0;
					if (o = n[q]._onDragOver({
						clientX: Z.clientX,
						clientY: Z.clientY,
						target: e,
						rootEl: n
					}), o && !this.options.dragoverBubble) break;
				}
				e = n;
			} while (n = n.parentNode);
			Qt();
		}
	},
	_onTouchMove: function(e) {
		if (de) {
			var n = this.options, o = n.fallbackTolerance, r = n.fallbackOffset, i = e.touches ? e.touches[0] : e, a = g && ye(g, !0), l = g && a && a.a, s = g && a && a.d, u = Re && H && Nt(H), d = (i.clientX - de.clientX + r.x) / (l || 1) + (u ? u[0] - tt[0] : 0) / (l || 1), f = (i.clientY - de.clientY + r.y) / (s || 1) + (u ? u[1] - tt[1] : 0) / (s || 1);
			if (!p.active && !ve) {
				if (o && Math.max(Math.abs(i.clientX - this._lastX), Math.abs(i.clientY - this._lastY)) < o) return;
				this._onDragStart(e, !0);
			}
			if (g) {
				a ? (a.e += d - (Qe || 0), a.f += f - (et || 0)) : a = {
					a: 1,
					b: 0,
					c: 0,
					d: 1,
					e: d,
					f
				};
				var m = "matrix(".concat(a.a, ",").concat(a.b, ",").concat(a.c, ",").concat(a.d, ",").concat(a.e, ",").concat(a.f, ")");
				h$1(g, "webkitTransform", m), h$1(g, "mozTransform", m), h$1(g, "msTransform", m), h$1(g, "transform", m), Qe = d, et = f, Z = i;
			}
			e.cancelable && e.preventDefault();
		}
	},
	_appendGhost: function() {
		if (!g) {
			var e = this.options.fallbackOnBody ? document.body : T, n = P(c, !0, Re, !0, e), o = this.options;
			if (Re) {
				for (H = e; h$1(H, "position") === "static" && h$1(H, "transform") === "none" && H !== document;) H = H.parentNode;
				H !== document.body && H !== document.documentElement ? (H === document && (H = te()), n.top += H.scrollTop, n.left += H.scrollLeft) : H = te(), tt = Nt(H);
			}
			g = c.cloneNode(!0), V(g, o.ghostClass, !1), V(g, o.fallbackClass, !0), V(g, o.dragClass, !0), h$1(g, "transition", ""), h$1(g, "transform", ""), h$1(g, "box-sizing", "border-box"), h$1(g, "margin", 0), h$1(g, "top", n.top), h$1(g, "left", n.left), h$1(g, "width", n.width), h$1(g, "height", n.height), h$1(g, "opacity", "0.8"), h$1(g, "position", Re ? "absolute" : "fixed"), h$1(g, "zIndex", "100000"), h$1(g, "pointerEvents", "none"), p.ghost = g, e.appendChild(g), h$1(g, "transform-origin", Pt / parseInt(g.style.width) * 100 + "% " + Mt / parseInt(g.style.height) * 100 + "%");
		}
	},
	_onDragStart: function(e, n) {
		var o = this, r = e.dataTransfer, i = o.options;
		if (z("dragStart", this, { evt: e }), p.eventCanceled) {
			this._onDrop();
			return;
		}
		z("setupClone", this), p.eventCanceled || (C = Vt(c), C.removeAttribute("id"), C.draggable = !1, C.style["will-change"] = "", this._hideClone(), V(C, this.options.chosenClass, !1), p.clone = C), o.cloneId = He(function() {
			z("clone", o), !p.eventCanceled && (o.options.removeCloneOnHide || T.insertBefore(C, c), o._hideClone(), W({
				sortable: o,
				name: "clone"
			}));
		}), !n && V(c, i.dragClass, !0), n ? (Ge = !0, o._loopId = setInterval(o._emulateDragOver, 50)) : (E(document, "mouseup", o._onDrop), E(document, "touchend", o._onDrop), E(document, "touchcancel", o._onDrop), r && (r.effectAllowed = "move", i.setData && i.setData.call(o, r, c)), S(document, "drop", o), h$1(c, "transform", "translateZ(0)")), ve = !0, o._dragStartId = He(o._dragStarted.bind(o, n, e)), S(document, "selectstart", o), Se = !0, Te && h$1(document.body, "user-select", "none");
	},
	_onDragOver: function(e) {
		var n = this.el, o = e.target, r, i, a, l = this.options, s = l.group, u = p.active, d = Me === s, f = l.sort, m = Y || u, y, b = this, w = !1;
		if (lt) return;
		function L(ee, Ee) {
			z(ee, b, ne({
				evt: e,
				isOwner: d,
				axis: y ? "vertical" : "horizontal",
				revert: a,
				dragRect: r,
				targetRect: i,
				canSort: f,
				fromSortable: m,
				target: o,
				completed: R,
				onMove: function(vt, rn) {
					return Xe(T, n, c, r, vt, P(vt), e, rn);
				},
				changed: j
			}, Ee));
		}
		function G() {
			L("dragOverAnimationCapture"), b.captureAnimationState(), b !== m && m.captureAnimationState();
		}
		function R(ee) {
			return L("dragOverCompleted", { insertion: ee }), ee && (d ? u._hideClone() : u._showClone(b), b !== m && (V(c, Y ? Y.options.ghostClass : u.options.ghostClass, !1), V(c, l.ghostClass, !0)), Y !== b && b !== p.active ? Y = b : b === p.active && Y && (Y = null), m === b && (b._ignoreWhileAnimating = o), b.animateAll(function() {
				L("dragOverAnimationComplete"), b._ignoreWhileAnimating = null;
			}), b !== m && (m.animateAll(), m._ignoreWhileAnimating = null)), (o === c && !c.animated || o === n && !o.animated) && (me = null), !l.dragoverBubble && !e.rootEl && o !== document && (c.parentNode[q]._isOutsideThisEl(e.target), !ee && he(e)), !l.dragoverBubble && e.stopPropagation && e.stopPropagation(), w = !0;
		}
		function j() {
			$ = J(c), se = J(c, l.draggable), W({
				sortable: b,
				name: "change",
				toEl: n,
				newIndex: $,
				newDraggableIndex: se,
				originalEvent: e
			});
		}
		if (e.preventDefault !== void 0 && e.cancelable && e.preventDefault(), o = Q(o, l.draggable, n, !0), L("dragOver"), p.eventCanceled) return w;
		if (c.contains(e.target) || o.animated && o.animatingX && o.animatingY || b._ignoreWhileAnimating === o) return R(!1);
		if (Ge = !1, u && !l.disabled && (d ? f || (a = O !== T) : Y === this || (this.lastPutMode = Me.checkPull(this, u, c, e)) && s.checkPut(this, u, c, e))) {
			if (y = this._getDirection(e, o) === "vertical", r = P(c), L("dragOverValid"), p.eventCanceled) return w;
			if (a) return O = T, G(), this._hideClone(), L("revert"), p.eventCanceled || (pe ? T.insertBefore(c, pe) : T.appendChild(c)), R(!0);
			var B = ht(n, l.draggable);
			if (!B || $n(e, y, this) && !B.animated) {
				if (B === c) return R(!1);
				if (B && n === e.target && (o = B), o && (i = P(o)), Xe(T, n, c, r, o, i, e, !!o) !== !1) return G(), B && B.nextSibling ? n.insertBefore(c, B.nextSibling) : n.appendChild(c), O = n, j(), R(!0);
			} else if (B && Vn(e, y, this)) {
				var X = we(n, 0, l, !0);
				if (X === c) return R(!1);
				if (o = X, i = P(o), Xe(T, n, c, r, o, i, e, !1) !== !1) return G(), n.insertBefore(c, X), O = n, j(), R(!0);
			} else if (o.parentNode === n) {
				i = P(o);
				var K = 0, oe, le = c.parentNode !== n, k = !Wn(c.animated && c.toRect || r, o.animated && o.toRect || i, y), v = y ? "top" : "left", D = xt(o, "top", "top") || xt(c, "top", "top"), A = D ? D.scrollTop : void 0;
				me !== o && (oe = i[v], Ae = !1, Fe = !k && l.invertSwap || le), K = qn(e, o, i, y, k ? 1 : l.swapThreshold, l.invertedSwapThreshold == null ? l.swapThreshold : l.invertedSwapThreshold, Fe, me === o);
				var I;
				if (K !== 0) {
					var _ = J(c);
					do
						_ -= K, I = O.children[_];
					while (I && (h$1(I, "display") === "none" || I === g));
				}
				if (K === 0 || I === o) return R(!1);
				me = o, Ie = K;
				var x = o.nextElementSibling, M = !1;
				M = K === 1;
				var F = Xe(T, n, c, r, o, i, e, M);
				if (F !== !1) return (F === 1 || F === -1) && (M = F === 1), lt = !0, setTimeout(Un, 30), G(), M && !x ? n.appendChild(c) : o.parentNode.insertBefore(c, M ? x : o), D && Ut(D, 0, A - D.scrollTop), O = c.parentNode, oe !== void 0 && !Fe && (ke = Math.abs(oe - P(o)[v])), j(), R(!0);
			}
			if (n.contains(c)) return R(!1);
		}
		return !1;
	},
	_ignoreWhileAnimating: null,
	_offMoveEvents: function() {
		E(document, "mousemove", this._onTouchMove), E(document, "touchmove", this._onTouchMove), E(document, "pointermove", this._onTouchMove), E(document, "dragover", he), E(document, "mousemove", he), E(document, "touchmove", he);
	},
	_offUpEvents: function() {
		var e = this.el.ownerDocument;
		E(e, "mouseup", this._onDrop), E(e, "touchend", this._onDrop), E(e, "pointerup", this._onDrop), E(e, "touchcancel", this._onDrop), E(document, "selectstart", this);
	},
	_onDrop: function(e) {
		var n = this.el, o = this.options;
		if ($ = J(c), se = J(c, o.draggable), z("drop", this, { evt: e }), O = c && c.parentNode, $ = J(c), se = J(c, o.draggable), p.eventCanceled) {
			this._nulling();
			return;
		}
		ve = !1, Fe = !1, Ae = !1, clearInterval(this._loopId), clearTimeout(this._dragStartTimer), st(this.cloneId), st(this._dragStartId), this.nativeDraggable && (E(document, "drop", this), E(n, "dragstart", this._onDragStart)), this._offMoveEvents(), this._offUpEvents(), Te && h$1(document.body, "user-select", ""), h$1(c, "transform", ""), e && (Se && (e.cancelable && e.preventDefault(), !o.dropBubble && e.stopPropagation()), g && g.parentNode && g.parentNode.removeChild(g), (T === O || Y && Y.lastPutMode !== "clone") && C && C.parentNode && C.parentNode.removeChild(C), c && (this.nativeDraggable && E(c, "dragend", this), nt(c), c.style["will-change"] = "", Se && !ve && V(c, Y ? Y.options.ghostClass : this.options.ghostClass, !1), V(c, this.options.chosenClass, !1), W({
			sortable: this,
			name: "unchoose",
			toEl: O,
			newIndex: null,
			newDraggableIndex: null,
			originalEvent: e
		}), T !== O ? ($ >= 0 && (W({
			rootEl: O,
			name: "add",
			toEl: O,
			fromEl: T,
			originalEvent: e
		}), W({
			sortable: this,
			name: "remove",
			toEl: O,
			originalEvent: e
		}), W({
			rootEl: O,
			name: "sort",
			toEl: O,
			fromEl: T,
			originalEvent: e
		}), W({
			sortable: this,
			name: "sort",
			toEl: O,
			originalEvent: e
		})), Y && Y.save()) : $ !== be && $ >= 0 && (W({
			sortable: this,
			name: "update",
			toEl: O,
			originalEvent: e
		}), W({
			sortable: this,
			name: "sort",
			toEl: O,
			originalEvent: e
		})), p.active && (($ == null || $ === -1) && ($ = be, se = Oe), W({
			sortable: this,
			name: "end",
			toEl: O,
			originalEvent: e
		}), this.save()))), this._nulling();
	},
	_nulling: function() {
		z("nulling", this), T = c = O = g = pe = C = Be = ue = de = Z = Se = $ = se = be = Oe = me = Ie = Y = Me = p.dragged = p.ghost = p.clone = p.active = null, ze.forEach(function(e) {
			e.checked = !0;
		}), ze.length = Qe = et = 0;
	},
	handleEvent: function(e) {
		switch (e.type) {
			case "drop":
			case "dragend":
				this._onDrop(e);
				break;
			case "dragenter":
			case "dragover":
				c && (this._onDragOver(e), zn(e));
				break;
			case "selectstart": e.preventDefault();
		}
	},
	/**
	* Serializes the item into an array of string.
	* @returns {String[]}
	*/
	toArray: function() {
		for (var e = [], n, o = this.el.children, r = 0, i = o.length, a = this.options; r < i; r++) n = o[r], Q(n, a.draggable, this.el, !1) && e.push(n.getAttribute(a.dataIdAttr) || Jn(n));
		return e;
	},
	/**
	* Sorts the elements according to the array.
	* @param  {String[]}  order  order of the items
	*/
	sort: function(e, n) {
		var o = {}, r = this.el;
		this.toArray().forEach(function(i, a) {
			var l = r.children[a];
			Q(l, this.options.draggable, r, !1) && (o[i] = l);
		}, this), n && this.captureAnimationState(), e.forEach(function(i) {
			o[i] && (r.removeChild(o[i]), r.appendChild(o[i]));
		}), n && this.animateAll();
	},
	/**
	* Save the current sorting
	*/
	save: function() {
		var e = this.options.store;
		e && e.set && e.set(this);
	},
	/**
	* For each element in the set, get the first element that matches the selector by testing the element itself and traversing up through its ancestors in the DOM tree.
	* @param   {HTMLElement}  el
	* @param   {String}       [selector]  default: `options.draggable`
	* @returns {HTMLElement|null}
	*/
	closest: function(e, n) {
		return Q(e, n || this.options.draggable, this.el, !1);
	},
	/**
	* Set/get option
	* @param   {string} name
	* @param   {*}      [value]
	* @returns {*}
	*/
	option: function(e, n) {
		var o = this.options;
		if (n === void 0) return o[e];
		var r = Ne.modifyOption(this, e, n);
		typeof r != "undefined" ? o[e] = r : o[e] = n, e === "group" && Jt(o);
	},
	/**
	* Destroy
	*/
	destroy: function() {
		z("destroy", this);
		var e = this.el;
		e[q] = null, E(e, "mousedown", this._onTapStart), E(e, "touchstart", this._onTapStart), E(e, "pointerdown", this._onTapStart), this.nativeDraggable && (E(e, "dragover", this), E(e, "dragenter", this)), Array.prototype.forEach.call(e.querySelectorAll("[draggable]"), function(n) {
			n.removeAttribute("draggable");
		}), this._onDrop(), this._disableDelayedDragEvents(), je.splice(je.indexOf(this.el), 1), this.el = e = null;
	},
	_hideClone: function() {
		if (!ue) {
			if (z("hideClone", this), p.eventCanceled) return;
			h$1(C, "display", "none"), this.options.removeCloneOnHide && C.parentNode && C.parentNode.removeChild(C), ue = !0;
		}
	},
	_showClone: function(e) {
		if (e.lastPutMode !== "clone") {
			this._hideClone();
			return;
		}
		if (ue) {
			if (z("showClone", this), p.eventCanceled) return;
			c.parentNode == T && !this.options.group.revertClone ? T.insertBefore(C, c) : pe ? T.insertBefore(C, pe) : T.appendChild(C), this.options.group.revertClone && this.animate(c, C), h$1(C, "display", ""), ue = !1;
		}
	}
};
function zn(t) {
	t.dataTransfer && (t.dataTransfer.dropEffect = "move"), t.cancelable && t.preventDefault();
}
function Xe(t, e, n, o, r, i, a, l) {
	var s, u = t[q], d = u.options.onMove, f;
	return window.CustomEvent && !ae && !xe ? s = new CustomEvent("move", {
		bubbles: !0,
		cancelable: !0
	}) : (s = document.createEvent("Event"), s.initEvent("move", !0, !0)), s.to = e, s.from = t, s.dragged = n, s.draggedRect = o, s.related = r || e, s.relatedRect = i || P(e), s.willInsertAfter = l, s.originalEvent = a, t.dispatchEvent(s), d && (f = d.call(u, s, a)), f;
}
function nt(t) {
	t.draggable = !1;
}
function Un() {
	lt = !1;
}
function Vn(t, e, n) {
	var o = P(we(n.el, 0, n.options, !0)), r = $t(n.el, n.options, g), i = 10;
	return e ? t.clientX < r.left - i || t.clientY < o.top && t.clientX < o.right : t.clientY < r.top - i || t.clientY < o.bottom && t.clientX < o.left;
}
function $n(t, e, n) {
	var o = P(ht(n.el, n.options.draggable)), r = $t(n.el, n.options, g), i = 10;
	return e ? t.clientX > r.right + i || t.clientY > o.bottom && t.clientX > o.left : t.clientY > r.bottom + i || t.clientX > o.right && t.clientY > o.top;
}
function qn(t, e, n, o, r, i, a, l) {
	var s = o ? t.clientY : t.clientX, u = o ? n.height : n.width, d = o ? n.top : n.left, f = o ? n.bottom : n.right, m = !1;
	if (!a) {
		if (l && ke < u * r) {
			if (!Ae && (Ie === 1 ? s > d + u * i / 2 : s < f - u * i / 2) && (Ae = !0), Ae) m = !0;
			else if (Ie === 1 ? s < d + ke : s > f - ke) return -Ie;
		} else if (s > d + u * (1 - r) / 2 && s < f - u * (1 - r) / 2) return Kn(e);
	}
	return m = m || a, m && (s < d + u * i / 2 || s > f - u * i / 2) ? s > d + u / 2 ? 1 : -1 : 0;
}
function Kn(t) {
	return J(c) < J(t) ? 1 : -1;
}
function Jn(t) {
	for (var e = t.tagName + t.className + t.src + t.href + t.textContent, n = e.length, o = 0; n--;) o += e.charCodeAt(n);
	return o.toString(36);
}
function Zn(t) {
	ze.length = 0;
	for (var e = t.getElementsByTagName("input"), n = e.length; n--;) {
		var o = e[n];
		o.checked && ze.push(o);
	}
}
function He(t) {
	return setTimeout(t, 0);
}
function st(t) {
	return clearTimeout(t);
}
Ve && S(document, "touchmove", function(t) {
	(p.active || ve) && t.cancelable && t.preventDefault();
});
p.utils = {
	on: S,
	off: E,
	css: h$1,
	find: jt,
	is: function(e, n) {
		return !!Q(e, n, e, !1);
	},
	extend: Fn,
	throttle: zt,
	closest: Q,
	toggleClass: V,
	clone: Vt,
	index: J,
	nextTick: He,
	cancelNextTick: st,
	detectDirection: Kt,
	getChild: we
};
p.get = function(t) {
	return t[q];
};
p.mount = function() {
	for (var t = arguments.length, e = new Array(t), n = 0; n < t; n++) e[n] = arguments[n];
	e[0].constructor === Array && (e = e[0]), e.forEach(function(o) {
		if (!o.prototype || !o.prototype.constructor) throw "Sortable: Mounted plugin must be a constructor function, not ".concat({}.toString.call(o));
		o.utils && (p.utils = ne(ne({}, p.utils), o.utils)), Ne.mount(o);
	});
};
p.create = function(t, e) {
	return new p(t, e);
};
p.version = Nn;
var N = [];
var De;
var ut;
var ct = !1;
var ot;
var rt;
var Ue;
var _e;
function Qn() {
	function t() {
		this.defaults = {
			scroll: !0,
			forceAutoScrollFallback: !1,
			scrollSensitivity: 30,
			scrollSpeed: 10,
			bubbleScroll: !0
		};
		for (var e in this) e.charAt(0) === "_" && typeof this[e] == "function" && (this[e] = this[e].bind(this));
	}
	return t.prototype = {
		dragStarted: function(n) {
			var o = n.originalEvent;
			this.sortable.nativeDraggable ? S(document, "dragover", this._handleAutoScroll) : this.options.supportPointer ? S(document, "pointermove", this._handleFallbackAutoScroll) : o.touches ? S(document, "touchmove", this._handleFallbackAutoScroll) : S(document, "mousemove", this._handleFallbackAutoScroll);
		},
		dragOverCompleted: function(n) {
			var o = n.originalEvent;
			!this.options.dragOverBubble && !o.rootEl && this._handleAutoScroll(o);
		},
		drop: function() {
			this.sortable.nativeDraggable ? E(document, "dragover", this._handleAutoScroll) : (E(document, "pointermove", this._handleFallbackAutoScroll), E(document, "touchmove", this._handleFallbackAutoScroll), E(document, "mousemove", this._handleFallbackAutoScroll)), Rt(), Le(), Rn();
		},
		nulling: function() {
			Ue = ut = De = ct = _e = ot = rt = null, N.length = 0;
		},
		_handleFallbackAutoScroll: function(n) {
			this._handleAutoScroll(n, !0);
		},
		_handleAutoScroll: function(n, o) {
			var r = this, i = (n.touches ? n.touches[0] : n).clientX, a = (n.touches ? n.touches[0] : n).clientY, l = document.elementFromPoint(i, a);
			if (Ue = n, o || this.options.forceAutoScrollFallback || xe || ae || Te) {
				it(n, this.options, l, o);
				var s = ce(l, !0);
				ct && (!_e || i !== ot || a !== rt) && (_e && Rt(), _e = setInterval(function() {
					var u = ce(document.elementFromPoint(i, a), !0);
					u !== s && (s = u, Le()), it(n, r.options, u, o);
				}, 10), ot = i, rt = a);
			} else {
				if (!this.options.bubbleScroll || ce(l, !0) === te()) {
					Le();
					return;
				}
				it(n, this.options, ce(l, !1), !1);
			}
		}
	}, ie(t, {
		pluginName: "scroll",
		initializeByDefault: !0
	});
}
function Le() {
	N.forEach(function(t) {
		clearInterval(t.pid);
	}), N = [];
}
function Rt() {
	clearInterval(_e);
}
var it = zt(function(t, e, n, o) {
	if (e.scroll) {
		var r = (t.touches ? t.touches[0] : t).clientX, i = (t.touches ? t.touches[0] : t).clientY, a = e.scrollSensitivity, l = e.scrollSpeed, s = te(), u = !1, d;
		ut !== n && (ut = n, Le(), De = e.scroll, d = e.scrollFn, De === !0 && (De = ce(n, !0)));
		var f = 0, m = De;
		do {
			var y = m, b = P(y), w = b.top, L = b.bottom, G = b.left, R = b.right, j = b.width, B = b.height, X = void 0, K = void 0, oe = y.scrollWidth, le = y.scrollHeight, k = h$1(y), v = y.scrollLeft, D = y.scrollTop;
			y === s ? (X = j < oe && (k.overflowX === "auto" || k.overflowX === "scroll" || k.overflowX === "visible"), K = B < le && (k.overflowY === "auto" || k.overflowY === "scroll" || k.overflowY === "visible")) : (X = j < oe && (k.overflowX === "auto" || k.overflowX === "scroll"), K = B < le && (k.overflowY === "auto" || k.overflowY === "scroll"));
			var A = X && (Math.abs(R - r) <= a && v + j < oe) - (Math.abs(G - r) <= a && !!v), I = K && (Math.abs(L - i) <= a && D + B < le) - (Math.abs(w - i) <= a && !!D);
			if (!N[f]) for (var _ = 0; _ <= f; _++) N[_] || (N[_] = {});
			(N[f].vx != A || N[f].vy != I || N[f].el !== y) && (N[f].el = y, N[f].vx = A, N[f].vy = I, clearInterval(N[f].pid), (A != 0 || I != 0) && (u = !0, N[f].pid = setInterval(function() {
				o && this.layer === 0 && p.active._onTouchMove(Ue);
				var x = N[this.layer].vy ? N[this.layer].vy * l : 0, M = N[this.layer].vx ? N[this.layer].vx * l : 0;
				typeof d == "function" && d.call(p.dragged.parentNode[q], M, x, t, Ue, N[this.layer].el) !== "continue" || Ut(N[this.layer].el, M, x);
			}.bind({ layer: f }), 24))), f++;
		} while (e.bubbleScroll && m !== s && (m = ce(m, !1)));
		ct = u;
	}
}, 30);
var en = function(e) {
	var n = e.originalEvent, o = e.putSortable, r = e.dragEl, i = e.activeSortable, a = e.dispatchSortableEvent, l = e.hideGhostForTarget, s = e.unhideGhostForTarget;
	if (n) {
		var u = o || i;
		l();
		var d = n.changedTouches && n.changedTouches.length ? n.changedTouches[0] : n, f = document.elementFromPoint(d.clientX, d.clientY);
		s(), u && !u.el.contains(f) && (a("spill"), this.onSpill({
			dragEl: r,
			putSortable: o
		}));
	}
};
function pt() {}
pt.prototype = {
	startIndex: null,
	dragStart: function(e) {
		var n = e.oldDraggableIndex;
		this.startIndex = n;
	},
	onSpill: function(e) {
		var n = e.dragEl, o = e.putSortable;
		this.sortable.captureAnimationState(), o && o.captureAnimationState();
		var r = we(this.sortable.el, this.startIndex, this.options);
		r ? this.sortable.el.insertBefore(n, r) : this.sortable.el.appendChild(n), this.sortable.animateAll(), o && o.animateAll();
	},
	drop: en
};
ie(pt, { pluginName: "revertOnSpill" });
function gt() {}
gt.prototype = {
	onSpill: function(e) {
		var n = e.dragEl, r = e.putSortable || this.sortable;
		r.captureAnimationState(), n.parentNode && n.parentNode.removeChild(n), r.animateAll();
	},
	drop: en
};
ie(gt, { pluginName: "removeOnSpill" });
p.mount(new Qn());
p.mount(gt, pt);
function eo(t) {
	return t == null ? t : JSON.parse(JSON.stringify(t));
}
function to(t) {
	getCurrentInstance() && onUnmounted(t);
}
function no(t) {
	getCurrentInstance() ? onMounted(t) : nextTick(t);
}
var tn = null;
var nn = null;
function Xt(t = null, e = null) {
	tn = t, nn = e;
}
function oo() {
	return {
		data: tn,
		clonedData: nn
	};
}
var Yt = Symbol("cloneElement");
function on(...t) {
	var le, k;
	const e = (le = getCurrentInstance()) == null ? void 0 : le.proxy;
	let n = null;
	const o = t[0];
	let [, r, i] = t;
	Array.isArray(unref(r)) || (i = r, r = null);
	let a = null;
	const { immediate: l = !0, clone: s = eo, forceFallback: u, fallbackOnBody: d, customUpdate: f } = (k = unref(i)) != null ? k : {};
	function m(v) {
		var F;
		const { from: D, oldIndex: A, item: I } = v, _ = Array.from(D.childNodes);
		n = u && !d ? _.slice(0, -1) : _;
		const x = unref((F = unref(r)) == null ? void 0 : F[A]), M = s(x);
		Xt(x, M), I[Yt] = M;
	}
	function y(v) {
		const D = v.item[Yt];
		if (!wn(D)) {
			if (Ke(v.item), isRef(r)) {
				const A = [...unref(r)];
				r.value = _t(A, v.newDraggableIndex, D);
				return;
			}
			_t(unref(r), v.newDraggableIndex, D);
		}
	}
	function b(v) {
		const { from: D, item: A, oldIndex: I, oldDraggableIndex: _, pullMode: x, clone: M } = v;
		if (Tt(D, A, I), x === "clone") {
			Ke(M);
			return;
		}
		if (isRef(r)) {
			const F = [...unref(r)];
			r.value = Dt(F, _);
			return;
		}
		Dt(unref(r), _);
	}
	function w(v) {
		if (f) {
			f(v);
			return;
		}
		const { from: D, item: A, oldIndex: I, oldDraggableIndex: _, newDraggableIndex: x } = v;
		if (Ke(A), Tt(D, A, I), isRef(r)) {
			const M = [...unref(r)];
			r.value = St(M, _, x);
			return;
		}
		St(unref(r), _, x);
	}
	function L(v) {
		const { newIndex: D, oldIndex: A, from: I, to: _ } = v;
		let x = null;
		const M = D === A && I === _;
		try {
			if (M) {
				let F = null;
				n?.some((ee, Ee) => {
					if (F && (n == null ? void 0 : n.length) !== _.childNodes.length) return I.insertBefore(F, ee.nextSibling), !0;
					const mt = _.childNodes[Ee];
					F = _ == null ? void 0 : _.replaceChild(ee, mt);
				});
			}
		} catch (F) {
			x = F;
		} finally {
			n = null;
		}
		nextTick(() => {
			if (Xt(), x) throw x;
		});
	}
	const G = {
		onUpdate: w,
		onStart: m,
		onAdd: y,
		onRemove: b,
		onEnd: L
	};
	function R(v) {
		const D = unref(o);
		return v || (v = En(D) ? Sn(D, e == null ? void 0 : e.$el) : D), v && !Tn(v) && (v = v.$el), v || vn("Root element not found"), v;
	}
	function j() {
		var I;
		const _ = (I = unref(i)) != null ? I : {}, { immediate: v, clone: D } = _, A = $e(_, ["immediate", "clone"]);
		return Ct(A, (x, M) => {
			Cn(x) && (A[x] = (F, ...ee) => {
				return On(F, oo()), M(F, ...ee);
			});
		}), _n(r === null ? {} : G, A);
	}
	const B = (v) => {
		v = R(v), a && X.destroy(), a = new p(v, j());
	};
	watch(() => i, () => {
		a && Ct(j(), (v, D) => {
			a?.option(v, D);
		});
	}, { deep: !0 });
	const X = {
		option: (v, D) => a == null ? void 0 : a.option(v, D),
		destroy: () => {
			a?.destroy(), a = null;
		},
		save: () => a == null ? void 0 : a.save(),
		toArray: () => a == null ? void 0 : a.toArray(),
		closest: (...v) => a == null ? void 0 : a.closest(...v)
	}, K = () => X == null ? void 0 : X.option("disabled", !0), oe = () => X == null ? void 0 : X.option("disabled", !1);
	return no(() => {
		l && B();
	}), to(X.destroy), fe({
		start: B,
		pause: K,
		resume: oe
	}, X);
}
var ft = [
	"update",
	"start",
	"add",
	"remove",
	"choose",
	"unchoose",
	"end",
	"sort",
	"filter",
	"clone",
	"move",
	"change"
];
var ro = [
	"clone",
	"animation",
	"ghostClass",
	"group",
	"sort",
	"disabled",
	"store",
	"handle",
	"draggable",
	"swapThreshold",
	"invertSwap",
	"invertedSwapThreshold",
	"removeCloneOnHide",
	"direction",
	"chosenClass",
	"dragClass",
	"ignore",
	"filter",
	"preventOnFilter",
	"easing",
	"setData",
	"dropBubble",
	"dragoverBubble",
	"dataIdAttr",
	"delay",
	"delayOnTouchOnly",
	"touchStartThreshold",
	"forceFallback",
	"fallbackClass",
	"fallbackOnBody",
	"fallbackTolerance",
	"fallbackOffset",
	"supportPointer",
	"emptyInsertThreshold",
	"scroll",
	"forceAutoScrollFallback",
	"scrollSensitivity",
	"scrollSpeed",
	"bubbleScroll",
	"modelValue",
	"tag",
	"target",
	"customUpdate",
	...ft.map((t) => `on${t.replace(/^\S/, (e) => e.toUpperCase())}`)
];
var lo = defineComponent({
	name: "VueDraggable",
	model: {
		prop: "modelValue",
		event: "update:modelValue"
	},
	props: ro,
	emits: ["update:modelValue", ...ft],
	setup(t, { slots: e, emit: n, expose: o, attrs: r }) {
		const i = ft.reduce((d, f) => {
			const m = `on${f.replace(/^\S/, (y) => y.toUpperCase())}`;
			return d[m] = (...y) => n(f, ...y), d;
		}, {}), a = computed(() => {
			const y = toRefs(t), { modelValue: d } = y, f = $e(y, ["modelValue"]), m = Object.entries(f).reduce((b, [w, L]) => {
				const G = unref(L);
				return G !== void 0 && (b[w] = G), b;
			}, {});
			return fe(fe({}, i), yn(fe(fe({}, r), m)));
		}), l = computed({
			get: () => t.modelValue,
			set: (d) => n("update:modelValue", d)
		}), s = ref(), u = reactive(on(t.target || s, l, a));
		return o(u), () => {
			var d;
			return h(t.tag || "div", { ref: s }, (d = e == null ? void 0 : e.default) == null ? void 0 : d.call(e, u));
		};
	}
});
var Bt = {
	mounted: "mounted",
	unmounted: "unmounted"
};
Bt.mounted, Bt.unmounted;
//#endregion
//#region plugins/dsh-dividend-screen/constants.ts
/**
* 插件 dsh-dividend-screen（股息筛选）· 全部常量
*
* 定位：市面「股息排行」字段的口径都有偏差 —— 东财 clist `f133` 实测 ≈ 最新年报期
* 分红 ÷ 现价（招商银行 2026-09-20 实测漏掉中期分红，2.47% vs 同花顺 TTM 4.97%），
* 只用于**选样本池**；展示的 TTM / 去年 / 推算股息率全部由本插件用分红明细自算。
* 在同一张表上叠加**今年推算**：用今年中报 ÷ 去年中报的净利比作为全年增长系数，
* 保留去年分红率（去年分红 = 去年财务年度内中期 + 末期 + 季度方案合计），
* 推算「今年若维持分红率、全年净利按中报增速走」的股息率。
*
* 数据源（2026-09-20 全部实测可用，证据 `.ai/tmp/dy*.json`）：
* - 股息率排行：`push2delay.eastmoney.com/api/qt/clist/get`，`fid=f133` 降序，
*   `fltt=2&invt=2` 下全部字段为真值（f2 现价 / f20 总市值 / f38 总股本 / f115 PE-TTM / f133 股息率）；
*   ⚠️ 实测 `pz>100` 只回 100 行（上游硬上限）→ 必须分页；
* - 业绩报表：`datacenter-web.eastmoney.com/api/data/v1/get?reportName=RPT_LICO_FN_CPD`，
*   支持 `(REPORTDATE=...)(SECURITY_CODE in ("...","..."))` 复合过滤，
*   字段 `PARENT_NETPROFIT` 归母净利 / `SJLTZ` 净利同比 / `YSTZ` 营收同比 / `BOARD_NAME` 行业；
* - 分红明细：`reportName=RPT_SHAREBONUS_DET`，`PRETAX_BONUS_RMB` 为每 10 股派息（含税），
*   同一报告期可能有多条方案，每股派息须**按代码求和**；`EX_DIVIDEND_DATE` 除权除息日
*   是 TTM 归集的锚点（报告期归属财务年度，除息日归属现金流时点，两者不同）。
*/
/** 插件 id */
var DIVIDEND_PLUGIN_ID = "dsh-dividend-screen";
/** 左侧导航路径（菜单贡献点带 component 时自动注册该路由） */
var DIVIDEND_MENU_PATH = "/dividend-screen";
/** 左侧导航标题 */
var DIVIDEND_MENU_TITLE = "股息筛选";
/** 菜单图标（MenuIcon 的 key） */
var DIVIDEND_MENU_ICON = "rank";
/** 东财行情域要求带 Referer，否则可能被拒 */
var EM_QUOTE_REFERER = "https://quote.eastmoney.com/";
/** 东财数据中心要求带 Referer，否则可能被拒 */
var EM_DATA_REFERER = "https://data.eastmoney.com/";
/** 股息率排行（push2delay 延时快照域，本机实测长期可达） */
var DIVIDEND_RANK_URL = "https://push2delay.eastmoney.com/api/qt/clist/get";
/** 东财数据中心（业绩报表与分红明细共用基址） */
var EM_DATACENTER_URL = "https://datacenter-web.eastmoney.com/api/data/v1/get";
/** 业绩报表的 reportName */
var EM_PERF_REPORT_NAME = "RPT_LICO_FN_CPD";
/** 分红送配明细的 reportName */
var EM_DIVIDEND_REPORT_NAME = "RPT_SHAREBONUS_DET";
/** 排行查询串（`{page}` 由取数层替换；`fltt=2&invt=2` 保证数值为真值小数） */
var DIVIDEND_RANK_QUERY = `pn={page}&pz=100&po=1&np=1&fltt=2&invt=2&fid=f133&fs=m:0+t:6,m:0+t:80,m:1+t:2,m:1+t:23&fields=f12,f14,f2,f3,f20,f23,f38,f115,f133`;
/** 排行查询串里页码的占位符（由取数层替换为实际页码） */
var DIVIDEND_RANK_PAGE_TOKEN = "{page}";
/** clist 行里各字段的键（避免在解析层写裸字符串） */
var EM_RANK_FIELD = {
	/** 股票代码 */
	CODE: "f12",
	/** 股票名称 */
	NAME: "f14",
	/** 现价 */
	PRICE: "f2",
	/** 涨跌幅（%） */
	CHANGE_PERCENT: "f3",
	/** 总市值（元） */
	MARKET_CAP: "f20",
	/** 市净率 */
	PB: "f23",
	/** 总股本（股） */
	TOTAL_SHARES: "f38",
	/** 市盈率 TTM */
	PE_TTM: "f115",
	/** 东财「股息率」字段（实测 ≈ 最新年报期分红 ÷ 现价，仅用于选样本池，见上） */
	DIVIDEND_YIELD: "f133"
};
/** datacenter 业绩报表的报告期字段名（⚠️ 无下划线） */
var EM_PERF_REPORT_DATE_FIELD = "REPORTDATE";
/** datacenter 分红明细的报告期字段名（⚠️ 带下划线，与业绩报表不同） */
var EM_DIVIDEND_REPORT_DATE_FIELD = "REPORT_DATE";
/** datacenter 查询里代码字段名（两个 reportName 通用） */
var EM_SECURITY_CODE_FIELD = "SECURITY_CODE";
/** datacenter 业绩报表的取用列（MGJYXJJE = 每股经营活动现金流，规则引擎用） */
var EM_PERF_COLUMNS = "SECURITY_CODE,SECURITY_NAME_ABBR,PARENT_NETPROFIT,SJLTZ,YSTZ,BOARD_NAME,MGJYXJJE";
/** datacenter 业绩报表行里各字段的键 */
var EM_PERF_FIELD = {
	/** 股票代码 */
	CODE: "SECURITY_CODE",
	/** 归母净利润（元） */
	NET_PROFIT: "PARENT_NETPROFIT",
	/** 净利润同比（%） */
	NET_PROFIT_YOY: "SJLTZ",
	/** 营业收入同比（%） */
	REVENUE_YOY: "YSTZ",
	/** 行业（东财口径） */
	INDUSTRY: "BOARD_NAME",
	/** 每股经营活动现金流（元；年报口径 = 全年经营现金流 ÷ 总股本） */
	OCF_PER_SHARE: "MGJYXJJE"
};
/** 资产负债表摘要的 reportName（负债率来源，2026-09-20 实测：DEBT_ASSET_RATIO 为百分数真值） */
var EM_BALANCE_REPORT_NAME = "RPT_DMSK_FN_BALANCE";
/** 资产负债表摘要的报告期字段名（⚠️ 带下划线，与分红明细同、与业绩报表不同） */
var EM_BALANCE_REPORT_DATE_FIELD = "REPORT_DATE";
/** 资产负债表摘要的取用列 */
var EM_BALANCE_COLUMNS = "SECURITY_CODE,REPORT_DATE,DEBT_ASSET_RATIO";
/** 资产负债表摘要行里各字段的键 */
var EM_BALANCE_FIELD = {
	/** 股票代码 */
	CODE: "SECURITY_CODE",
	/** 报告期 */
	REPORT_DATE: "REPORT_DATE",
	/** 资产负债率（%，真值小数） */
	DEBT_ASSET_RATIO: "DEBT_ASSET_RATIO"
};
/** datacenter 分红明细的取用列（EX_DIVIDEND_DATE = 除权除息日，TTM 归集锚点） */
var EM_DIVIDEND_COLUMNS = "SECURITY_CODE,SECURITY_NAME_ABBR,REPORT_DATE,ASSIGN_PROGRESS,PRETAX_BONUS_RMB,TOTAL_SHARES,EX_DIVIDEND_DATE";
/** datacenter 分红明细行里各字段的键 */
var EM_DIVIDEND_FIELD = {
	/** 股票代码 */
	CODE: "SECURITY_CODE",
	/** 报告期（多期合并查询后按期分组的键） */
	REPORT_DATE: "REPORT_DATE",
	/** 每 10 股派息（元，含税；纯转增行为 null） */
	BONUS_PER_TEN: "PRETAX_BONUS_RMB",
	/** 派息方案公告时的总股本（股） */
	TOTAL_SHARES: "TOTAL_SHARES",
	/** 除权除息日（未实施为空） */
	EX_DATE: "EX_DIVIDEND_DATE"
};
/** 东财行情域（push2delay）分页间隔（毫秒；东财系同上游必须错峰） */
var EM_RANK_DELAY_MS = 1e3;
/** 重试间隔（毫秒） */
var EM_FETCH_RETRY_DELAY_MS = 1500;
/** 样本池可选档位 */
var DIVIDEND_UNIVERSE_OPTIONS = [
	100,
	200,
	300,
	500
];
/** 元 → 亿元换算基数 */
var YUAN_PER_YI = 1e8;
/**
* 推算状态（决定行内推算列显示什么）
*
* 状态判定按顺序短路：未披露 → 今年亏损 → 增长不可比 → 无可比分红率 → 可推算。
*/
var DIVIDEND_PROJECT_STATUS = {
	/** 今年中报已披露、去年基数健康、去年有分红率 → 可推算 */
	OK: "ok",
	/** 今年中报未披露（无记录或净利字段缺失） */
	NO_REPORT: "no_report",
	/** 今年中报亏损（负增长推算出的负分红没有意义，不推算） */
	H1_LOSS: "h1_loss",
	/** 今年盈利但去年同期无数据或为负（增长系数不可比） */
	BASE_INVALID: "base_invalid",
	/** 去年未分红或去年净利为负（分红率不可得） */
	NO_PAYOUT: "no_payout"
};
/** 推算状态中文说明（行内徽标与展开区共用） */
var DIVIDEND_PROJECT_STATUS_LABEL = {
	ok: "可推算",
	no_report: "中报未披露",
	h1_loss: "中报亏损",
	base_invalid: "增长不可比",
	no_payout: "去年无可比分红率"
};
/** 推算状态徽标样式（可推算用涨色弱底，其余用中性弱底） */
var DIVIDEND_PROJECT_STATUS_BADGE_CLASS = {
	ok: "bg-up-weak text-up",
	no_report: "bg-flat-weak/60 text-text-tertiary",
	h1_loss: "bg-down-weak text-down",
	base_invalid: "bg-flat-weak/60 text-text-tertiary",
	no_payout: "bg-flat-weak/60 text-text-tertiary"
};
/** 超额分红徽标文案 */
var DIVIDEND_PAYOUT_OVERDUE_BADGE = "超分红";
/**
* 规则配置在插件库 config 表里的键
*/
var DIVIDEND_CONFIG_KEY = "rule_config";
/** 规则分组：筛选（全部满足才保留） */
var RULE_GROUP_FILTER = "filter";
/** 规则分组：排除（命中任意一条即剔除） */
var RULE_GROUP_EXCLUDE = "exclude";
/**
* 周期行业关键词默认清单（子串匹配东财 BOARD_NAME）
*
* 「非周期顶点」没有直接可查的字段，用两层代理：① 行业属周期板块 → 高股息常是
* 盈利顶点的价格陷阱（市盈率极低 = 市场预期景气回落）；② 中报净利同比塌陷。
* 关键词按子串匹配以兼容行业名的年度调整（如「普钢」/「特钢」都含「钢」）。
*/
var RULE_CYCLICAL_KEYWORDS_DEFAULT = "煤炭,焦炭,钢,石油,炼化,油气,化工,化学,有色,工业金属,能源金属,小金属,贵金属,航运,港口,化纤";
/** 亿元 → 元 的换算因子（东财 f20 总市值的存储单位是元） */
var YI_TO_YUAN = 1e8;
/** 页面标题 */
var DIVIDEND_PAGE_TITLE = "股息筛选";
/** 页面副标题（说明口径与硬约束） */
var DIVIDEND_PAGE_SUBTITLE = "按东财股息率排行选样本池，TTM / 去年 / 推算股息率均为本页自算口径（TTM = 近 12 个月已实施派息 ÷ 现价，与同花顺同口径；东财 f133 字段会漏一年多次分红，故只用于选池）。推算：以「今年中报 ÷ 去年中报」的净利比作全年增长系数、保留去年分红率。辅助研究工具，推算不构成投资建议。";
/** 扫描按钮文案 */
var DIVIDEND_SCAN_BUTTON = "扫描排行";
/** 扫描中按钮文案前缀 */
var DIVIDEND_SCAN_RUNNING = "扫描中";
/** 首次空态文案 */
var DIVIDEND_EMPTY_TEXT = "还没有股息样本，点「扫描排行」按 TTM 股息率拉取前 N 名并叠加中报推算（结果落本地库，重进页面不再联网）";
/** 扫描失败文案前缀 */
var DIVIDEND_SCAN_FAILED = "扫描失败";
/** 样本池选择标签 */
var DIVIDEND_UNIVERSE_LABEL = "样本池";
/** 表格列标题 */
var DIVIDEND_COLUMN_LABEL = {
	action: "操作",
	name: "股票",
	industry: "行业",
	price: "现价",
	ttmYield: "TTM股息率",
	yieldLast: "去年股息率",
	payoutLast: "去年分红率",
	dividendYears: "连续分红",
	netProfitH1: "中报净利",
	netProfitYoY: "净利同比",
	projectedYield: "推算今年股息率",
	projectedDelta: "较去年",
	debtRatio: "负债率",
	peTtm: "PE(TTM)",
	ruleResult: "规则"
};
/** 可配置列的键列表（归一化的全集参数） */
var DIVIDEND_CONFIGURABLE_COLUMN_KEYS = [
	{
		key: "name",
		label: DIVIDEND_COLUMN_LABEL.name
	},
	{
		key: "industry",
		label: DIVIDEND_COLUMN_LABEL.industry
	},
	{
		key: "price",
		label: DIVIDEND_COLUMN_LABEL.price
	},
	{
		key: "ttmYield",
		label: DIVIDEND_COLUMN_LABEL.ttmYield
	},
	{
		key: "projectedYield",
		label: DIVIDEND_COLUMN_LABEL.projectedYield
	},
	{
		key: "projectedDelta",
		label: DIVIDEND_COLUMN_LABEL.projectedDelta
	},
	{
		key: "yieldLast",
		label: DIVIDEND_COLUMN_LABEL.yieldLast
	},
	{
		key: "payoutLast",
		label: DIVIDEND_COLUMN_LABEL.payoutLast
	},
	{
		key: "dividendYears",
		label: DIVIDEND_COLUMN_LABEL.dividendYears
	},
	{
		key: "netProfitH1",
		label: DIVIDEND_COLUMN_LABEL.netProfitH1
	},
	{
		key: "netProfitYoY",
		label: DIVIDEND_COLUMN_LABEL.netProfitYoY
	},
	{
		key: "debtRatio",
		label: DIVIDEND_COLUMN_LABEL.debtRatio
	},
	{
		key: "peTtm",
		label: DIVIDEND_COLUMN_LABEL.peTtm
	}
].map((column) => column.key);
/** settings 里表头配置的键名 */
var DIVIDEND_SETTINGS_COLUMN_KEY = "columns";
/** 快捷筛选：仅已披露中报 */
var DIVIDEND_FILTER_PUBLISHED = "仅已披露中报";
/** 快捷筛选：仅净利同比增长 */
var DIVIDEND_FILTER_GROWING = "仅净利增长";
/** 快捷筛选：仅可推算行 */
var DIVIDEND_FILTER_PROJECTABLE = "仅可推算";
/** 清除筛选按钮文案 */
var DIVIDEND_FILTER_CLEAR = "清除筛选";
/**
* 筛选生效时的行数提示模板
* @param shown 已筛出行数
* @param total 全部行数
* @returns 提示文案
*/
var DIVIDEND_FILTER_SUMMARY = (shown, total) => `筛选后 ${shown}/${total} 只`;
/** 展开区小标题 */
var DIVIDEND_DETAIL_TITLE = "推算明细";
/** 展开区字段标签 */
var DIVIDEND_DETAIL_LABEL = {
	status: "推算状态",
	dpsLast: "去年每股分红",
	dividendTotalLast: "去年分红总额",
	netProfitFyLast: "去年全年净利",
	payoutLast: "去年分红率",
	netProfitH1: "今年中报净利",
	netProfitH1Last: "去年中报净利",
	growthH1: "中报净利比",
	projectedNetProfit: "预计今年净利",
	projectedDps: "推算今年每股分红",
	projectedYield: "推算今年股息率",
	interimDps: "今年中期已宣派",
	ttmYield: "TTM股息率（自算）",
	marketCap: "总市值",
	peTtm: "PE(TTM)",
	pb: "市净率",
	dividendYears: "连续分红年数",
	ocfPerShareLast: "每股经营现金流（FY）",
	cashCoverLast: "现金流 ÷ 分红",
	debtRatio: "资产负债率",
	ruleMatch: "规则匹配"
};
/** 规则面板卡片标题 */
var RULE_PANEL_TITLE = "筛选规则";
/** 筛选组标题（全部满足才保留） */
var RULE_GROUP_TITLE_FILTER = "真高股息筛选条件（须全部满足）";
/** 排除组标题（命中即剔除） */
var RULE_GROUP_TITLE_EXCLUDE = "伪高股息剔除规则（命中任一即剔除）";
/** 添加规则按钮文案 */
var RULE_ADD_BUTTON = "添加规则";
/** 添加规则的占位提示 */
var RULE_ADD_PLACEHOLDER = "选择规则类型";
/** 恢复默认预置按钮文案 */
var RULE_RESET_DEFAULT = "恢复默认预置";
/** 删除规则的可达性标签 */
var RULE_REMOVE_LABEL = "删除该规则";
/** 页面顶部的两个 tab（`BaseTabs` 选项） */
var DIVIDEND_TAB_OPTIONS = [{
	label: "股息筛选",
	value: "screen"
}, {
	label: "股息自选",
	value: "watchlist"
}];
/** tab 值：筛选 */
var DIVIDEND_TAB_SCREEN = "screen";
/** 加入自选的可达性标签 */
var WATCH_ADD_LABEL = "加入自选";
/** 移出自选的可达性标签 */
var WATCH_REMOVE_LABEL = "移出自选";
/** 一键把当前筛选列表全部加入自选 */
var WATCH_BULK_ADD = "把当前列表加入自选";
/** 自选 tab 的空态文案 */
var WATCH_EMPTY_TEXT = "还没有自选股票——在列表左侧「操作」列点「自选」按钮加入，筛选出的通过名单可以整表收进来跟踪，也可以在下方搜索个股加入";
/** 自选 tab 的表格卡片标题 */
var WATCH_CARD_TITLE = "股息自选";
/**
* 自选计数文案模板
* @param count 自选数量
* @returns 文案
*/
var WATCH_COUNT_TEXT = (count) => `共 ${count} 只`;
/** 操作失败的提示前缀（与规则保存失败同一格式） */
var WATCH_SAVE_FAILED = "自选保存失败";
/** 规则持久化失败提示前缀 */
var RULE_SAVE_FAILED = "规则保存失败";
/** 「显示未通过行」开关文案（未通过的行默认隐藏，翻开才显示并带原因徽标） */
var RULE_SHOW_FAILED = "显示未通过";
var RULE_PASS_BADGE = "通过";
/** 规则未通过徽标文案前缀 */
var RULE_FAIL_BADGE = "未过";
/** 规则剔除徽标文案前缀 */
var RULE_EXCLUDE_BADGE = "剔除";
/** 无启用规则时规则列的占位提示 */
var RULE_NO_ACTIVE_HINT = "未启用";
/** 页头字段标签 */
var DIVIDEND_HEADER_LABEL = {
	scannedAt: "上次扫描",
	universe: "样本池",
	marketTotal: "全市场",
	published: "已披露中报",
	projectable: "可推算",
	periodH1: "中报报告期",
	periodFyLast: "分红基期"
};
/** 推算公式说明（展开区固定展示，口径透明） */
var DIVIDEND_FORMULA_TEXT = "推算口径：预计今年净利 = 去年全年净利 ×（今年中报净利 ÷ 去年中报净利）；推算分红 = 去年分红率 × 预计今年净利；推算股息率 = 推算每股分红 ÷ 现价。分红率沿用去年（含特别分红的异常年份照算），中报增速对全年为线性外推，季节性强的行业（白酒 / 工程等下半年占比高）与并购重组个股会显著失真，请结合行业属性判断。";
/** 搜索输入框占位文案 */
var WATCH_SEARCH_PLACEHOLDER = "搜索个股（代码 / 名称 / 拼音）";
/** 搜索输入框的可达性标签 */
var WATCH_SEARCH_LABEL = "搜索个股并加入自选";
/** 搜索无结果的文案 */
var WATCH_SEARCH_NO_RESULT = "没有匹配的 A 股标的";
/** 搜索失败文案前缀 */
var WATCH_SEARCH_FAILED = "搜索失败";
/** 预览卡片标题 */
var WATCH_PREVIEW_TITLE = "个股预览";
/** 预览卡片「不在样本池 → 按需拉取中」的提示文案 */
var WATCH_PREVIEW_FETCHING = "不在最新扫描的样本池里，正在按需拉取该股的股息指标（行情 + 三期业绩 + 分红史 + 负债 ≈ 6 次串行请求）…";
/** 预览卡片按需拉取成功后的口径说明 */
var WATCH_PREVIEW_ON_DEMAND_NOTE = "该股不在最新扫描样本池，以下指标为点击时按需拉取（口径与扫描一致，但不写入快照，重进页面即消失）";
/** 预览指标按需拉取失败的提示前缀 */
var WATCH_PREVIEW_FETCH_FAILED = "指标拉取失败";
/** 预览卡片「打开个股详情」按钮文案 */
var WATCH_PREVIEW_OPEN_DETAIL = "个股详情";
/**
* 免责声明（页脚固定展示）
*
* 三条口径必须写明：TTM 股息率是本页自算口径（近 12 个月已实施派息 ÷ 现价，同花顺同口径；
* 东财 f133 字段 ≈ 最新年报期分红 ÷ 现价，会漏一年多次分红，只用于选样本池）；
* 去年股息率与推算股息率是本插件自算口径；推算是线性外推不是预告。
*
* 末条是跨平台口径警告：集思录等第三方「静态股息率」按**分红到账的自然年**归集，
* 本页「去年股息率」按**财务报告期**（去年财务年度内全部方案合计）归集，
* 实测同一只股可差近一倍（达仁堂 3.71% vs 6.78%、汇洁股份 6.22% vs 11.05%）→ 对比前必须对齐口径。
*/
var DIVIDEND_DISCLAIMER = "本页为历史数据推算工具，不构成投资建议：分红以公司股东大会决议为准，分红率与增速的外推都可能失真；「TTM股息率」为本页自算口径（近 12 个月已实施派息 ÷ 现价；东财排行字段会漏一年多次分红，仅用于选样本池），「去年股息率 / 推算股息率」亦为本页自算口径。注意跨平台口径差异：集思录等平台的「静态股息率」按分红的到账自然年归集，本页按财务报告期归集，同一只股可差近一倍，拿别处的股息率与本页对比前请先对齐口径。数据落本地插件库，扫描只在点击时请求上游。";
//#endregion
//#region plugins/dsh-dividend-screen/column-config.ts
/**
* 归一列配置（纯函数）
* @param raw settings 里存的原始值（可能是任意损坏形状）
* @param allKeys 代码声明的全部可配置列键（顺序即默认顺序）
* @returns 归一后的配置（order 为全集，且至少保留一列可见）
*/
var normalizeDividendColumnConfig = (raw, allKeys) => {
	const known = new Set(allKeys);
	const saved = raw && typeof raw === "object" ? raw : {};
	const savedOrder = Array.isArray(saved.order) ? saved.order.filter((key) => typeof key === "string" && known.has(key)) : [];
	const savedHidden = Array.isArray(saved.hidden) ? new Set(saved.hidden.filter((key) => typeof key === "string" && known.has(key))) : /* @__PURE__ */ new Set();
	const order = [.../* @__PURE__ */ new Set([...savedOrder, ...allKeys])];
	const hidden = order.filter((key) => savedHidden.has(key));
	if (hidden.length >= order.length) hidden.pop();
	return {
		order,
		hidden
	};
};
/**
* 从归一配置取可见列键（按 order 顺序）
* @param config 归一配置
* @returns 可见列键列表
*/
var visibleDividendColumns = (config) => config.order.filter((key) => !config.hidden.includes(key));
//#endregion
//#region plugins/dsh-dividend-screen/DividendColumnSettings.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$1 = { class: "w-5 shrink-0 text-right text-xs tabular-nums text-text-tertiary" };
var _hoisted_2$1 = { class: "flex min-w-0 flex-1 cursor-pointer items-center gap-2" };
var _hoisted_3$1 = [
	"checked",
	"aria-label",
	"onChange"
];
//#endregion
//#region plugins/dsh-dividend-screen/DividendColumnSettings.vue
var DividendColumnSettings_default = /* @__PURE__ */ defineComponent({
	__name: "DividendColumnSettings",
	props: { settings: {} },
	setup(__props) {
		const props = __props;
		/** 归一后的当前配置（直接依赖 settings.values，保存后自动重渲染） */
		const config = computed(() => normalizeDividendColumnConfig(props.settings.values[DIVIDEND_SETTINGS_COLUMN_KEY], DIVIDEND_CONFIGURABLE_COLUMN_KEYS));
		/** 可见列数 */
		const visibleCount = computed(() => visibleDividendColumns(config.value).length);
		/**
		* 列顺序的可写视图：拖拽结束后整组落库（隐藏集合不变，只按新顺序过滤对齐）
		*/
		const orderModel = computed({
			get: () => config.value.order,
			set: (order) => {
				props.settings.set(DIVIDEND_SETTINGS_COLUMN_KEY, {
					order,
					hidden: order.filter((key) => config.value.hidden.includes(key))
				});
			}
		});
		/**
		* 切换一列的显隐（即时落库；收起最后一列的操作被忽略）
		* @param key 列键
		* @param checked 是否勾选（勾选 = 显示）
		*/
		const onToggle = (key, checked) => {
			if (!checked && visibleCount.value <= 1) return;
			const current = config.value;
			const hidden = new Set(current.hidden);
			if (checked) hidden.delete(key);
			else hidden.add(key);
			props.settings.set(DIVIDEND_SETTINGS_COLUMN_KEY, {
				order: [...current.order],
				hidden: current.order.filter((candidate) => hidden.has(candidate))
			});
		};
		/** 恢复默认：代码声明顺序 + 全部显示（只重置列配置，不动其他设置键） */
		const onResetDefault = () => {
			props.settings.set(DIVIDEND_SETTINGS_COLUMN_KEY, {
				order: [...DIVIDEND_CONFIGURABLE_COLUMN_KEYS],
				hidden: []
			});
		};
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", null, [
				_cache[2] || (_cache[2] = createElementVNode("p", { class: "mb-2 text-xs text-text-tertiary" }, " 勾选要显示的列，拖拽手柄调整顺序（即时生效）；「操作」列固定最左、「规则」列固定最右，不参与调整。 ", -1)),
				createVNode(unref(lo), {
					modelValue: orderModel.value,
					"onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => orderModel.value = $event),
					tag: "ul",
					animation: 150,
					handle: "[data-drag-handle]",
					"force-fallback": true,
					"fallback-class": "sortable-fallback bg-surface shadow-lg ring-1 ring-flat-weak",
					"ghost-class": "opacity-40",
					"chosen-class": "bg-flat-weak",
					class: "space-y-1"
				}, {
					default: withCtx(() => [(openBlock(true), createElementBlock(Fragment, null, renderList(config.value.order, (key, index) => {
						return openBlock(), createElementBlock("li", {
							key,
							class: "flex select-none items-center gap-2.5 rounded-lg border border-flat-weak px-2.5 py-1.5 text-sm"
						}, [
							createCommentVNode(" 拖拽手柄：内联 grip 图标而不是 `deps.ui.Icon` ——\n             本组件由宿主的设置弹窗渲染，宿主只注入 settings，拿不到插件自己的 props。\n             手柄用**属性选择器**而不是类名：只为「选中元素」存在的标记不是 Tailwind 工具类，\n             产物 CSS 里永远不会有它的规则（样式审计会一直告警），样式交给下面这几个真正的工具类。 "),
							_cache[1] || (_cache[1] = createElementVNode("svg", {
								"data-drag-handle": "",
								class: "shrink-0 cursor-grab text-text-tertiary active:cursor-grabbing",
								width: "15",
								height: "15",
								viewBox: "0 0 24 24",
								fill: "currentColor",
								"aria-hidden": "true"
							}, [
								createElementVNode("circle", {
									cx: "9",
									cy: "6",
									r: "1"
								}),
								createElementVNode("circle", {
									cx: "15",
									cy: "6",
									r: "1"
								}),
								createElementVNode("circle", {
									cx: "9",
									cy: "12",
									r: "1"
								}),
								createElementVNode("circle", {
									cx: "15",
									cy: "12",
									r: "1"
								}),
								createElementVNode("circle", {
									cx: "9",
									cy: "18",
									r: "1"
								}),
								createElementVNode("circle", {
									cx: "15",
									cy: "18",
									r: "1"
								})
							], -1)),
							createElementVNode("span", _hoisted_1$1, toDisplayString(index + 1), 1),
							createElementVNode("label", _hoisted_2$1, [createElementVNode("input", {
								type: "checkbox",
								class: "h-4 w-4 shrink-0 cursor-pointer rounded border-flat-weak accent-primary",
								checked: !config.value.hidden.includes(key),
								"aria-label": `显示${unref(DIVIDEND_COLUMN_LABEL)[key]}`,
								onChange: ($event) => onToggle(key, $event.target.checked)
							}, null, 40, _hoisted_3$1), createElementVNode("span", { class: normalizeClass(["truncate", config.value.hidden.includes(key) ? "text-text-tertiary line-through" : "text-text"]) }, toDisplayString(unref(DIVIDEND_COLUMN_LABEL)[key]), 3)])
						]);
					}), 128))]),
					_: 1
				}, 8, ["modelValue"]),
				createElementVNode("button", {
					type: "button",
					class: "pressable mt-3 rounded-lg px-2 py-1 text-xs text-text-tertiary hover:bg-flat-weak hover:text-text active:scale-95",
					onClick: onResetDefault
				}, " 恢复默认列配置 ")
			]);
		};
	}
});
//#endregion
//#region plugins/dsh-dividend-screen/em-parse.ts
/**
* 插件 dsh-dividend-screen（股息筛选）· 纯解析层
*
* 三个解析函数只做「上游文本 → 类型化行」，不联网、无副作用，
* 冒烟测试直接喂真实响应文本断言（见 `.ai/tmp/dividend-screen-smoke.mjs`）。
*
* 数值纪律：`"-"` / 空 / 非数一律 null —— 绝不把「无数据」当 0
* （0 是合法业务值：分红为零、增速为零都真实存在，混进 null 会污染推算）。
*/
/**
* 数值字段（非有限数一律 null）
* @param value 原始字段值
* @returns 数值；无法解析为 null
*/
var toNumber = (value) => {
	if (typeof value === "number") return Number.isFinite(value) ? value : null;
	if (typeof value === "string") {
		const text = value.trim();
		if (text === "" || text === "-") return null;
		const parsed = Number(text);
		return Number.isFinite(parsed) ? parsed : null;
	}
	return null;
};
/**
* 文本字段（非字符串一律空串）
* @param value 原始字段值
* @returns 去空白后的文本
*/
var toText = (value) => typeof value === "string" ? value.trim() : "";
/**
* 解析 clist 股息率排行单页（纯函数）
*
* `data.diff` 带 `np=1` 时是数组，历史形态也可能是对象映射，两种都兼容；
* `data.total` 是上游自报的全市场行数（样本池覆盖率的分母）。
* @param text 响应文本（UTF-8 JSON）
* @returns `{ rows, total }`；rows 按返回顺序（已按股息率降序），total 解析不到为 null
*/
var parseRankPage = (text) => {
	let payload;
	try {
		payload = JSON.parse(text);
	} catch {
		return {
			rows: [],
			total: null
		};
	}
	const total = toNumber(payload.data?.total);
	const diff = payload.data?.diff;
	const rawRows = Array.isArray(diff) ? diff : diff && typeof diff === "object" ? Object.values(diff) : [];
	const rows = [];
	for (const raw of rawRows) {
		if (!raw || typeof raw !== "object") continue;
		const row = raw;
		const code = toText(row[EM_RANK_FIELD.CODE]);
		const name = toText(row[EM_RANK_FIELD.NAME]);
		if (!code || !name) continue;
		rows.push({
			code,
			name,
			price: toNumber(row[EM_RANK_FIELD.PRICE]),
			changePercent: toNumber(row[EM_RANK_FIELD.CHANGE_PERCENT]),
			marketCap: toNumber(row[EM_RANK_FIELD.MARKET_CAP]),
			pb: toNumber(row[EM_RANK_FIELD.PB]),
			totalShares: toNumber(row[EM_RANK_FIELD.TOTAL_SHARES]),
			peTtm: toNumber(row[EM_RANK_FIELD.PE_TTM]),
			ttmYield: toNumber(row[EM_RANK_FIELD.DIVIDEND_YIELD])
		});
	}
	return {
		rows,
		total
	};
};
/**
* 解析 datacenter 业绩报表响应（纯函数）
* @param text 响应文本（UTF-8 JSON）
* @returns 业绩行（未披露的股票不在返回里，调用方以「缺席 = 未披露」处理）
*/
var parsePerfRows = (text) => {
	let payload;
	try {
		payload = JSON.parse(text);
	} catch {
		return [];
	}
	const rawRows = payload.result?.data;
	if (!Array.isArray(rawRows)) return [];
	const rows = [];
	for (const raw of rawRows) {
		if (!raw || typeof raw !== "object") continue;
		const row = raw;
		const code = toText(row[EM_PERF_FIELD.CODE]);
		if (!code) continue;
		rows.push({
			code,
			netProfit: toNumber(row[EM_PERF_FIELD.NET_PROFIT]),
			netProfitYoY: toNumber(row[EM_PERF_FIELD.NET_PROFIT_YOY]),
			revenueYoY: toNumber(row[EM_PERF_FIELD.REVENUE_YOY]),
			industry: toText(row[EM_PERF_FIELD.INDUSTRY]),
			ocfPerShare: toNumber(row[EM_PERF_FIELD.OCF_PER_SHARE])
		});
	}
	return rows;
};
/**
* 解析 datacenter 分红明细响应（纯函数，逐事件）
*
* 多期合并查询（`REPORT_DATE in (...)`）后事件按报告期分组，`reportDate`
* 由上游 `REPORT_DATE` 截前 10 位得到（上游形如 `2025-12-31 00:00:00`）。
* @param text 响应文本（UTF-8 JSON）
* @returns 分红事件行（纯转增 / 派息字段为空 / 缺报告期的方案被过滤）
*/
var parseDividendEvents = (text) => {
	let payload;
	try {
		payload = JSON.parse(text);
	} catch {
		return [];
	}
	const rawRows = payload.result?.data;
	if (!Array.isArray(rawRows)) return [];
	const events = [];
	for (const raw of rawRows) {
		if (!raw || typeof raw !== "object") continue;
		const row = raw;
		const code = toText(row[EM_DIVIDEND_FIELD.CODE]);
		const perTen = toNumber(row[EM_DIVIDEND_FIELD.BONUS_PER_TEN]);
		const reportDate = toText(row[EM_DIVIDEND_FIELD.REPORT_DATE]).slice(0, 10);
		if (!code || !reportDate || perTen === null || perTen <= 0) continue;
		events.push({
			code,
			dps: perTen / 10,
			totalShares: toNumber(row[EM_DIVIDEND_FIELD.TOTAL_SHARES]),
			reportDate,
			exDate: toText(row[EM_DIVIDEND_FIELD.EX_DATE]).slice(0, 10) || null
		});
	}
	return events;
};
/**
* 取两条实施日中最新的非空值（纯函数；同报告期多条方案时除息日可能不同）
* @param a 现有聚合的实施日（可为 null）
* @param b 新事件实施日（可为 null）
* @returns 较新的非空实施日；两者皆空为 null
*/
var latestExDate = (a, b) => {
	if (!a) return b ?? null;
	if (!b) return a;
	return a > b ? a : b;
};
/**
* 按（代码 × 报告期）分组聚合分红事件（纯函数；同代码同报告期多条方案求和，
* 实施日取最新非空 —— TTM 归集按实施日锚定）
* @param events 分红事件行
* @returns 代码 → 报告期（`YYYY-MM-DD`）→ 聚合结果
*/
var groupDividendEventsByDate = (events) => {
	const grouped = /* @__PURE__ */ new Map();
	for (const event of events) {
		let byDate = grouped.get(event.code);
		if (!byDate) {
			byDate = /* @__PURE__ */ new Map();
			grouped.set(event.code, byDate);
		}
		const current = byDate.get(event.reportDate);
		if (current) byDate.set(event.reportDate, {
			code: event.code,
			dps: current.dps + event.dps,
			totalShares: event.totalShares ?? current.totalShares,
			exDate: latestExDate(current.exDate ?? null, event.exDate ?? null)
		});
		else byDate.set(event.reportDate, {
			code: event.code,
			dps: event.dps,
			totalShares: event.totalShares,
			exDate: event.exDate ?? null
		});
	}
	return grouped;
};
/**
* 解析 datacenter 资产负债表摘要响应（纯函数）
* @param text 响应文本（UTF-8 JSON）
* @returns 负债率行（同一代码多报告期时保留全部，由取数层择新）
*/
var parseDebtRows = (text) => {
	let payload;
	try {
		payload = JSON.parse(text);
	} catch {
		return [];
	}
	const rawRows = payload.result?.data;
	if (!Array.isArray(rawRows)) return [];
	const rows = [];
	for (const raw of rawRows) {
		if (!raw || typeof raw !== "object") continue;
		const row = raw;
		const code = toText(row[EM_BALANCE_FIELD.CODE]);
		const reportDate = toText(row[EM_BALANCE_FIELD.REPORT_DATE]).slice(0, 10);
		const ratio = toNumber(row[EM_BALANCE_FIELD.DEBT_ASSET_RATIO]);
		if (!code || !reportDate || ratio === null) continue;
		rows.push({
			code,
			ratio,
			reportDate
		});
	}
	return rows;
};
//#endregion
//#region plugins/dsh-dividend-screen/em-data.ts
/**
* 插件 dsh-dividend-screen（股息筛选）· 取数层（东方财富）
*
* 三个 fetch 包装，全部走宿主 `proxyFetch`（Tauri 走 Rust 直连 / 浏览器走 /stock-proxy，
* `eastmoney.com` 已在代理白名单与 Tauri capabilities 内，无需新增配置）。
*
* 频率纪律（SERVER_API 红线）：
* - 全部**串行**、同上游请求之间留间隔（行情域 1s / 数据中心 600ms）；
* - 东财会直接掐断连接（`fetch failed`，非 HTTP 错误码）→ 原地小步重试是唯一有效兜底；
* - 只由用户点击「扫描排行」触发，不轮询；结果落库后重进页面不再联网。
*
* 请求量估算（样本池 200 / 分块 100）：排行 2 页 + 业绩 3 期 × 2 块 + 分红 2 期 × 2 块 ≈ 12 次。
*
* ⚠️ 宿主能力（网络请求与限速节拍）**不由本模块 import**，而是以 `deps` 形式沿调用链注入：
* 本插件最终以单文件产物分发，运行时拿不到任何宿主模块。
*/
/**
* 分块一个代码清单（保持顺序）
* @param codes 代码清单
* @returns 代码分块
*/
var chunkCodes = (codes) => {
	const chunks = [];
	for (let index = 0; index < codes.length; index += 100) chunks.push(codes.slice(index, index + 100));
	return chunks;
};
/**
* 带原地重试的一次请求（东财掐连接是常态，等一小会重试即恢复）
* @param deps 宿主能力
* @param url 请求地址
* @param referer Referer 头
* @returns 响应文本
*/
var fetchTextWithRetry = async (deps, url, referer) => {
	let lastError = "未知错误";
	for (let attempt = 0; attempt < 3; attempt += 1) {
		if (attempt > 0) await deps.format.delay(EM_FETCH_RETRY_DELAY_MS);
		try {
			const response = await deps.http.fetch(url, { headers: { Referer: referer } });
			if (!response.ok) {
				lastError = `HTTP ${response.status}`;
				continue;
			}
			return await response.text();
		} catch (error) {
			lastError = error instanceof Error ? error.message : String(error);
		}
	}
	throw new Error(lastError);
};
/**
* 拉取股息率排行前 N（clist `fid=f133` 降序，分页串行）
*
* 分页防漂移三件套（f133 随现价实时变，行会在页边界搬家）：
* 按代码去重；收不满 `limit` 且上一页还有数据就继续翻（护栏 `DIVIDEND_RANK_MAX_PAGES`）；
* 排序只用于**选样本池**，展示口径全部由推算层自算，个别边界股进出不影响数据正确性。
* @param deps 宿主能力
* @param limit 样本池大小
* @param onRequest 每完成一个分页请求回调一次（进度条计数）
* @returns `{ rows, total }`；rows 为前 limit 行（按 TTM 股息率降序），total 为上游全市场行数
*/
var fetchDividendRank = async (deps, limit, onRequest) => {
	const merged = /* @__PURE__ */ new Map();
	let total = null;
	for (let page = 1; page <= 6; page += 1) {
		if (page > 1) await deps.format.delay(EM_RANK_DELAY_MS);
		const { rows, total: pageTotal } = parseRankPage(await fetchTextWithRetry(deps, `${DIVIDEND_RANK_URL}?${DIVIDEND_RANK_QUERY.replace(DIVIDEND_RANK_PAGE_TOKEN, String(page))}`, EM_QUOTE_REFERER));
		onRequest?.();
		if (pageTotal !== null) total = pageTotal;
		for (const row of rows) if (!merged.has(row.code)) merged.set(row.code, row);
		if (merged.size >= limit || rows.length === 0) break;
	}
	return {
		rows: [...merged.values()].slice(0, limit),
		total
	};
};
/**
* 单股精确查询（`ulist.np` 按 secids 精确取行情）
*
* 字段与排行 clist **完全同构**（f12/f14/f2/…/f133，`fltt=2&invt=2` 下同为真值小数），
* 返回体也是 `data.diff` 数组 → 直接复用 `parseRankPage` 解析成 `RankBaseRow`。
* 用途：自选 tab 搜索预览时，样本池外的个股按需补一次行情（点击触发，不轮询）。
*/
var EM_ULIST_URL = "https://push2delay.eastmoney.com/api/qt/ulist.np/get";
/** 单股精确查询串（`{secid}` 由取数层替换） */
var EM_ULIST_QUERY = "secids={secid}&fields=f12,f14,f2,f3,f20,f23,f38,f115,f133&fltt=2&invt=2";
/**
* 6 位裸代码 → ulist secid 的市场前缀（`1.` = 沪，`0.` = 深）
*
* 股息语境只有沪深 A 股（搜索层已过滤），北交所（4/8 开头）不在支持范围。
* @param code 6 位裸代码
* @returns 市场前缀
*/
var marketPrefix = (code) => code.startsWith("6") ? "1" : "0";
/**
* 精确查询单只股票的行情基准行（字段与排行一致，可直接进推算层）
* @param deps 宿主能力
* @param code 6 位裸代码
* @returns 排行基准行；上游未返回该股（退市 / 非沪深）为 null
*/
var fetchRankRowByCode = async (deps, code) => {
	const { rows } = parseRankPage(await fetchTextWithRetry(deps, `${EM_ULIST_URL}?${EM_ULIST_QUERY.replace("{secid}", `${marketPrefix(code)}.${code}`)}`, EM_QUOTE_REFERER));
	return rows.find((row) => row.code === code) ?? null;
};
/**
* 组装 datacenter 的查询串（报告期 in 多值 + 代码 in 分块）
* @param reportName 报表名
* @param reportDateField 该报表的报告期字段名（三个报表各不相同）
* @param columns 取用列
* @param reportDates 报告期清单（`YYYY-MM-DD`；多期合并一次查，省请求数）
* @param codes 代码分块
* @returns 完整 URL
*/
var buildDatacenterUrl = (reportName, reportDateField, columns, reportDates, codes) => {
	const filter = `(${reportDateField} in (${reportDates.map((date) => `'${date}'`).join(",")}))(${EM_SECURITY_CODE_FIELD} in (${codes.map((code) => `"${code}"`).join(",")}))`;
	return `${EM_DATACENTER_URL}?${new URLSearchParams({
		sortColumns: EM_SECURITY_CODE_FIELD,
		sortTypes: "1",
		pageSize: String(500),
		pageNumber: "1",
		reportName,
		columns,
		filter
	}).toString()}`;
};
/**
* 请求一次 datacenter（校验 success 标记与 result 形态，防「200 但无数据」被当成功）
* @param deps 宿主能力
* @param reportName 报表名
* @param reportDateField 该报表的报告期字段名
* @param columns 取用列
* @param reportDates 报告期清单
* @param codes 代码分块
* @returns 响应文本（已确认 success 且 result.data 为数组）
*/
var fetchDatacenter = async (deps, reportName, reportDateField, columns, reportDates, codes) => {
	const text = await fetchTextWithRetry(deps, buildDatacenterUrl(reportName, reportDateField, columns, reportDates, codes), EM_DATA_REFERER);
	let payload;
	try {
		payload = JSON.parse(text);
	} catch {
		throw new Error("数据中心返回了无法解析的内容");
	}
	if (payload["success"] === false) {
		const message = typeof payload.message === "string" ? `：${payload.message}` : "";
		throw new Error(`数据中心拒绝本次查询（${reportName} @ ${reportDates.join(",")}）${message}`);
	}
	if (payload.result?.data !== void 0 && !Array.isArray(payload.result.data)) throw new Error("数据中心返回结构异常（result.data 非数组）");
	return text;
};
/**
* 拉取一批代码在指定报告期的业绩（分块串行）
* @param deps 宿主能力
* @param codes 6 位裸代码清单
* @param reportDate 报告期（如 `2026-06-30`）
* @param onRequest 每完成一个分块请求回调一次
* @returns 代码 → 业绩行（缺席 = 该股该期未披露）
*/
var fetchPerfByCodes = async (deps, codes, reportDate, onRequest) => {
	const merged = /* @__PURE__ */ new Map();
	for (const chunk of chunkCodes(codes)) {
		if (merged.size > 0) await deps.format.delay(600);
		const text = await fetchDatacenter(deps, EM_PERF_REPORT_NAME, EM_PERF_REPORT_DATE_FIELD, EM_PERF_COLUMNS, [reportDate], chunk);
		for (const row of parsePerfRows(text)) merged.set(row.code, row);
		onRequest?.();
	}
	return merged;
};
/**
* 拉取一批代码在多个报告期的分红（分块串行，多期合并一次查询按期分组）
*
* 5 年分红史 + 去年年度 + 今年中期合并成一个 `in` 过滤，**每分块只发 1 次请求**
* ——连续分红年数这个规则指标是零额外请求拿到的。
* @param deps 宿主能力
* @param codes 6 位裸代码清单
* @param reportDates 报告期清单（如 `['2025-12-31','2026-06-30']`）
* @param onRequest 每完成一个分块请求回调一次
* @returns 代码 → 报告期 → 分红聚合（缺席 = 该股该期无现金分红方案）
*/
var fetchDividendsByCodes = async (deps, codes, reportDates, onRequest) => {
	const merged = /* @__PURE__ */ new Map();
	for (const chunk of chunkCodes(codes)) {
		if (merged.size > 0) await deps.format.delay(600);
		const text = await fetchDatacenter(deps, EM_DIVIDEND_REPORT_NAME, EM_DIVIDEND_REPORT_DATE_FIELD, EM_DIVIDEND_COLUMNS, reportDates, chunk);
		for (const [code, byDate] of groupDividendEventsByDate(parseDividendEvents(text))) {
			const existing = merged.get(code);
			if (existing) for (const [date, aggregate] of byDate) existing.set(date, aggregate);
			else merged.set(code, byDate);
		}
		onRequest?.();
	}
	return merged;
};
/**
* 拉取一批代码的最新负债率（分块串行；多个报告期一次查询，逐代码取最新已披露期）
* @param deps 宿主能力
* @param codes 6 位裸代码清单
* @param reportDates 候选报告期清单（如今年中报 + 去年年报，覆盖披露进度差）
* @param onRequest 每完成一个分块请求回调一次
* @returns 代码 → 负债率快照（缺席 = 两个报告期都未披露资产负债摘要）
*/
var fetchDebtRatioByCodes = async (deps, codes, reportDates, onRequest) => {
	const merged = /* @__PURE__ */ new Map();
	for (const chunk of chunkCodes(codes)) {
		if (merged.size > 0) await deps.format.delay(600);
		const text = await fetchDatacenter(deps, EM_BALANCE_REPORT_NAME, EM_BALANCE_REPORT_DATE_FIELD, EM_BALANCE_COLUMNS, reportDates, chunk);
		for (const row of parseDebtRows(text)) merged.set(row.code, row);
		onRequest?.();
	}
	return merged;
};
//#endregion
//#region plugins/dsh-dividend-screen/project.ts
/**
* 插件 dsh-dividend-screen（股息筛选）· 推算层（纯函数）
*
* 把「排行快照 + 三个报告期业绩 + 多期分红 + 负债率」合成一行可展示的推算结论。
* 全部逻辑无副作用，冒烟测试用真实上游数值断言（荣晟环保 2026 中报实测案）。
*
* 推算模型（用户口径：**保留去年分红率**）：
* - 去年分红 = 去年财务年度内宣派的全部方案合计（中期 + 末期 + 季度；只取年报期会
*   低估一年多次分红的个股 —— 招商银行 2026-09 实测漏一半）；
* - 去年分红率 = 去年分红总额 ÷ 去年全年归母净利（可为 >100% 的特别分红，照算并标记）；
* - 增长系数 = 今年中报净利 ÷ 去年中报净利（去年基数缺失或 ≤0 → 不可比，不推算）；
* - 预计今年净利 = 去年全年净利 × 增长系数（线性外推，季节性行业会失真，页面明示）；
* - 推算每股分红 = 去年分红率 × 预计今年净利 ÷ 总股本；
* - 推算股息率 = 推算每股分红 ÷ 现价。
*
* 规则引擎指标（同批合成）：
* - 连续分红年数：从去年年报往前数连续有现金分红的年度数；
* - 现金流覆盖倍数 = 每股经营现金流 ÷ 每股分红（每股比值等价于总额比值）；
* - 负债率：取最新已披露报告期（扫描层已择新）。
*
* TTM 股息率：自算 = 近 12 个月内除权除息的每股派息合计 ÷ 现价（同花顺同口径）；
* 东财 f133（≈ 最新年报期分红 ÷ 现价）只用于选样本池，分红史未采集时才回退。
*
* 状态判定按顺序短路：中报未披露 → 中报亏损 → 增长不可比 → 无可比分红率 → 可推算。
*/
/**
* ISO 日期（`YYYY-MM-DD`）平移 N 天（纯函数；闰年边界由 Date 自行消化）
* @param iso 基准日期
* @param days 平移天数（负数 = 往前）
* @returns 平移后的日期
*/
var shiftIsoDate = (iso, days) => {
	const date = /* @__PURE__ */ new Date(`${iso}T00:00:00Z`);
	date.setUTCDate(date.getUTCDate() + days);
	return date.toISOString().slice(0, 10);
};
/**
* 把一个财务年度内的分红聚合合并成单一年度聚合（纯函数）
*
* 「去年分红」的正确口径是**去年财务年度内宣派的全部方案**：一年多次分红的个股
* （如招商银行 2025 年度中期 10 派 10.13 + 末期 10 派 10.03）只取年报期会低估一半
* （2026-09-20 实测）。股本优先取年报期记录（最接近分红率分母的时点），缺席退中期等。
* @param byDate 报告期 → 聚合（可 undefined = 无任何分红记录）
* @param fiscalYear 财务年（如 `2025`，匹配该年全部报告期键）
* @returns 合并后的年度聚合；该年无记录为 undefined
*/
var mergeFiscalYearDividends = (byDate, fiscalYear) => {
	if (!byDate) return void 0;
	let merged;
	for (const [reportDate, aggregate] of byDate) {
		if (!reportDate.startsWith(`${fiscalYear.slice(0, 4)}-`)) continue;
		if (!merged) {
			merged = { ...aggregate };
			continue;
		}
		merged = {
			code: merged.code,
			dps: merged.dps + aggregate.dps,
			totalShares: reportDate.endsWith("-12-31") && aggregate.totalShares !== null ? aggregate.totalShares : merged.totalShares ?? aggregate.totalShares,
			exDate: merged.exDate ?? aggregate.exDate
		};
	}
	return merged;
};
/**
* 计算近 12 个月已实施的每股派息合计（纯函数，TTM 股息率的分子）
*
* 按除权除息日归集（现金流的真实时点），与同花顺「股息(TTM)」同口径；
* 东财 `f133` 只算最新年报期分红，一年多次分红的个股会被低估（招行实测漏一半）。
* @param byDate 报告期 → 聚合（undefined = 分红史未采集）
* @param today 当前日期（`YYYY-MM-DD`）
* @returns TTM 每股派息；分红史未采集或全部方案未实施为 null（不可计算）
*/
var computeTtmDps = (byDate, today) => {
	if (!byDate) return null;
	const windowStart = shiftIsoDate(today, -365);
	let total = null;
	for (const aggregate of byDate.values()) {
		if (!aggregate.exDate || aggregate.exDate <= windowStart || aggregate.exDate > today) continue;
		total = (total ?? 0) + aggregate.dps;
	}
	return total;
};
/**
* 解析推算状态（纯函数，判定顺序即优先级）
* @param netProfitH1 今年中报净利（null = 未披露）
* @param netProfitH1Last 去年中报净利（null = 未披露）
* @param payoutLast 去年分红率（null = 不可得）
* @returns 推算状态
*/
var resolveProjectStatus = (netProfitH1, netProfitH1Last, payoutLast) => {
	if (netProfitH1 === null) return DIVIDEND_PROJECT_STATUS.NO_REPORT;
	if (netProfitH1 <= 0) return DIVIDEND_PROJECT_STATUS.H1_LOSS;
	if (netProfitH1Last === null || netProfitH1Last <= 0) return DIVIDEND_PROJECT_STATUS.BASE_INVALID;
	if (payoutLast === null) return DIVIDEND_PROJECT_STATUS.NO_PAYOUT;
	return DIVIDEND_PROJECT_STATUS.OK;
};
/**
* 从去年年报往前数连续现金分红的年度数（纯函数）
*
* 锚年（去年年报）无分红 = 0；分红史未采集返回 null（规则按数据缺失处理）；
* 中途某年缺记录（未分红或停牌等）即停。入参的 Map 直接复用扫描返回的
* 「报告期 → 聚合」分桶（里面含中期报告期，但本函数只查 `YYYY-12-31` 键，天然忽略）。
* @param fyDividends 报告期 → 分红聚合
* @param fyLastDate 锚年报告期（如 `2025-12-31`）
* @returns 连续分红年数；分红史未采集为 null
*/
var countConsecutiveDividendYears = (fyDividends, fyLastDate) => {
	if (!fyDividends || !fyLastDate) return null;
	const anchorYear = Number(fyLastDate.slice(0, 4));
	if (!Number.isFinite(anchorYear)) return null;
	let years = 0;
	for (let offset = 0; offset < 100; offset += 1) {
		const aggregate = fyDividends.get(`${anchorYear - offset}-12-31`);
		if (aggregate === void 0 || aggregate.dps <= 0) break;
		years += 1;
	}
	return years;
};
/**
* 合成一行推算结论（纯函数）
* @param inputs 输入集合（各数据源缺席语义见 `ScreenRowInputs`）
* @returns 落库展示行
*/
var buildScreenRow = (inputs) => {
	const { base, h1, h1Last, fyLast, divLast, divInterim, fyDividends, fyLastDate, debt } = inputs;
	const today = inputs.today ?? (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
	const dpsLast = divLast?.dps ?? 0;
	const dividendShares = divLast?.totalShares ?? base.totalShares;
	const dividendTotalLast = divLast !== void 0 && dividendShares !== null ? dpsLast * dividendShares : null;
	const netProfitFyLast = fyLast?.netProfit ?? null;
	const payoutLast = dividendTotalLast !== null && dividendTotalLast > 0 && netProfitFyLast !== null && netProfitFyLast > 0 ? dividendTotalLast / netProfitFyLast : null;
	const netProfitH1 = h1?.netProfit ?? null;
	const netProfitH1Last = h1Last?.netProfit ?? null;
	const growthH1 = netProfitH1 !== null && netProfitH1Last !== null && netProfitH1Last > 0 ? netProfitH1 / netProfitH1Last : null;
	const status = resolveProjectStatus(netProfitH1, netProfitH1Last, payoutLast);
	const ok = status === DIVIDEND_PROJECT_STATUS.OK;
	const projectedNetProfit = ok && netProfitFyLast !== null && growthH1 !== null ? netProfitFyLast * growthH1 : null;
	const projectedDividendTotal = ok && projectedNetProfit !== null && payoutLast !== null ? payoutLast * projectedNetProfit : null;
	const projectedDps = ok && projectedDividendTotal !== null && base.totalShares !== null && base.totalShares > 0 ? projectedDividendTotal / base.totalShares : null;
	const projectedYield = projectedDps !== null && base.price !== null && base.price > 0 ? projectedDps / base.price * 100 : null;
	const yieldLast = base.price !== null && base.price > 0 ? dpsLast / base.price * 100 : null;
	const ttmDps = computeTtmDps(fyDividends, today);
	const ttmYieldSelf = ttmDps !== null && base.price !== null && base.price > 0 ? ttmDps / base.price * 100 : null;
	const dividendYears = countConsecutiveDividendYears(fyDividends, fyLastDate);
	const ocfPerShareLast = fyLast?.ocfPerShare ?? null;
	const cashCoverLast = ocfPerShareLast !== null && dpsLast > 0 ? ocfPerShareLast / dpsLast : null;
	return {
		code: base.code,
		name: base.name,
		industry: h1?.industry || fyLast?.industry || "",
		price: base.price,
		changePercent: base.changePercent,
		marketCap: base.marketCap,
		pb: base.pb,
		peTtm: base.peTtm,
		totalShares: base.totalShares,
		ttmYield: ttmYieldSelf ?? base.ttmYield,
		dpsLast,
		dividendTotalLast,
		netProfitFyLast,
		payoutLast,
		netProfitH1,
		netProfitH1Last,
		netProfitYoY: h1?.netProfitYoY ?? null,
		revenueYoY: h1?.revenueYoY ?? null,
		growthH1,
		projectedNetProfit,
		projectedDps,
		projectedYield,
		yieldLast,
		interimDps: divInterim?.dps ?? null,
		dividendYears,
		ocfPerShareLast,
		cashCoverLast,
		debtRatio: debt?.ratio ?? null,
		status
	};
};
/**
* 落库行的默认排序（纯函数）
*
* 推算股息率降序为第一优先（本插件的核心产出），不可推算的行沉底后按
* TTM 股息率降序排（它们仍有「市面排行」的参考价值）。
* @param rows 落库行
* @returns 排序后的新数组（不改入参）
*/
var sortScreenRows = (rows) => [...rows].sort((a, b) => {
	const aYield = a.projectedYield ?? Number.NEGATIVE_INFINITY;
	const bYield = b.projectedYield ?? Number.NEGATIVE_INFINITY;
	if (aYield !== bYield) return bYield - aYield;
	const aTtm = a.ttmYield ?? Number.NEGATIVE_INFINITY;
	return (b.ttmYield ?? Number.NEGATIVE_INFINITY) - aTtm;
});
//#endregion
//#region plugins/dsh-dividend-screen/scan.ts
/**
* 插件 dsh-dividend-screen（股息筛选）· 扫描编排
*
* 一次扫描 = 股息率排行前 N（push2delay clist）→ 三个报告期业绩（datacenter 业绩报表，
* `in` 代码分块）→ 多期分红合并查询（5 个年度 × 4 个季度报告期，一个 `in` 过滤一次查完；
* 年报期数连续分红年数，中期 / 季度期供「去年分红合计」与 TTM 除息日归集）
* → 两个报告期的负债率摘要 → 推算合成（含连续分红年数 / 现金流覆盖等规则指标）→ 全量落库。
*
* 报告期随当前年份自适应：今年中报 = `${今年}-06-30`，去年中报 / 去年年报同理；
* 中报披露季（8~9 月）部分股票尚未披露 → 状态记「中报未披露」，行保留、不静默丢。
*
* 频率纪律：全部串行 + 同上游间隔，总请求量 ≈ 排行页数 + 5 × 代码分块数
* （业绩 3 + 分红 1 + 负债 1；样本池 200 时约 12 次）；只由用户点击触发，不轮询。
*/
/**
* 生成参与推算的四个报告期（随当前年份自适应）
* @returns 报告期集合
*/
var resolveReportPeriods = () => {
	const year = (/* @__PURE__ */ new Date()).getFullYear();
	return {
		h1: `${year}-06-30`,
		h1Last: `${year - 1}-06-30`,
		fyLast: `${year - 1}-12-31`,
		interim: `${year}-06-30`
	};
};
/**
* 生成连续分红年数的回看年度清单（锚年 = 去年年报，往前 `DIVIDEND_HISTORY_YEARS` 年）
*
* 每年取**全部四个季度报告期**：年报期给连续分红年数用；中期 / 季度期给「去年分红
* 合计」（一年多次分红个股只取年报期会低估一半，招行 2026-09 实测）与 TTM
* （按除权除息日归集，回看窗口可能落在中期 / 季度方案的除息日上）用。
* 同一个 `in` 过滤一次查完，多日期零额外请求。
* @param fyLast 去年年报报告期（如 `2025-12-31`）
* @returns 报告期清单（含锚年各期；`in` 过滤不关心顺序）
*/
var resolveDividendHistoryDates = (fyLast) => {
	const anchorYear = Number(fyLast.slice(0, 4));
	const dates = [];
	for (let offset = 0; offset < 5; offset += 1) {
		const year = anchorYear - offset;
		dates.push(`${year}-12-31`, `${year}-09-30`, `${year}-06-30`, `${year}-03-31`);
	}
	return dates;
};
/**
* 执行一次股息筛选扫描并落库
* @param deps 宿主能力（取数与限速节拍经它注入；产物形态下没有 import 可用）
* @param repo 快照仓储
* @param universeLimit 样本池大小（按 TTM 股息率取前 N）
* @param onProgress 进度回调（按请求数计）
* @returns 扫描结果
*/
var runDividendScan = async (deps, repo, universeLimit, onProgress) => {
	const periods = resolveReportPeriods();
	let rankPages = 0;
	const rank = await fetchDividendRank(deps, universeLimit, () => {
		rankPages += 1;
	});
	const codes = rank.rows.map((row) => row.code);
	if (codes.length === 0) throw new Error("排行接口未返回任何行（上游可能限速，稍后重试）");
	const chunkCount = chunkCodes(codes).length;
	const totalRequests = rankPages + chunkCount * 5;
	let done = rankPages;
	/** 计一次完成并上报进度 */
	const tick = () => {
		done += 1;
		onProgress?.({
			done,
			total: totalRequests
		});
	};
	onProgress?.({
		done,
		total: totalRequests
	});
	const perfH1 = await fetchPerfByCodes(deps, codes, periods.h1, tick);
	const perfH1Last = await fetchPerfByCodes(deps, codes, periods.h1Last, tick);
	const perfFyLast = await fetchPerfByCodes(deps, codes, periods.fyLast, tick);
	const divAll = await fetchDividendsByCodes(deps, codes, [...resolveDividendHistoryDates(periods.fyLast), periods.interim], tick);
	const debtAll = await fetchDebtRatioByCodes(deps, codes, [periods.h1, periods.fyLast], tick);
	const rows = sortScreenRows(rank.rows.map((base) => buildScreenRow({
		base,
		h1: perfH1.get(base.code),
		h1Last: perfH1Last.get(base.code),
		fyLast: perfFyLast.get(base.code),
		divLast: mergeFiscalYearDividends(divAll.get(base.code), periods.fyLast),
		divInterim: divAll.get(base.code)?.get(periods.interim),
		fyDividends: divAll.get(base.code),
		fyLastDate: periods.fyLast,
		debt: debtAll.get(base.code)
	})));
	const meta = {
		scannedAt: Date.now(),
		universeLimit,
		universeTotal: rank.total,
		rowCount: rows.length,
		publishedCount: rows.filter((row) => row.netProfitH1 !== null).length,
		projectableCount: rows.filter((row) => row.status === DIVIDEND_PROJECT_STATUS.OK).length,
		periods,
		warnings: []
	};
	await repo.saveScan(rows, meta);
	return {
		rows,
		meta
	};
};
/**
* 按需拉取单只股票的完整展示行（自选 tab 搜索预览用）
*
* 样本池外的个股不走全量扫描：单股精确行情（ulist.np，1 次）+ 三期业绩 + 多期分红
* + 负债（datacenter 各 1 次，单股不分块）≈ 6 次串行请求，推算口径与扫描完全同源
* （同一个 `buildScreenRow`）。只由用户点击搜索结果触发，不轮询、不落库
* ——预览是临时数据，进自选并扫描后才有持久化快照。
* @param deps 宿主能力
* @param code 6 位裸代码
* @returns 展示行；上游未返回该股行情（退市 / 非沪深）为 null
*/
var fetchScreenRowByCode = async (deps, code) => {
	const periods = resolveReportPeriods();
	const base = await fetchRankRowByCode(deps, code);
	if (!base) return null;
	const perfH1 = await fetchPerfByCodes(deps, [code], periods.h1);
	const perfH1Last = await fetchPerfByCodes(deps, [code], periods.h1Last);
	const perfFyLast = await fetchPerfByCodes(deps, [code], periods.fyLast);
	const divAll = await fetchDividendsByCodes(deps, [code], [...resolveDividendHistoryDates(periods.fyLast), periods.interim]);
	const debt = await fetchDebtRatioByCodes(deps, [code], [periods.h1, periods.fyLast]);
	return buildScreenRow({
		base,
		h1: perfH1.get(code),
		h1Last: perfH1Last.get(code),
		fyLast: perfFyLast.get(code),
		divLast: mergeFiscalYearDividends(divAll.get(code), periods.fyLast),
		divInterim: divAll.get(code)?.get(periods.interim),
		fyDividends: divAll.get(code),
		fyLastDate: periods.fyLast,
		debt: debt.get(code)
	});
};
//#endregion
//#region plugins/dsh-dividend-screen/rules.ts
/**
* 插件 dsh-dividend-screen（股息筛选）· 可配置规则引擎（纯函数）
*
* 两组语义：
* - **筛选（filter）**：全部启用规则须满足才保留（AND）；
* - **排除（exclude）**：任一启用规则命中即剔除并标原因（OR）——
*   「伪高股息剔除」的语义载体。
*
* 判定三值：`true` 命中 / `false` 不命中 / `null` **数据缺失**。
* 缺失的语义不对称：筛选规则视为未满足（宁缺勿滥）、排除规则视为不命中
* （数据缺失不能当罪名）。
*
* 默认预置即用户给的清单：TTM 股息率 > 4% ∧ 总市值 ≥ 100 亿 ∧ 连续 5 年分红 ∧
* 分红率 30~70% ∧ 经营现金流覆盖分红 ∧ 负债率 < 60% ∧ 非周期顶点（行业关键词 + 盈利塌陷两层代理）。
*
* 全部指标在扫描时已算好落库（`DividendScreenRow`），规则评估是纯客户端的，
* 改规则不触发任何网络请求。
*/
/** 规则类型键 */
var DIVIDEND_RULE_TYPE = {
	/** 筛选：TTM 股息率 > X% */
	MIN_TTM_YIELD: "min_ttm_yield",
	/** 筛选：连续分红年数 ≥ X 年 */
	MIN_DIVIDEND_YEARS: "min_dividend_years",
	/** 筛选：去年分红率介于 X~Y%（含端点） */
	PAYOUT_RATIO_RANGE: "payout_ratio_range",
	/** 筛选：去年经营现金流 ÷ 分红总额 ≥ X 倍 */
	CASH_COVER_MIN: "cash_cover_min",
	/** 筛选：总市值 ≥ X 亿元 */
	MIN_MARKET_CAP: "min_market_cap",
	/** 筛选：资产负债率 ≤ X% */
	MAX_DEBT_RATIO: "max_debt_ratio",
	/** 筛选：推算今年股息率 > X%（预置外维度） */
	MIN_PROJECTED_YIELD: "min_projected_yield",
	/** 筛选：去年股息率 > X%（预置外维度） */
	MIN_YIELD_LAST: "min_yield_last",
	/** 筛选：去年每股分红 > X 元（预置外维度） */
	MIN_DPS_LAST: "min_dps_last",
	/** 筛选：PE(TTM) ≤ X（预置外维度） */
	MAX_PE: "max_pe",
	/** 筛选：市净率 ≤ X（预置外维度） */
	MAX_PB: "max_pb",
	/** 筛选：中报净利同比 ≥ X%（预置外维度） */
	MIN_NP_YOY: "min_np_yoy",
	/** 筛选：中报营收同比 ≥ X%（预置外维度） */
	MIN_REV_YOY: "min_rev_yoy",
	/** 筛选：今年中期已宣派分红（预置外维度） */
	HAS_INTERIM_DIVIDEND: "has_interim_dividend",
	/** 筛选：行业含指定关键词（只看，预置外维度） */
	INDUSTRY_WHITELIST: "industry_whitelist",
	/** 排除：行业含周期关键词（周期顶点代理①） */
	INDUSTRY_BLACKLIST: "industry_blacklist",
	/** 排除：中报净利同比 < X%（盈利塌陷，高息不可持续，周期顶点代理②） */
	MAX_INTERIM_DECLINE: "max_interim_decline",
	/** 排除：去年分红率 > X%（透支型特别分红） */
	MAX_PAYOUT_OVERDUE: "max_payout_overdue",
	/** 排除：每股经营现金流为负（分红不靠真金白银） */
	NEGATIVE_OCF: "negative_ocf"
};
/**
* 读数值参数（缺键 / 非有限数回退默认）
* @param params 参数表
* @param fields 该类型的参数字段
* @param key 参数键
* @returns 数值
*/
var numParam = (params, fields, key) => {
	const field = fields.find((item) => item.key === key);
	const fallback = typeof field?.fallback === "number" ? field.fallback : 0;
	const value = params[key];
	return typeof value === "number" && Number.isFinite(value) ? value : fallback;
};
/**
* 读文本参数（缺键 / 非串回退默认）
* @param params 参数表
* @param fields 该类型的参数字段
* @param key 参数键
* @returns 文本
*/
var textParam = (params, fields, key) => {
	const field = fields.find((item) => item.key === key);
	const fallback = typeof field?.fallback === "string" ? field.fallback : "";
	const value = params[key];
	return typeof value === "string" && value.trim() !== "" ? value : fallback;
};
/** 规则类型注册表（评估全部纯函数；新增规则类型在此登记，UI 与持久化自动跟上） */
var RULE_TYPE_REGISTRY = {
	[DIVIDEND_RULE_TYPE.MIN_TTM_YIELD]: {
		key: DIVIDEND_RULE_TYPE.MIN_TTM_YIELD,
		label: "TTM 股息率高于",
		description: "东财口径：近 12 个月已实施派息 ÷ 现价",
		defaultGroup: RULE_GROUP_FILTER,
		params: [{
			key: "min",
			label: "股息率大于",
			kind: "number",
			fallback: 4,
			unit: "%"
		}],
		evaluate: (row, params) => row.ttmYield === null ? null : row.ttmYield > numParam(params, RULE_TYPE_REGISTRY[DIVIDEND_RULE_TYPE.MIN_TTM_YIELD].params, "min")
	},
	[DIVIDEND_RULE_TYPE.MIN_DIVIDEND_YEARS]: {
		key: DIVIDEND_RULE_TYPE.MIN_DIVIDEND_YEARS,
		label: "连续分红年数不少于",
		description: "从去年年报往前数连续有现金分红的年度数",
		defaultGroup: RULE_GROUP_FILTER,
		params: [{
			key: "min",
			label: "连续年数至少",
			kind: "number",
			fallback: 5,
			unit: "年"
		}],
		evaluate: (row, params) => row.dividendYears === null ? null : row.dividendYears >= numParam(params, RULE_TYPE_REGISTRY[DIVIDEND_RULE_TYPE.MIN_DIVIDEND_YEARS].params, "min")
	},
	[DIVIDEND_RULE_TYPE.PAYOUT_RATIO_RANGE]: {
		key: DIVIDEND_RULE_TYPE.PAYOUT_RATIO_RANGE,
		label: "去年分红率介于",
		description: "过高透支、过低抠门；30~70% 是「赚了就分、分了不伤身」的常见带",
		defaultGroup: RULE_GROUP_FILTER,
		params: [{
			key: "min",
			label: "下限",
			kind: "number",
			fallback: 30,
			unit: "%"
		}, {
			key: "max",
			label: "上限",
			kind: "number",
			fallback: 70,
			unit: "%"
		}],
		evaluate: (row, params) => {
			if (row.payoutLast === null) return null;
			const fields = RULE_TYPE_REGISTRY[DIVIDEND_RULE_TYPE.PAYOUT_RATIO_RANGE].params;
			const payoutPercent = row.payoutLast * 100;
			return payoutPercent >= numParam(params, fields, "min") && payoutPercent <= numParam(params, fields, "max");
		}
	},
	[DIVIDEND_RULE_TYPE.CASH_COVER_MIN]: {
		key: DIVIDEND_RULE_TYPE.CASH_COVER_MIN,
		label: "经营现金流覆盖分红",
		description: "每股经营现金流 ÷ 每股分红（每股比值 = 总额比值，股本约掉）",
		defaultGroup: RULE_GROUP_FILTER,
		params: [{
			key: "min",
			label: "覆盖倍数至少",
			kind: "number",
			fallback: 1,
			unit: "×"
		}],
		evaluate: (row, params) => row.cashCoverLast === null ? null : row.cashCoverLast >= numParam(params, RULE_TYPE_REGISTRY[DIVIDEND_RULE_TYPE.CASH_COVER_MIN].params, "min")
	},
	[DIVIDEND_RULE_TYPE.MIN_MARKET_CAP]: {
		key: DIVIDEND_RULE_TYPE.MIN_MARKET_CAP,
		label: "总市值不低于",
		description: "微盘高息常是「股价跌出来的息」：流动性差、分红一停就杀估值",
		defaultGroup: RULE_GROUP_FILTER,
		params: [{
			key: "min",
			label: "市值至少",
			kind: "number",
			fallback: 100,
			unit: "亿"
		}],
		evaluate: (row, params) => {
			if (row.marketCap === null) return null;
			const min = numParam(params, RULE_TYPE_REGISTRY[DIVIDEND_RULE_TYPE.MIN_MARKET_CAP].params, "min");
			return row.marketCap >= min * YI_TO_YUAN;
		}
	},
	[DIVIDEND_RULE_TYPE.MAX_DEBT_RATIO]: {
		key: DIVIDEND_RULE_TYPE.MAX_DEBT_RATIO,
		label: "资产负债率不高于",
		description: "最新已披露报告期（中报优先，回退去年年报）",
		defaultGroup: RULE_GROUP_FILTER,
		params: [{
			key: "max",
			label: "负债率不超过",
			kind: "number",
			fallback: 60,
			unit: "%"
		}],
		evaluate: (row, params) => row.debtRatio === null ? null : row.debtRatio <= numParam(params, RULE_TYPE_REGISTRY[DIVIDEND_RULE_TYPE.MAX_DEBT_RATIO].params, "max")
	},
	[DIVIDEND_RULE_TYPE.MIN_PROJECTED_YIELD]: {
		key: DIVIDEND_RULE_TYPE.MIN_PROJECTED_YIELD,
		label: "推算今年股息率高于",
		description: "本页自算口径：去年分红率 × 预计今年净利 ÷ 现市值",
		defaultGroup: RULE_GROUP_FILTER,
		params: [{
			key: "min",
			label: "推算股息率大于",
			kind: "number",
			fallback: 5,
			unit: "%"
		}],
		evaluate: (row, params) => row.projectedYield === null ? null : row.projectedYield > numParam(params, RULE_TYPE_REGISTRY[DIVIDEND_RULE_TYPE.MIN_PROJECTED_YIELD].params, "min")
	},
	[DIVIDEND_RULE_TYPE.MIN_YIELD_LAST]: {
		key: DIVIDEND_RULE_TYPE.MIN_YIELD_LAST,
		label: "去年股息率高于",
		description: "去年全年每股派息 ÷ 现价（静态口径）",
		defaultGroup: RULE_GROUP_FILTER,
		params: [{
			key: "min",
			label: "去年股息率大于",
			kind: "number",
			fallback: 3,
			unit: "%"
		}],
		evaluate: (row, params) => row.yieldLast === null ? null : row.yieldLast > numParam(params, RULE_TYPE_REGISTRY[DIVIDEND_RULE_TYPE.MIN_YIELD_LAST].params, "min")
	},
	[DIVIDEND_RULE_TYPE.MIN_DPS_LAST]: {
		key: DIVIDEND_RULE_TYPE.MIN_DPS_LAST,
		label: "去年每股分红高于",
		description: "按去年年度报告期的每股派息合计（含税，元）",
		defaultGroup: RULE_GROUP_FILTER,
		params: [{
			key: "min",
			label: "每股分红大于",
			kind: "number",
			fallback: .3,
			unit: "元"
		}],
		evaluate: (row, params) => row.dpsLast === null ? null : row.dpsLast > numParam(params, RULE_TYPE_REGISTRY[DIVIDEND_RULE_TYPE.MIN_DPS_LAST].params, "min")
	},
	[DIVIDEND_RULE_TYPE.MAX_PE]: {
		key: DIVIDEND_RULE_TYPE.MAX_PE,
		label: "PE(TTM) 不高于",
		description: "估值垫：PE 太高的股息率往往经不起盈利波动",
		defaultGroup: RULE_GROUP_FILTER,
		params: [{
			key: "max",
			label: "PE 不超过",
			kind: "number",
			fallback: 25,
			unit: ""
		}],
		evaluate: (row, params) => row.peTtm === null ? null : row.peTtm <= numParam(params, RULE_TYPE_REGISTRY[DIVIDEND_RULE_TYPE.MAX_PE].params, "max")
	},
	[DIVIDEND_RULE_TYPE.MAX_PB]: {
		key: DIVIDEND_RULE_TYPE.MAX_PB,
		label: "市净率不高于",
		description: "低 PB 是分红能力的资产端约束（资产虚高的高息会被过滤）",
		defaultGroup: RULE_GROUP_FILTER,
		params: [{
			key: "max",
			label: "PB 不超过",
			kind: "number",
			fallback: 3,
			unit: ""
		}],
		evaluate: (row, params) => row.pb === null ? null : row.pb <= numParam(params, RULE_TYPE_REGISTRY[DIVIDEND_RULE_TYPE.MAX_PB].params, "max")
	},
	[DIVIDEND_RULE_TYPE.MIN_NP_YOY]: {
		key: DIVIDEND_RULE_TYPE.MIN_NP_YOY,
		label: "中报净利同比增长至少",
		description: "正面版盈利门槛：同比低于阈值不放行（与「剔除中报净利下滑」互补，阈值可设更高）",
		defaultGroup: RULE_GROUP_FILTER,
		params: [{
			key: "min",
			label: "同比至少",
			kind: "number",
			fallback: 0,
			unit: "%"
		}],
		evaluate: (row, params) => row.netProfitYoY === null ? null : row.netProfitYoY >= numParam(params, RULE_TYPE_REGISTRY[DIVIDEND_RULE_TYPE.MIN_NP_YOY].params, "min")
	},
	[DIVIDEND_RULE_TYPE.MIN_REV_YOY]: {
		key: DIVIDEND_RULE_TYPE.MIN_REV_YOY,
		label: "中报营收同比增长至少",
		description: "收入端确认景气（利润可以挤出来，收入更难伪装）",
		defaultGroup: RULE_GROUP_FILTER,
		params: [{
			key: "min",
			label: "同比至少",
			kind: "number",
			fallback: 0,
			unit: "%"
		}],
		evaluate: (row, params) => row.revenueYoY === null ? null : row.revenueYoY >= numParam(params, RULE_TYPE_REGISTRY[DIVIDEND_RULE_TYPE.MIN_REV_YOY].params, "min")
	},
	[DIVIDEND_RULE_TYPE.HAS_INTERIM_DIVIDEND]: {
		key: DIVIDEND_RULE_TYPE.HAS_INTERIM_DIVIDEND,
		label: "今年中期已宣派分红",
		description: "已有实际动作的确定性证据：中报披露了分红方案（未披露视为不满足）",
		defaultGroup: RULE_GROUP_FILTER,
		params: [],
		evaluate: (row) => row.interimDps === null ? null : row.interimDps > 0
	},
	[DIVIDEND_RULE_TYPE.INDUSTRY_WHITELIST]: {
		key: DIVIDEND_RULE_TYPE.INDUSTRY_WHITELIST,
		label: "只看指定行业",
		description: "行业名含任一关键词才保留（逗号分隔；留空 = 不限）",
		defaultGroup: RULE_GROUP_FILTER,
		params: [{
			key: "keywords",
			label: "行业关键词（逗号分隔）",
			kind: "text",
			fallback: ""
		}],
		evaluate: (row, params) => {
			if (row.industry === "") return null;
			const keywords = textParam(params, RULE_TYPE_REGISTRY[DIVIDEND_RULE_TYPE.INDUSTRY_WHITELIST].params, "keywords").split(/[,，]/).map((item) => item.trim()).filter((item) => item !== "");
			if (keywords.length === 0) return false;
			return keywords.some((keyword) => row.industry.includes(keyword));
		}
	},
	[DIVIDEND_RULE_TYPE.INDUSTRY_BLACKLIST]: {
		key: DIVIDEND_RULE_TYPE.INDUSTRY_BLACKLIST,
		label: "剔除周期行业",
		description: "行业名含任一关键词即命中（周期顶点代理①：高息常是景气回落的价格陷阱）",
		defaultGroup: RULE_GROUP_EXCLUDE,
		params: [{
			key: "keywords",
			label: "关键词（逗号分隔）",
			kind: "text",
			fallback: RULE_CYCLICAL_KEYWORDS_DEFAULT
		}],
		evaluate: (row, params) => {
			if (row.industry === "") return null;
			const keywords = textParam(params, RULE_TYPE_REGISTRY[DIVIDEND_RULE_TYPE.INDUSTRY_BLACKLIST].params, "keywords").split(/[,，]/).map((item) => item.trim()).filter((item) => item !== "");
			if (keywords.length === 0) return false;
			return keywords.some((keyword) => row.industry.includes(keyword));
		}
	},
	[DIVIDEND_RULE_TYPE.MAX_INTERIM_DECLINE]: {
		key: DIVIDEND_RULE_TYPE.MAX_INTERIM_DECLINE,
		label: "剔除中报净利下滑",
		description: "中报净利同比低于阈值即命中（盈利塌陷代理②：今年的高分息明年未必守得住）",
		defaultGroup: RULE_GROUP_EXCLUDE,
		params: [{
			key: "max",
			label: "同比低于",
			kind: "number",
			fallback: 0,
			unit: "%"
		}],
		evaluate: (row, params) => row.netProfitYoY === null ? null : row.netProfitYoY < numParam(params, RULE_TYPE_REGISTRY[DIVIDEND_RULE_TYPE.MAX_INTERIM_DECLINE].params, "max")
	},
	[DIVIDEND_RULE_TYPE.MAX_PAYOUT_OVERDUE]: {
		key: DIVIDEND_RULE_TYPE.MAX_PAYOUT_OVERDUE,
		label: "剔除超额分红",
		description: "去年分红率超阈值即命中（特别分红 / 透支型分红率不可线性外推）",
		defaultGroup: RULE_GROUP_EXCLUDE,
		params: [{
			key: "max",
			label: "分红率超过",
			kind: "number",
			fallback: 100,
			unit: "%"
		}],
		evaluate: (row, params) => {
			if (row.payoutLast === null) return null;
			const fields = RULE_TYPE_REGISTRY[DIVIDEND_RULE_TYPE.MAX_PAYOUT_OVERDUE].params;
			return row.payoutLast * 100 > numParam(params, fields, "max");
		}
	},
	[DIVIDEND_RULE_TYPE.NEGATIVE_OCF]: {
		key: DIVIDEND_RULE_TYPE.NEGATIVE_OCF,
		label: "剔除经营现金流为负",
		description: "分红靠融资或变卖资产而非经营造血（数据缺失不剔除）",
		defaultGroup: RULE_GROUP_EXCLUDE,
		params: [],
		evaluate: (row) => row.ocfPerShareLast === null ? null : row.ocfPerShareLast < 0
	}
};
/** 预置规则的实例 id 前缀（与用户自建规则区分开） */
var PRESET_RULE_ID_PREFIX = "preset-";
/**
* 生成一条规则实例（参数取类型默认值）
* @param type 规则类型键
* @param group 分组覆盖（缺省用类型默认分组）
* @returns 规则实例
*/
var createRuleInstance = (type, group) => {
	const def = RULE_TYPE_REGISTRY[type];
	const params = {};
	for (const field of def.params) params[field.key] = field.fallback;
	return {
		id: `rule-${Date.now().toString(36)}-${Math.floor(Math.random() * 1e4).toString(36)}`,
		type,
		group: group ?? def.defaultGroup,
		enabled: true,
		params
	};
};
/**
* 默认预置规则（用户口径：「伪高股息剔除 + 真高股息筛选」清单）
* @returns 预置规则实例数组（顺序即面板展示序）
*/
var createDefaultRules = () => [
	{
		id: `${PRESET_RULE_ID_PREFIX}ttm-yield`,
		type: DIVIDEND_RULE_TYPE.MIN_TTM_YIELD,
		group: RULE_GROUP_FILTER,
		enabled: true,
		params: { min: 4 }
	},
	{
		id: `${PRESET_RULE_ID_PREFIX}div-years`,
		type: DIVIDEND_RULE_TYPE.MIN_DIVIDEND_YEARS,
		group: RULE_GROUP_FILTER,
		enabled: true,
		params: { min: 5 }
	},
	{
		id: `${PRESET_RULE_ID_PREFIX}payout-range`,
		type: DIVIDEND_RULE_TYPE.PAYOUT_RATIO_RANGE,
		group: RULE_GROUP_FILTER,
		enabled: true,
		params: {
			min: 30,
			max: 70
		}
	},
	{
		id: `${PRESET_RULE_ID_PREFIX}cash-cover`,
		type: DIVIDEND_RULE_TYPE.CASH_COVER_MIN,
		group: RULE_GROUP_FILTER,
		enabled: true,
		params: { min: 1 }
	},
	{
		id: `${PRESET_RULE_ID_PREFIX}market-cap`,
		type: DIVIDEND_RULE_TYPE.MIN_MARKET_CAP,
		group: RULE_GROUP_FILTER,
		enabled: true,
		params: { min: 100 }
	},
	{
		id: `${PRESET_RULE_ID_PREFIX}debt-ratio`,
		type: DIVIDEND_RULE_TYPE.MAX_DEBT_RATIO,
		group: RULE_GROUP_FILTER,
		enabled: true,
		params: { max: 60 }
	},
	{
		id: `${PRESET_RULE_ID_PREFIX}cyclical-industry`,
		type: DIVIDEND_RULE_TYPE.INDUSTRY_BLACKLIST,
		group: RULE_GROUP_EXCLUDE,
		enabled: true,
		params: { keywords: RULE_CYCLICAL_KEYWORDS_DEFAULT }
	},
	{
		id: `${PRESET_RULE_ID_PREFIX}interim-decline`,
		type: DIVIDEND_RULE_TYPE.MAX_INTERIM_DECLINE,
		group: RULE_GROUP_EXCLUDE,
		enabled: true,
		params: { max: 0 }
	},
	{
		id: `${PRESET_RULE_ID_PREFIX}payout-overdue`,
		type: DIVIDEND_RULE_TYPE.MAX_PAYOUT_OVERDUE,
		group: RULE_GROUP_EXCLUDE,
		enabled: true,
		params: { max: 100 }
	},
	{
		id: `${PRESET_RULE_ID_PREFIX}negative-ocf`,
		type: DIVIDEND_RULE_TYPE.NEGATIVE_OCF,
		group: RULE_GROUP_EXCLUDE,
		enabled: true,
		params: {}
	}
];
/**
* 清洗从库里读回的规则配置（未知类型 / 非对象行丢弃，参数缺键补默认、类型错回退）
* @param raw 库里读回的任意值（应为 `RuleConfig[]` 的 JSON 反序列化结果）
* @returns 清洗后的规则配置（输入非法返回 null，由调用方决定是否回退预置）
*/
var sanitizeRuleConfigs = (raw) => {
	if (!Array.isArray(raw)) return null;
	const configs = [];
	for (const item of raw) {
		if (!item || typeof item !== "object") continue;
		const candidate = item;
		const def = RULE_TYPE_REGISTRY[candidate.type];
		if (!def) continue;
		const group = candidate.group === "filter" || candidate.group === "exclude" ? candidate.group : def.defaultGroup;
		const params = {};
		for (const field of def.params) {
			const value = (candidate.params ?? {})[field.key];
			if (field.kind === "number") params[field.key] = typeof value === "number" && Number.isFinite(value) ? value : field.fallback;
			else params[field.key] = typeof value === "string" ? value : field.fallback;
		}
		configs.push({
			id: typeof candidate.id === "string" && candidate.id !== "" ? candidate.id : createRuleInstance(def.key).id,
			type: def.key,
			group,
			enabled: candidate.enabled !== false,
			params
		});
	}
	return configs;
};
/**
* 渲染一条规则的展示文案（含参数值与单位）
* @param config 规则实例
* @returns 展示文案（如 `TTM 股息率 > 4%`）
*/
var formatRuleText = (config) => {
	const def = RULE_TYPE_REGISTRY[config.type];
	if (!def) return config.type;
	const unitOf = (key) => def.params.find((field) => field.key === key)?.unit ?? "";
	const numOf = (key) => {
		const field = def.params.find((item) => item.key === key);
		return `${typeof config.params[key] === "number" ? config.params[key] : field?.fallback}${unitOf(key)}`;
	};
	const textOf = (key) => {
		const field = def.params.find((item) => item.key === key);
		return typeof config.params[key] === "string" ? config.params[key] : field?.fallback;
	};
	switch (def.key) {
		case DIVIDEND_RULE_TYPE.MIN_TTM_YIELD: return `TTM 股息率 > ${numOf("min")}`;
		case DIVIDEND_RULE_TYPE.MIN_DIVIDEND_YEARS: return `连续分红 ≥ ${numOf("min")}`;
		case DIVIDEND_RULE_TYPE.PAYOUT_RATIO_RANGE: return `分红率 ${numOf("min")} ~ ${numOf("max")}`;
		case DIVIDEND_RULE_TYPE.CASH_COVER_MIN: return `现金流覆盖分红 ≥ ${numOf("min")}`;
		case DIVIDEND_RULE_TYPE.MIN_MARKET_CAP: return `总市值 ≥ ${numOf("min")}`;
		case DIVIDEND_RULE_TYPE.MIN_PROJECTED_YIELD: return `推算股息率 > ${numOf("min")}`;
		case DIVIDEND_RULE_TYPE.MIN_YIELD_LAST: return `去年股息率 > ${numOf("min")}`;
		case DIVIDEND_RULE_TYPE.MIN_DPS_LAST: return `每股分红 > ${numOf("min")}`;
		case DIVIDEND_RULE_TYPE.MAX_PE: return `PE(TTM) ≤ ${numOf("max")}`;
		case DIVIDEND_RULE_TYPE.MAX_PB: return `PB ≤ ${numOf("max")}`;
		case DIVIDEND_RULE_TYPE.MIN_NP_YOY: return `净利同比 ≥ ${numOf("min")}`;
		case DIVIDEND_RULE_TYPE.MIN_REV_YOY: return `营收同比 ≥ ${numOf("min")}`;
		case DIVIDEND_RULE_TYPE.HAS_INTERIM_DIVIDEND: return "中期已宣派分红";
		case DIVIDEND_RULE_TYPE.INDUSTRY_WHITELIST: {
			const keywords = textOf("keywords").trim();
			return keywords === "" ? "只看指定行业（未设关键词 = 全部通过）" : `行业含 [${keywords}]`;
		}
		case DIVIDEND_RULE_TYPE.MAX_DEBT_RATIO: return `负债率 ≤ ${numOf("max")}`;
		case DIVIDEND_RULE_TYPE.INDUSTRY_BLACKLIST: return `行业含 [${textOf("keywords")}]`;
		case DIVIDEND_RULE_TYPE.MAX_INTERIM_DECLINE: return `中报净利同比 < ${numOf("max")}`;
		case DIVIDEND_RULE_TYPE.MAX_PAYOUT_OVERDUE: return `分红率 > ${numOf("max")}（超额）`;
		case DIVIDEND_RULE_TYPE.NEGATIVE_OCF: return "经营现金流 < 0";
		default: return def.label;
	}
};
/**
* 对一行数据评估全部启用规则（纯函数）
*
* 语义：无启用规则 = 通过；排除组任一命中 → 不通过（带原因）；
* 筛选组任一未满足（含数据缺失）→ 不通过（带原因）。
* @param row 落库展示行
* @param configs 规则配置（只评估 `enabled` 的）
* @returns 匹配结果
*/
var evaluateRules = (row, configs) => {
	const excludeReasons = [];
	const failedFilters = [];
	for (const config of configs) {
		if (!config.enabled) continue;
		const def = RULE_TYPE_REGISTRY[config.type];
		if (!def) continue;
		const verdict = def.evaluate(row, config.params);
		const text = formatRuleText(config);
		if (config.group === "exclude") {
			if (verdict === true) excludeReasons.push(text);
		} else if (verdict !== true) failedFilters.push(verdict === null ? `${text}（数据缺失）` : text);
	}
	return {
		pass: excludeReasons.length === 0 && failedFilters.length === 0,
		excludeReasons,
		failedFilters
	};
};
//#endregion
//#region plugins/dsh-dividend-screen/DividendScreenView.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1 = { class: "space-y-4" };
var _hoisted_2 = { class: "flex shrink-0 items-center gap-1" };
var _hoisted_3 = { class: "flex flex-wrap items-start justify-between gap-3" };
var _hoisted_4 = { class: "min-w-0 flex-1" };
var _hoisted_5 = { class: "flex items-center gap-1.5 text-base font-semibold text-text" };
var _hoisted_6 = { class: "mt-1 text-xs leading-relaxed text-text-secondary" };
var _hoisted_7 = {
	key: 0,
	class: "flex shrink-0 items-center gap-2"
};
var _hoisted_8 = { class: "flex items-center gap-1.5 text-xs text-text-secondary" };
var _hoisted_9 = ["disabled"];
var _hoisted_10 = ["value"];
var _hoisted_11 = {
	key: 0,
	class: "text-xs tabular-nums text-text-tertiary"
};
var _hoisted_12 = {
	key: 0,
	class: "mt-3 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-text-tertiary"
};
var _hoisted_13 = { key: 0 };
var _hoisted_14 = {
	key: 1,
	class: "mt-2 rounded-lg bg-primary-weak px-2 py-1.5 text-xs leading-relaxed text-primary"
};
var _hoisted_15 = {
	key: 2,
	class: "mt-3 flex flex-wrap items-center gap-1.5"
};
var _hoisted_16 = ["aria-pressed"];
var _hoisted_17 = ["aria-pressed"];
var _hoisted_18 = ["aria-pressed"];
var _hoisted_19 = ["aria-pressed"];
var _hoisted_20 = {
	key: 0,
	class: "tabular-nums"
};
var _hoisted_21 = {
	key: 0,
	class: "ml-1 text-[11px] tabular-nums text-text-tertiary"
};
var _hoisted_22 = { class: "text-xs tabular-nums text-text-tertiary" };
var _hoisted_23 = { class: "grid gap-4 md:grid-cols-2" };
var _hoisted_24 = { class: "mb-2 flex items-center gap-1.5 text-xs font-medium text-text-secondary" };
var _hoisted_25 = { class: "tabular-nums text-text-tertiary" };
var _hoisted_26 = { class: "space-y-1.5" };
var _hoisted_27 = ["title"];
var _hoisted_28 = {
	key: 0,
	class: "flex items-center gap-1 text-[11px] text-text-tertiary"
};
var _hoisted_29 = ["step", "onUpdate:modelValue"];
var _hoisted_30 = {
	key: 1,
	class: "flex items-center gap-1 text-[11px] text-text-tertiary"
};
var _hoisted_31 = ["onUpdate:modelValue"];
var _hoisted_32 = ["aria-label", "onClick"];
var _hoisted_33 = {
	key: 0,
	class: "px-2.5 py-1 text-[11px] text-text-tertiary"
};
var _hoisted_34 = { class: "mt-3 flex flex-wrap items-center gap-2" };
var _hoisted_35 = ["aria-label"];
var _hoisted_36 = { value: "" };
var _hoisted_37 = ["value"];
var _hoisted_38 = {
	key: 0,
	class: "mt-2 rounded-lg bg-down-weak px-2 py-1.5 text-xs leading-relaxed text-down"
};
var _hoisted_39 = {
	key: 0,
	class: "text-xs tabular-nums text-text-tertiary"
};
var _hoisted_40 = {
	key: 1,
	class: "text-[11px] tabular-nums text-text-tertiary"
};
var _hoisted_41 = {
	key: 0,
	class: "relative mb-3"
};
var _hoisted_42 = ["placeholder", "aria-label"];
var _hoisted_43 = {
	key: 0,
	class: "ml-2 text-xs text-text-tertiary"
};
var _hoisted_44 = {
	key: 1,
	class: "absolute z-20 mt-1 max-h-64 w-full max-w-md overflow-y-auto rounded-lg border border-flat-weak bg-surface shadow-lg"
};
var _hoisted_45 = ["onMousedown"];
var _hoisted_46 = { class: "truncate text-text" };
var _hoisted_47 = { class: "shrink-0 tabular-nums text-[11px] text-text-tertiary" };
var _hoisted_48 = {
	key: 2,
	class: "mt-1 text-xs text-text-tertiary"
};
var _hoisted_49 = {
	key: 3,
	class: "mt-1 rounded-lg bg-down-weak px-2 py-1 text-xs text-down"
};
var _hoisted_50 = {
	key: 4,
	class: "mt-2 rounded-lg border border-flat-weak bg-flat-weak/40 p-3"
};
var _hoisted_51 = { class: "flex flex-wrap items-center gap-2" };
var _hoisted_52 = { class: "text-sm font-medium text-text" };
var _hoisted_53 = { class: "tabular-nums text-[11px] text-text-tertiary" };
var _hoisted_54 = {
	key: 0,
	class: "mt-1.5 text-xs leading-relaxed text-text-tertiary"
};
var _hoisted_55 = {
	key: 1,
	class: "mt-1.5 rounded-lg bg-down-weak px-2 py-1 text-xs leading-relaxed text-down"
};
var _hoisted_56 = { class: "mt-2 grid grid-cols-2 gap-x-6 gap-y-1.5 text-xs sm:grid-cols-4" };
var _hoisted_57 = { class: "text-text-tertiary" };
var _hoisted_58 = { class: "tabular-nums text-text" };
var _hoisted_59 = { class: "text-text-tertiary" };
var _hoisted_60 = { class: "tabular-nums text-text" };
var _hoisted_61 = { class: "text-text-tertiary" };
var _hoisted_62 = { class: "tabular-nums font-medium text-up" };
var _hoisted_63 = { class: "text-text-tertiary" };
var _hoisted_64 = { class: "tabular-nums text-text" };
var _hoisted_65 = { class: "text-text-tertiary" };
var _hoisted_66 = { class: "tabular-nums text-text" };
var _hoisted_67 = { class: "text-text-tertiary" };
var _hoisted_68 = { class: "tabular-nums text-text" };
var _hoisted_69 = { class: "text-text-tertiary" };
var _hoisted_70 = { class: "tabular-nums text-text" };
var _hoisted_71 = { class: "text-text-tertiary" };
var _hoisted_72 = { class: "tabular-nums text-text" };
var _hoisted_73 = {
	key: 0,
	class: "mt-1.5 text-[11px] leading-relaxed text-text-tertiary"
};
var _hoisted_74 = { class: "mt-2 flex items-center gap-2" };
var _hoisted_75 = { key: 1 };
var _hoisted_76 = {
	key: 0,
	class: "pb-4 text-center"
};
var _hoisted_77 = {
	key: 1,
	class: "pb-4 text-center"
};
var _hoisted_78 = { class: "flex items-center gap-1.5" };
var _hoisted_79 = { class: "text-text" };
var _hoisted_80 = { class: "tabular-nums text-[11px] text-text-tertiary" };
var _hoisted_81 = {
	key: 1,
	class: "rounded bg-primary-weak px-1 py-0.5 text-[10px] text-primary"
};
var _hoisted_82 = { class: "text-text-secondary" };
var _hoisted_83 = { class: "tabular-nums text-text" };
var _hoisted_84 = { key: 1 };
var _hoisted_85 = {
	key: 0,
	class: "font-medium tabular-nums text-up"
};
var _hoisted_86 = {
	key: 1,
	class: "text-text-tertiary"
};
var _hoisted_87 = {
	key: 1,
	class: "text-text-tertiary"
};
var _hoisted_88 = ["title"];
var _hoisted_89 = [
	"title",
	"aria-label",
	"onClick"
];
var _hoisted_90 = { class: "space-y-3" };
var _hoisted_91 = { class: "text-xs leading-relaxed text-text-secondary" };
var _hoisted_92 = {
	key: 0,
	class: "rounded-lg bg-flat-weak px-2 py-1.5"
};
var _hoisted_93 = { class: "text-xs font-medium text-text-secondary" };
var _hoisted_94 = { class: "grid grid-cols-2 gap-x-6 gap-y-1.5 text-xs sm:grid-cols-3 md:grid-cols-4" };
var _hoisted_95 = { class: "text-text-tertiary" };
var _hoisted_96 = { class: "text-text-tertiary" };
var _hoisted_97 = { class: "tabular-nums text-text" };
var _hoisted_98 = { class: "text-text-tertiary" };
var _hoisted_99 = { class: "tabular-nums text-text" };
var _hoisted_100 = { class: "text-text-tertiary" };
var _hoisted_101 = { class: "tabular-nums text-text" };
var _hoisted_102 = { class: "text-text-tertiary" };
var _hoisted_103 = { class: "tabular-nums text-text" };
var _hoisted_104 = { class: "text-text-tertiary" };
var _hoisted_105 = { class: "tabular-nums text-text" };
var _hoisted_106 = { class: "text-text-tertiary" };
var _hoisted_107 = { class: "tabular-nums text-text" };
var _hoisted_108 = { class: "text-text-tertiary" };
var _hoisted_109 = { class: "tabular-nums text-text" };
var _hoisted_110 = { class: "text-text-tertiary" };
var _hoisted_111 = { class: "tabular-nums text-text" };
var _hoisted_112 = { class: "text-text-tertiary" };
var _hoisted_113 = { class: "tabular-nums text-text" };
var _hoisted_114 = { class: "text-text-tertiary" };
var _hoisted_115 = { class: "tabular-nums text-text" };
var _hoisted_116 = { class: "text-text-tertiary" };
var _hoisted_117 = { class: "tabular-nums text-text" };
var _hoisted_118 = { class: "text-text-tertiary" };
var _hoisted_119 = { class: "tabular-nums text-text" };
var _hoisted_120 = { class: "text-text-tertiary" };
var _hoisted_121 = { class: "tabular-nums text-text" };
var _hoisted_122 = { class: "text-text-tertiary" };
var _hoisted_123 = { class: "tabular-nums font-medium text-up" };
var _hoisted_124 = { class: "text-text-tertiary" };
var _hoisted_125 = { class: "tabular-nums text-text" };
var _hoisted_126 = { class: "text-text-tertiary" };
var _hoisted_127 = { class: "tabular-nums text-text" };
var _hoisted_128 = { class: "text-text-tertiary" };
var _hoisted_129 = { class: "tabular-nums text-text" };
var _hoisted_130 = { class: "text-text-tertiary" };
var _hoisted_131 = { class: "tabular-nums text-text" };
var _hoisted_132 = { class: "text-text-tertiary" };
var _hoisted_133 = { class: "tabular-nums text-text" };
var _hoisted_134 = { class: "text-xs leading-relaxed text-text-tertiary" };
/**
* 股息筛选看板（插件 dsh-dividend-screen 的页面）
*
* 页面只读插件库快照渲染（零联网）；点「扫描排行」才发起上游请求
* （排行 + 三期业绩 + 多期分红 + 负债率，样本池 200 时约 12 次串行请求）。
* 筛选与规则评估都是纯客户端的（快照行数 ≤ 样本池上限），改规则不触发网络请求，
* 规则配置持久化在插件库 config 表。
*/
var NUMERIC_COLUMN_MIN_WIDTH = 80;
/** 展开箭头列（BaseTable 内置 w-8）的最小宽度（px） */
var EXPAND_COLUMN_MIN_WIDTH = 32;
//#endregion
//#region plugins/dsh-dividend-screen/DividendScreenView.vue
var DividendScreenView_default = /* @__PURE__ */ defineComponent({
	__name: "DividendScreenView",
	props: {
		repo: {},
		stockSearch: {},
		settings: {},
		deps: {}
	},
	setup(__props) {
		const props = __props;
		/** 宿主格式化服务的短名字（模板里写 `format.percent(...)` 比 `deps.format.percent(...)` 好读） */
		const format = props.deps.format;
		/** 是否正在扫描 */
		const scanning = ref(false);
		/** 扫描进度（null = 未进行中） */
		const progress = ref(null);
		/** 扫描告警文案（空串 = 无告警） */
		const scanNotice = ref("");
		/** 规则保存失败提示（空串 = 无提示） */
		const ruleNotice = ref("");
		/** 样本池档位（仅决定下一次扫描的范围） */
		const universeLimit = ref(200);
		/** 快捷筛选：仅已披露中报 */
		const publishedOnly = ref(false);
		/** 快捷筛选：仅净利同比增长 */
		const growingOnly = ref(false);
		/** 快捷筛选：仅可推算行 */
		const projectableOnly = ref(false);
		/** 未通过规则的行默认隐藏（剔除/未过不占列表），开启后连同原因一起显示 */
		const showFailing = ref(false);
		/** 当前展开的行（受控展开行） */
		const expandedKeys = ref([]);
		/** 添加规则下拉的选中类型（空串 = 未选） */
		const selectedRuleType = ref("");
		/** 页面顶部 tab：筛选 / 自选 */
		const activeTab = ref(DIVIDEND_TAB_SCREEN);
		/** 自选保存失败提示（空串 = 无提示） */
		const watchNotice = ref("");
		/** 快照（响应式：扫描落库后自动刷新） */
		const snapshot = computed(() => props.repo.snapshot());
		/** 全部行（扫描时的默认序） */
		const allRows = computed(() => snapshot.value.rows);
		/** 扫描元信息 */
		const meta = computed(() => snapshot.value.meta);
		/** 当前规则配置（响应式：保存后自动更新） */
		const ruleConfigs = computed(() => props.repo.ruleConfig());
		/** 启用中的规则 */
		const enabledRules = computed(() => ruleConfigs.value.filter((config) => config.enabled));
		/** 规则按组分桶（面板两列各渲染一组，保持配置顺序） */
		const ruleGroups = computed(() => {
			const buckets = {
				filter: [],
				exclude: []
			};
			for (const config of ruleConfigs.value) buckets[config.group].push(config);
			return buckets;
		});
		/** 是否有启用中的规则 */
		const hasEnabledRules = computed(() => enabledRules.value.length > 0);
		/**
		* 逐行评估规则（缓存：行与规则引用不变就不重算）
		* @returns 代码 → 匹配结果
		*/
		const ruleMatches = computed(() => {
			const map = /* @__PURE__ */ new Map();
			for (const row of allRows.value) map.set(row.code, evaluateRules(row, ruleConfigs.value));
			return map;
		});
		/** 通过规则的行数 */
		const rulePassCount = computed(() => allRows.value.filter((row) => ruleMatches.value.get(row.code)?.pass).length);
		/** 被规则挡下的行数（剔除 + 未过） */
		const ruleFailCount = computed(() => allRows.value.length - rulePassCount.value);
		/** 自选条目（响应式；加入 / 移出后自动更新） */
		const watchedItems = computed(() => props.repo.watchlist());
		/** 自选代码集合（行内星标态判定用） */
		const watchSet = computed(() => new Set(watchedItems.value.map((item) => item.code)));
		/** 快照行按代码索引（自选 join 快照用） */
		const rowsByCode = computed(() => new Map(allRows.value.map((row) => [row.code, row])));
		/**
		* 快照外自选的占位展示行（纯函数；指标全部未知，扫描覆盖该股后自动补全）
		* @param item 自选条目
		* @returns 占位展示行
		*/
		const createPlaceholderRow = (item) => ({
			code: item.code,
			name: item.name,
			industry: "",
			price: null,
			changePercent: null,
			marketCap: null,
			pb: null,
			peTtm: null,
			totalShares: null,
			ttmYield: null,
			dpsLast: 0,
			dividendTotalLast: null,
			netProfitFyLast: null,
			payoutLast: null,
			netProfitH1: null,
			netProfitH1Last: null,
			netProfitYoY: null,
			revenueYoY: null,
			growthH1: null,
			projectedNetProfit: null,
			projectedDps: null,
			projectedYield: null,
			yieldLast: null,
			interimDps: null,
			dividendYears: null,
			ocfPerShareLast: null,
			cashCoverLast: null,
			debtRatio: null,
			status: DIVIDEND_PROJECT_STATUS.NO_REPORT
		});
		/**
		* 会话内按需拉取的展示行缓存（代码 → 行）
		*
		* 快照外自选（样本池没覆盖的个股）进自选 tab 时自动补拉：约 6 次串行请求/股，
		* 拉到后整个会话复用，切 tab / 重渲染不再请求；不落库（持久化快照仍以扫描为准）。
		*/
		const onDemandRows = ref(/* @__PURE__ */ new Map());
		/** 上游明确无行情的代码（退市 / 非沪深，本次会话不再重试） */
		const onDemandGone = ref(/* @__PURE__ */ new Set());
		/** 正在拉取中的代码（防重复排队；非响应式，进度走 watchFetchProgress） */
		const fetchingCodes = /* @__PURE__ */ new Set();
		/** 快照外自选的补拉进度（null = 空闲） */
		const watchFetchProgress = ref(null);
		/**
		* 自选展示行：快照命中 → 会话内按需拉取命中 → 占位行（指标 `--`）
		* （自选是用户主动清单，全部条目都进列表；快照外个股拉到数据后原地补全）
		*/
		const watchRows = computed(() => watchedItems.value.map((item) => rowsByCode.value.get(item.code) ?? onDemandRows.value.get(item.code) ?? createPlaceholderRow(item)));
		/** 仍无指标数据的自选代码（占位行不显示「中报未披露」状态徽标，避免误导） */
		const watchMissingCodes = computed(() => new Set(watchedItems.value.filter((item) => !rowsByCode.value.has(item.code) && !onDemandRows.value.has(item.code)).map((item) => item.code)));
		/**
		* 串行补拉快照外自选的完整指标（进入自选 tab 触发；个股间留间隔守频率红线）
		*
		* 单股 ≈ 6 次请求（与扫描同源同口径）；拉取失败的代码本轮跳过并在提示区说明，
		* 不进入黑名单（限速类失败下次进入 tab 会自然重试，无轮询不会风暴）。
		*/
		const fetchMissingWatchRows = async () => {
			const pending = [...watchMissingCodes.value].filter((code) => !fetchingCodes.has(code));
			if (pending.length === 0) return;
			let done = 0;
			watchFetchProgress.value = {
				done,
				total: pending.length
			};
			for (const code of pending) {
				fetchingCodes.add(code);
				try {
					const row = await fetchScreenRowByCode(props.deps, code);
					if (row) {
						const next = new Map(onDemandRows.value);
						next.set(code, row);
						onDemandRows.value = next;
					} else onDemandGone.value = new Set(onDemandGone.value).add(code);
				} catch (error) {
					watchNotice.value = `快照外自选指标拉取失败：${error instanceof Error ? error.message : String(error)}`;
				} finally {
					fetchingCodes.delete(code);
					done += 1;
					watchFetchProgress.value = done < pending.length ? {
						done,
						total: pending.length
					} : null;
					if (done < pending.length) await props.deps.format.delay(600);
				}
			}
		};
		watch([activeTab, watchMissingCodes], ([tab]) => {
			if (tab !== "watchlist") return;
			fetchMissingWatchRows();
		});
		/**
		* 切换某行的自选态（星标列；加入 / 移出都即时持久化）
		* @param row 展示行
		*/
		const onToggleWatch = (row) => {
			watchNotice.value = "";
			(watchSet.value.has(row.code) ? props.repo.removeWatch([row.code]) : props.repo.addWatch([{
				code: row.code,
				name: row.name
			}])).catch((error) => {
				watchNotice.value = `${WATCH_SAVE_FAILED}：${error instanceof Error ? error.message : String(error)}`;
			});
		};
		/** 把当前筛选列表（筛选 tab 的可见行）全部加入自选 */
		const onAddAllToWatch = () => {
			watchNotice.value = "";
			props.repo.addWatch(rows.value.map((row) => ({
				code: row.code,
				name: row.name
			}))).catch((error) => {
				watchNotice.value = `${WATCH_SAVE_FAILED}：${error instanceof Error ? error.message : String(error)}`;
			});
		};
		/** 当前筛选列表里尚未加入自选的行数（整表加入按钮的可用性判定） */
		const bulkAddableCount = computed(() => rows.value.filter((row) => !watchSet.value.has(row.code)).length);
		/** 搜索关键词（双向绑定） */
		const searchKeyword = ref("");
		/** 搜索结果（已过滤为 A 股个股） */
		const searchResults = ref([]);
		/** 搜索请求中 */
		const searching = ref(false);
		/** 搜索失败提示（空串 = 无提示） */
		const searchNotice = ref("");
		/** 结果下拉是否展开 */
		const searchOpen = ref(false);
		/** 当前预览的标的（点搜索结果后设置） */
		const previewResult = ref(null);
		/** 搜索框是否可用（宿主服务未提供时整块隐藏） */
		const searchAvailable = computed(() => props.stockSearch !== void 0 && props.stockSearch !== null);
		/**
		* 是否为 A 股个股（指数 / 基金 / 港美股不在股息自选语境里）
		* @param result 搜索结果
		* @returns 是否 A 股个股
		*/
		const isAShareStock = (result) => result.category === "stock" && (result.market === "sh" || result.market === "sz");
		/** 执行一次搜索（结果过滤为 A 股个股） */
		const doSearch = async () => {
			const trimmed = searchKeyword.value.trim();
			previewResult.value = null;
			if (trimmed.length < 2 || !props.stockSearch) {
				searchResults.value = [];
				searchOpen.value = false;
				return;
			}
			searching.value = true;
			searchNotice.value = "";
			try {
				const results = await props.stockSearch.search(trimmed);
				searchResults.value = results.filter(isAShareStock);
				searchOpen.value = true;
			} catch (error) {
				searchResults.value = [];
				searchNotice.value = `${WATCH_SEARCH_FAILED}：${error instanceof Error ? error.message : String(error)}`;
			} finally {
				searching.value = false;
			}
		};
		/** 输入防抖 300ms（与宿主 use-stock-search 同一节奏，避免轰炸上游） */
		const debouncedSearch = props.deps.format.debounce(doSearch, 300);
		/** 关键词变化：清掉已选预览，防抖触发搜索 */
		watch(searchKeyword, () => {
			previewResult.value = null;
			debouncedSearch();
		});
		/**
		* 选中一个搜索结果 → 进入预览并收起下拉
		*
		* 快照命中的行直接渲染（零联网）；样本池外的个股按需拉取一次
		* （行情 + 三期业绩 + 分红史 + 负债 ≈ 6 次串行请求，点击触发，不落库）。
		* @param result 搜索结果
		*/
		const onSelectResult = (result) => {
			previewResult.value = result;
			searchOpen.value = false;
			const code = result.code.slice(2);
			if (rowsByCode.value.has(code)) {
				previewFetchedRow.value = null;
				previewFetchError.value = "";
				previewFetching.value = false;
				return;
			}
			startPreviewFetch(code);
		};
		/** 关闭预览 */
		const onClosePreview = () => {
			previewResult.value = null;
		};
		/** 预览标的的裸代码（完整符号 sh600519 → 600519） */
		const previewCode = computed(() => previewResult.value ? previewResult.value.code.slice(2) : "");
		/** 预览标的在最新快照中的行（命中才有现成指标，无需联网） */
		const previewRow = computed(() => previewCode.value === "" ? void 0 : rowsByCode.value.get(previewCode.value));
		/** 按需拉取到的展示行（样本池外个股；仅当前选中标的有效的结果） */
		const previewFetchedRow = ref(null);
		/** 按需拉取中 */
		const previewFetching = ref(false);
		/** 按需拉取失败提示（空串 = 无提示） */
		const previewFetchError = ref("");
		/** 拉取序号（用户快速连点不同结果时丢弃过期响应） */
		let previewFetchSeq = 0;
		/**
		* 按需拉取单股的完整展示行（点击触发，约 6 次串行请求；过期响应按序号丢弃）
		* @param code 6 位裸代码
		*/
		const startPreviewFetch = (code) => {
			const seq = ++previewFetchSeq;
			previewFetchedRow.value = null;
			previewFetchError.value = "";
			previewFetching.value = true;
			fetchScreenRowByCode(props.deps, code).then((row) => {
				if (seq !== previewFetchSeq) return;
				if (row) previewFetchedRow.value = row;
				else previewFetchError.value = "上游未返回该股行情（可能已退市或非沪深标的）";
			}).catch((error) => {
				if (seq !== previewFetchSeq) return;
				previewFetchError.value = `${WATCH_PREVIEW_FETCH_FAILED}：${error instanceof Error ? error.message : String(error)}`;
			}).finally(() => {
				if (seq === previewFetchSeq) previewFetching.value = false;
			});
		};
		/** 预览实际渲染的行：快照命中优先，否则用按需拉取结果 */
		const effectivePreviewRow = computed(() => previewRow.value ?? previewFetchedRow.value ?? void 0);
		/** 当前预览是否走的按需拉取（决定口径说明文案） */
		const previewIsOnDemand = computed(() => previewRow.value === void 0 && previewFetchedRow.value !== null);
		/** 预览标的是否已自选 */
		const previewWatched = computed(() => previewCode.value !== "" && watchSet.value.has(previewCode.value));
		/**
		* 搜索结果里标的的展示名
		* @param result 搜索结果
		* @returns 展示名（无名称时回退完整代码）
		*/
		const resultLabel = (result) => result.name || result.code;
		/**
		* 预览 / 搜索结果加入自选（失败给搜索区提示）
		* @param result 搜索结果
		* @returns 无
		*/
		const onAddResultToWatch = (result) => {
			watchNotice.value = "";
			props.repo.addWatch([{
				code: result.code.slice(2),
				name: result.name
			}]).catch((error) => {
				watchNotice.value = `${WATCH_SAVE_FAILED}：${error instanceof Error ? error.message : String(error)}`;
			});
		};
		/**
		* 预览标的切换自选态
		*/
		const onTogglePreviewWatch = () => {
			if (!previewResult.value) return;
			watchNotice.value = "";
			if (previewWatched.value) {
				props.repo.removeWatch([previewCode.value]).catch((error) => {
					watchNotice.value = `${WATCH_SAVE_FAILED}：${error instanceof Error ? error.message : String(error)}`;
				});
				return;
			}
			onAddResultToWatch(previewResult.value);
		};
		/**
		* 打开预览标的的个股详情侧栏（完整符号直接取自搜索结果，不经本地补前缀）
		*/
		const onOpenPreviewDetail = () => {
			if (previewResult.value) props.deps.stockOpen.openSidebar(previewResult.value.code, []);
		};
		/** 是否有任一筛选生效 */
		const filterActive = computed(() => publishedOnly.value || growingOnly.value || projectableOnly.value || showFailing.value);
		/** 筛选后的行 */
		const rows = computed(() => allRows.value.filter((row) => {
			if (publishedOnly.value && row.netProfitH1 === null) return false;
			if (growingOnly.value && !(row.growthH1 !== null && row.growthH1 > 1)) return false;
			if (projectableOnly.value && row.status !== DIVIDEND_PROJECT_STATUS.OK) return false;
			if (!showFailing.value && hasEnabledRules.value && !ruleMatches.value.get(row.code)?.pass) return false;
			return true;
		}));
		/**
		* 推算较去年的变化值（百分点；任一侧缺失为 null）
		* @param row 展示行
		* @returns 变化值（百分点）
		*/
		const deltaValue = (row) => row.projectedYield !== null && row.yieldLast !== null ? row.projectedYield - row.yieldLast : null;
		/** 全部可配置数据列的完整定义（key → 列定义；顺序即默认顺序，与配置清单一致） */
		const columnDefByKey = {
			name: {
				key: "name",
				label: DIVIDEND_COLUMN_LABEL.name
			},
			industry: {
				key: "industry",
				label: DIVIDEND_COLUMN_LABEL.industry
			},
			price: {
				key: "price",
				label: DIVIDEND_COLUMN_LABEL.price,
				align: "right",
				sortable: true,
				sortValue: (row) => row.price
			},
			ttmYield: {
				key: "ttmYield",
				label: DIVIDEND_COLUMN_LABEL.ttmYield,
				align: "right",
				sortable: true,
				sortValue: (row) => row.ttmYield
			},
			projectedYield: {
				key: "projectedYield",
				label: DIVIDEND_COLUMN_LABEL.projectedYield,
				align: "right",
				sortable: true,
				sortValue: (row) => row.projectedYield
			},
			projectedDelta: {
				key: "projectedDelta",
				label: DIVIDEND_COLUMN_LABEL.projectedDelta,
				align: "right",
				sortable: true,
				sortValue: (row) => deltaValue(row)
			},
			yieldLast: {
				key: "yieldLast",
				label: DIVIDEND_COLUMN_LABEL.yieldLast,
				align: "right",
				sortable: true,
				sortValue: (row) => row.yieldLast
			},
			payoutLast: {
				key: "payoutLast",
				label: DIVIDEND_COLUMN_LABEL.payoutLast,
				align: "right",
				sortable: true,
				sortValue: (row) => row.payoutLast
			},
			dividendYears: {
				key: "dividendYears",
				label: DIVIDEND_COLUMN_LABEL.dividendYears,
				align: "right",
				sortable: true,
				sortValue: (row) => row.dividendYears
			},
			netProfitH1: {
				key: "netProfitH1",
				label: DIVIDEND_COLUMN_LABEL.netProfitH1,
				align: "right",
				sortable: true,
				sortValue: (row) => row.netProfitH1
			},
			netProfitYoY: {
				key: "netProfitYoY",
				label: DIVIDEND_COLUMN_LABEL.netProfitYoY,
				align: "right",
				sortable: true,
				sortValue: (row) => row.netProfitYoY
			},
			debtRatio: {
				key: "debtRatio",
				label: DIVIDEND_COLUMN_LABEL.debtRatio,
				align: "right",
				sortable: true,
				sortValue: (row) => row.debtRatio
			},
			peTtm: {
				key: "peTtm",
				label: DIVIDEND_COLUMN_LABEL.peTtm,
				align: "right",
				sortable: true,
				sortValue: (row) => row.peTtm
			}
		};
		/** 表头配置（插件设置里编辑的显隐 + 顺序；依赖 settings.values，改配置即重算） */
		const columnConfig = computed(() => normalizeDividendColumnConfig(props.settings.values[DIVIDEND_SETTINGS_COLUMN_KEY], DIVIDEND_CONFIGURABLE_COLUMN_KEYS));
		/** 表格基础列（按用户配置的显隐与顺序出列；两个 tab 共用） */
		const baseColumns = computed(() => visibleDividendColumns(columnConfig.value).map((key) => columnDefByKey[key]));
		/** 最左操作列：加入 / 移出自选按钮（行内显式操作，替代原行尾星标） */
		const actionColumn = {
			key: "action",
			label: DIVIDEND_COLUMN_LABEL.action
		};
		/** 当前 tab 的表格列（操作列固定最左；自选 tab 不展示规则列——自选本身已是筛选的结果） */
		const tableColumns = computed(() => activeTab.value === "watchlist" ? [actionColumn, ...baseColumns.value] : [
			actionColumn,
			...baseColumns.value,
			{
				key: "ruleResult",
				label: DIVIDEND_COLUMN_LABEL.ruleResult
			}
		]);
		/** 个别列的最小可读宽度（px）；未登记的数值列按默认值算 */
		const DIVIDEND_COLUMN_MIN_WIDTH = {
			name: 200,
			industry: 88,
			action: 64,
			ruleResult: 88
		};
		/** 数值列的最小可读宽度（px） */
		const tableMinWidth = computed(() => {
			return `${tableColumns.value.reduce((sum, col) => sum + (DIVIDEND_COLUMN_MIN_WIDTH[col.key] ?? NUMERIC_COLUMN_MIN_WIDTH), 0) + EXPAND_COLUMN_MIN_WIDTH}px`;
		});
		/**
		* 操作列按钮文案（筛选 tab：加自选 / 已自选；自选 tab：恒为移除）
		* @param row 展示行
		* @returns 按钮文案
		*/
		const actionLabel = (row) => {
			if (activeTab.value === "watchlist") return WATCH_REMOVE_LABEL;
			return watchSet.value.has(row.code) ? "已自选" : `＋ ${WATCH_ADD_LABEL}`;
		};
		/**
		* 操作列按钮样式（未加入 = 主色实底；已加入 / 移除 = 中性弱底）
		* @param row 展示行
		* @returns 类名
		*/
		const actionClass = (row) => {
			const watched = watchSet.value.has(row.code);
			if (activeTab.value === "watchlist") return "bg-flat-weak text-text-secondary hover:bg-down-weak hover:text-down";
			return watched ? "bg-flat-weak text-text-tertiary" : "bg-primary-weak text-primary hover:brightness-95";
		};
		/** 当前 tab 的表格行 */
		const tableRows = computed(() => activeTab.value === "watchlist" ? watchRows.value : rows.value);
		/** 当前 tab 的空态文案 */
		const emptyText = computed(() => {
			if (activeTab.value === "watchlist") return WATCH_EMPTY_TEXT;
			return allRows.value.length === 0 ? DIVIDEND_EMPTY_TEXT : "";
		});
		/**
		* 行 key
		* @param row 展示行
		* @returns 行 key（裸代码，快照内唯一）
		*/
		const rowKey = (row) => row.code;
		/**
		* 持久化规则配置（每次增删改后调用；失败给行内提示）
		* @param configs 新规则配置
		*/
		const persistRules = (configs) => {
			ruleNotice.value = "";
			props.repo.saveRuleConfig(configs).catch((error) => {
				ruleNotice.value = `${RULE_SAVE_FAILED}：${error instanceof Error ? error.message : String(error)}`;
			});
		};
		/** 规则参数变更（输入框 change 即保存；参数已由 v-model 写回实例） */
		const onRuleParamChange = () => {
			persistRules(ruleConfigs.value);
		};
		/**
		* 删除规则
		* @param config 规则实例
		*/
		const onRemoveRule = (config) => {
			persistRules(ruleConfigs.value.filter((item) => item.id !== config.id));
		};
		/**
		* 添加规则（按下拉选中的类型；参数取类型默认值）
		*/
		const onAddRule = () => {
			if (selectedRuleType.value === "") return;
			const def = RULE_TYPE_REGISTRY[selectedRuleType.value];
			if (!def) return;
			persistRules([...ruleConfigs.value, createRuleInstance(def.key)]);
			selectedRuleType.value = "";
		};
		/** 恢复默认预置规则 */
		const onResetRules = () => {
			persistRules(createDefaultRules());
		};
		/**
		* 去年分红率是否超额（>100% 的特别分红年份，推算照算但明示异常）
		* @param row 展示行
		* @returns 是否超额
		*/
		const isPayoutOverdue = (row) => row.payoutLast !== null && row.payoutLast > 1;
		/**
		* 涨跌文案样式
		* @param value 数值
		* @returns 文本色类名
		*/
		const changeClass = (value) => format.trendClass(format.trend(value));
		/**
		* 推算状态的徽标类名
		*
		* 抽成带类型签名的函数而不是在模板里直接索引常量：`<component :is>` 渲染组件的
		* 作用域插槽入参会丢类型（`row` 被推断成 any），拿 any 去索引常量会报 TS7053。
		* @param status 推算状态
		* @returns 徽标类名
		*/
		const statusBadgeClass = (status) => DIVIDEND_PROJECT_STATUS_BADGE_CLASS[status];
		/**
		* 推算状态的文案（同上：模板索引常量会丢类型）
		* @param status 推算状态
		* @returns 状态文案
		*/
		const statusLabel = (status) => DIVIDEND_PROJECT_STATUS_LABEL[status];
		/**
		* 格式化价格（元）
		* @param value 价格
		* @returns 文案
		*/
		const formatPrice = (value) => value === null ? "—" : value.toFixed(2);
		/**
		* 格式化股息率（%，两位）
		* @param value 股息率
		* @returns 文案
		*/
		const formatYield = (value) => value === null ? "—" : `${value.toFixed(2)}%`;
		/**
		* 格式化分红率（0-1 → %，一位）
		* @param value 分红率
		* @returns 文案
		*/
		const formatPayout = (value) => value === null ? "—" : `${(value * 100).toFixed(1)}%`;
		/**
		* 格式化负债率（%，一位）
		* @param value 负债率
		* @returns 文案
		*/
		const formatDebtRatio = (value) => value === null ? "—" : `${value.toFixed(1)}%`;
		/**
		* 格式化覆盖倍数（×，两位）
		* @param value 倍数
		* @returns 文案
		*/
		const formatCover = (value) => value === null ? "—" : `${value.toFixed(2)}×`;
		/**
		* 格式化每股金额（元，两位）
		* @param value 金额
		* @returns 文案
		*/
		const formatPerShare = (value) => value === null ? "—" : `${value.toFixed(2)}元`;
		/**
		* 格式化金额（元 → 亿元）
		* @param value 金额（元）
		* @returns 文案
		*/
		const formatYuanToYi = (value) => value === null ? "—" : `${(value / YUAN_PER_YI).toFixed(2)}亿`;
		/**
		* 格式化每股分红（元，最多 3 位，兼容茅台级的 28 元派息）
		* @param value 每股分红
		* @returns 文案
		*/
		const formatDps = (value) => value === null ? "—" : `${value.toFixed(3)}元`;
		/**
		* 格式化中报净利比（倍数）
		* @param value 净利比
		* @returns 文案
		*/
		const formatGrowth = (value) => value === null ? "—" : `${value.toFixed(2)}×`;
		/**
		* 格式化连续分红年数
		* @param value 年数（null = 未采集）
		* @returns 文案
		*/
		const formatDividendYears = (value) => value === null ? "—" : `${value}年`;
		/**
		* 推算较去年的变化文案
		* @param row 展示行
		* @returns 文案
		*/
		const formatDelta = (row) => {
			const delta = deltaValue(row);
			if (delta === null) return "—";
			return `${delta > 0 ? "+" : ""}${delta.toFixed(2)}pp`;
		};
		/**
		* 规则列的完整原因文案（title 提示用）
		* @param row 展示行
		* @returns 原因串（通过为空串）
		*/
		const ruleReasonText = (row) => {
			const match = ruleMatches.value.get(row.code);
			if (!match) return "";
			return [...match.excludeReasons, ...match.failedFilters].join("；");
		};
		/**
		* 规则列的短徽标文案（剔除优先展示）
		* @param row 展示行
		* @returns 徽标文案
		*/
		const ruleBadgeText = (row) => {
			const match = ruleMatches.value.get(row.code);
			if (!match) return RULE_NO_ACTIVE_HINT;
			if (match.pass) return RULE_PASS_BADGE;
			const first = match.excludeReasons[0] ?? match.failedFilters[0] ?? "";
			const prefix = match.excludeReasons.length > 0 ? RULE_EXCLUDE_BADGE : RULE_FAIL_BADGE;
			return first === "" ? prefix : `${prefix}·${first}`;
		};
		/**
		* 规则列徽标样式类
		* @param row 展示行
		* @returns 类名
		*/
		const ruleBadgeClass = (row) => {
			const match = ruleMatches.value.get(row.code);
			if (!match || match.pass) return "bg-primary-weak text-primary";
			return match.excludeReasons.length > 0 ? "bg-up-weak text-up" : "bg-flat-weak text-text-tertiary";
		};
		/**
		* 扫描时间文案
		* @param value 毫秒时间戳
		* @returns 本地时间文案
		*/
		const formatScannedAt = (value) => new Date(value).toLocaleString("zh-CN");
		/**
		* 切换某行的展开态
		* @param row 展示行
		*/
		const onToggleExpand = (row) => {
			expandedKeys.value = expandedKeys.value.includes(row.code) ? expandedKeys.value.filter((item) => item !== row.code) : [row.code];
		};
		/**
		* 双击行：打开个股详情侧栏（携带本页快照为上下文，侧栏内可逐只切换）
		* @param row 展示行
		*/
		const onRowDblclick = (row) => {
			props.deps.stockOpen.openSidebar(row.code, rows.value.map((item) => ({
				symbol: item.code,
				name: item.name,
				price: item.price,
				changePercent: item.changePercent
			})));
		};
		/** 清除全部快捷筛选 */
		const onClearFilters = () => {
			publishedOnly.value = false;
			growingOnly.value = false;
			projectableOnly.value = false;
			showFailing.value = false;
		};
		/**
		* 触发一次扫描（点击触发，不轮询；结果落库）
		*/
		const onScan = async () => {
			if (scanning.value) return;
			scanning.value = true;
			scanNotice.value = "";
			progress.value = null;
			try {
				await runDividendScan(props.deps, props.repo, universeLimit.value, (next) => {
					progress.value = next;
				});
			} catch (error) {
				scanNotice.value = `${DIVIDEND_SCAN_FAILED}：${error instanceof Error ? error.message : String(error)}`;
			} finally {
				scanning.value = false;
				progress.value = null;
			}
		};
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", _hoisted_1, [
				createCommentVNode(" 页面级视图切换：与龙虎榜 / 行情情绪页一致的 underline 风格，置于卡片之上 "),
				createElementVNode("div", _hoisted_2, [(openBlock(), createBlock(resolveDynamicComponent(__props.deps.ui.Tabs), {
					modelValue: activeTab.value,
					"onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => activeTab.value = $event),
					options: unref(DIVIDEND_TAB_OPTIONS),
					variant: "underline"
				}, null, 8, ["modelValue", "options"]))]),
				(openBlock(), createBlock(resolveDynamicComponent(__props.deps.ui.Card), null, {
					default: withCtx(() => [
						createElementVNode("div", _hoisted_3, [createElementVNode("div", _hoisted_4, [createElementVNode("h1", _hoisted_5, [(openBlock(), createBlock(resolveDynamicComponent(__props.deps.ui.Icon), {
							name: unref(DIVIDEND_MENU_ICON),
							size: 16
						}, null, 8, ["name"])), createTextVNode(" " + toDisplayString(unref(DIVIDEND_PAGE_TITLE)), 1)]), createElementVNode("p", _hoisted_6, toDisplayString(unref(DIVIDEND_PAGE_SUBTITLE)), 1)]), activeTab.value === unref("screen") ? (openBlock(), createElementBlock("div", _hoisted_7, [
							createElementVNode("label", _hoisted_8, [createTextVNode(toDisplayString(unref(DIVIDEND_UNIVERSE_LABEL)) + " ", 1), withDirectives(createElementVNode("select", {
								"onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => universeLimit.value = $event),
								class: "rounded-lg bg-flat-weak px-2 py-1 text-xs text-text outline-none",
								disabled: scanning.value
							}, [(openBlock(true), createElementBlock(Fragment, null, renderList(unref(DIVIDEND_UNIVERSE_OPTIONS), (option) => {
								return openBlock(), createElementBlock("option", {
									key: option,
									value: option
								}, toDisplayString(option), 9, _hoisted_10);
							}), 128))], 8, _hoisted_9), [[
								vModelSelect,
								universeLimit.value,
								void 0,
								{ number: true }
							]])]),
							progress.value ? (openBlock(), createElementBlock("span", _hoisted_11, toDisplayString(unref(DIVIDEND_SCAN_RUNNING)) + " " + toDisplayString(progress.value.done) + "/" + toDisplayString(progress.value.total), 1)) : createCommentVNode("v-if", true),
							(openBlock(), createBlock(resolveDynamicComponent(__props.deps.ui.Button), {
								disabled: scanning.value,
								onClick: onScan
							}, {
								default: withCtx(() => [(openBlock(), createBlock(resolveDynamicComponent(__props.deps.ui.Icon), {
									name: unref(DIVIDEND_MENU_ICON),
									size: 14
								}, null, 8, ["name"])), createTextVNode(" " + toDisplayString(unref(DIVIDEND_SCAN_BUTTON)), 1)]),
								_: 1
							}, 8, ["disabled"]))
						])) : createCommentVNode("v-if", true)]),
						createCommentVNode(" 扫描与口径信息只属于「股息筛选」tab；自选 tab 只读本地库 "),
						activeTab.value === unref("screen") ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [
							createCommentVNode(" 口径信息：报告期、覆盖与披露进度一并如实给出 "),
							meta.value ? (openBlock(), createElementBlock("div", _hoisted_12, [
								createElementVNode("span", null, toDisplayString(unref(DIVIDEND_HEADER_LABEL).scannedAt) + "：" + toDisplayString(formatScannedAt(meta.value.scannedAt)), 1),
								createElementVNode("span", null, toDisplayString(unref(DIVIDEND_HEADER_LABEL).universe) + "：" + toDisplayString(meta.value.universeLimit), 1),
								meta.value.universeTotal !== null ? (openBlock(), createElementBlock("span", _hoisted_13, toDisplayString(unref(DIVIDEND_HEADER_LABEL).marketTotal) + "：" + toDisplayString(meta.value.universeTotal), 1)) : createCommentVNode("v-if", true),
								createElementVNode("span", null, toDisplayString(unref(DIVIDEND_HEADER_LABEL).published) + "：" + toDisplayString(meta.value.publishedCount) + "/" + toDisplayString(meta.value.rowCount), 1),
								createElementVNode("span", null, toDisplayString(unref(DIVIDEND_HEADER_LABEL).projectable) + "：" + toDisplayString(meta.value.projectableCount) + "/" + toDisplayString(meta.value.rowCount), 1),
								createElementVNode("span", null, toDisplayString(unref(DIVIDEND_HEADER_LABEL).periodH1) + "：" + toDisplayString(meta.value.periods.h1), 1),
								createElementVNode("span", null, toDisplayString(unref(DIVIDEND_HEADER_LABEL).periodFyLast) + "：" + toDisplayString(meta.value.periods.fyLast), 1)
							])) : createCommentVNode("v-if", true),
							scanNotice.value ? (openBlock(), createElementBlock("p", _hoisted_14, toDisplayString(scanNotice.value), 1)) : createCommentVNode("v-if", true),
							createCommentVNode(" 快捷筛选开关（纯客户端，快照行内过滤） "),
							allRows.value.length > 0 ? (openBlock(), createElementBlock("div", _hoisted_15, [
								createElementVNode("button", {
									type: "button",
									class: normalizeClass(["pressable rounded-md px-1.5 py-0.5 text-[11px] active:scale-95", publishedOnly.value ? "bg-primary-weak text-primary" : "bg-flat-weak text-text-secondary"]),
									"aria-pressed": publishedOnly.value,
									onClick: _cache[2] || (_cache[2] = ($event) => publishedOnly.value = !publishedOnly.value)
								}, toDisplayString(unref(DIVIDEND_FILTER_PUBLISHED)), 11, _hoisted_16),
								createElementVNode("button", {
									type: "button",
									class: normalizeClass(["pressable rounded-md px-1.5 py-0.5 text-[11px] active:scale-95", growingOnly.value ? "bg-primary-weak text-primary" : "bg-flat-weak text-text-secondary"]),
									"aria-pressed": growingOnly.value,
									onClick: _cache[3] || (_cache[3] = ($event) => growingOnly.value = !growingOnly.value)
								}, toDisplayString(unref(DIVIDEND_FILTER_GROWING)), 11, _hoisted_17),
								createElementVNode("button", {
									type: "button",
									class: normalizeClass(["pressable rounded-md px-1.5 py-0.5 text-[11px] active:scale-95", projectableOnly.value ? "bg-primary-weak text-primary" : "bg-flat-weak text-text-secondary"]),
									"aria-pressed": projectableOnly.value,
									onClick: _cache[4] || (_cache[4] = ($event) => projectableOnly.value = !projectableOnly.value)
								}, toDisplayString(unref(DIVIDEND_FILTER_PROJECTABLE)), 11, _hoisted_18),
								createElementVNode("button", {
									type: "button",
									class: normalizeClass(["pressable rounded-md px-1.5 py-0.5 text-[11px] active:scale-95", showFailing.value ? "bg-primary-weak text-primary" : "bg-flat-weak text-text-secondary"]),
									"aria-pressed": showFailing.value,
									onClick: _cache[5] || (_cache[5] = ($event) => showFailing.value = !showFailing.value)
								}, [createTextVNode(toDisplayString(unref(RULE_SHOW_FAILED)) + " ", 1), ruleFailCount.value > 0 ? (openBlock(), createElementBlock("span", _hoisted_20, "（" + toDisplayString(ruleFailCount.value) + "）", 1)) : createCommentVNode("v-if", true)], 10, _hoisted_19),
								filterActive.value ? (openBlock(), createElementBlock("span", _hoisted_21, [createTextVNode(toDisplayString(unref(DIVIDEND_FILTER_SUMMARY)(rows.value.length, allRows.value.length)) + " ", 1), createElementVNode("button", {
									type: "button",
									class: "pressable ml-1 rounded px-1 py-0.5 text-primary active:scale-95",
									onClick: onClearFilters
								}, toDisplayString(unref(DIVIDEND_FILTER_CLEAR)), 1)])) : createCommentVNode("v-if", true)
							])) : createCommentVNode("v-if", true)
						], 64)) : createCommentVNode("v-if", true)
					]),
					_: 1
				})),
				createCommentVNode(" 可配置规则面板：增删改全部即时持久化，评估纯客户端（仅筛选 tab） "),
				activeTab.value === unref("screen") ? (openBlock(), createBlock(resolveDynamicComponent(__props.deps.ui.Card), {
					key: 0,
					title: unref(RULE_PANEL_TITLE)
				}, {
					extra: withCtx(() => [createElementVNode("span", _hoisted_22, " 通过 " + toDisplayString(rulePassCount.value) + "/" + toDisplayString(allRows.value.length), 1)]),
					default: withCtx(() => [
						createElementVNode("div", _hoisted_23, [(openBlock(), createElementBlock(Fragment, null, renderList(["filter", "exclude"], (group) => {
							return createElementVNode("div", { key: group }, [createElementVNode("p", _hoisted_24, [
								createElementVNode("span", { class: normalizeClass(["inline-block h-1.5 w-1.5 rounded-full", group === "filter" ? "bg-primary" : "bg-up"]) }, null, 2),
								createTextVNode(" " + toDisplayString(group === "filter" ? unref(RULE_GROUP_TITLE_FILTER) : unref(RULE_GROUP_TITLE_EXCLUDE)) + " ", 1),
								createElementVNode("span", _hoisted_25, toDisplayString(ruleGroups.value[group].length), 1)
							]), createElementVNode("div", _hoisted_26, [(openBlock(true), createElementBlock(Fragment, null, renderList(ruleGroups.value[group], (config) => {
								return openBlock(), createElementBlock("div", {
									key: config.id,
									class: "group flex flex-wrap items-center gap-x-2 gap-y-1 rounded-lg bg-flat-weak px-2.5 py-1.5 transition-colors"
								}, [
									createElementVNode("span", {
										class: "text-xs font-medium text-text",
										title: unref(RULE_TYPE_REGISTRY)[config.type]?.description
									}, toDisplayString(unref(formatRuleText)(config)), 9, _hoisted_27),
									(openBlock(true), createElementBlock(Fragment, null, renderList(unref(RULE_TYPE_REGISTRY)[config.type]?.params ?? [], (field) => {
										return openBlock(), createElementBlock(Fragment, { key: field.key }, [field.kind === "number" ? (openBlock(), createElementBlock("label", _hoisted_28, [
											createTextVNode(toDisplayString(field.label) + " ", 1),
											withDirectives(createElementVNode("input", {
												type: "number",
												class: "w-16 rounded-md bg-surface px-1.5 py-0.5 text-xs tabular-nums text-text outline-none focus:ring-1 focus:ring-primary",
												step: field.unit === "×" ? "0.1" : "1",
												"onUpdate:modelValue": ($event) => config.params[field.key] = $event,
												onChange: _cache[6] || (_cache[6] = ($event) => onRuleParamChange())
											}, null, 40, _hoisted_29), [[
												vModelText,
												config.params[field.key],
												void 0,
												{ number: true }
											]]),
											createTextVNode(" " + toDisplayString(field.unit), 1)
										])) : (openBlock(), createElementBlock("label", _hoisted_30, [createTextVNode(toDisplayString(field.label) + " ", 1), withDirectives(createElementVNode("input", {
											type: "text",
											class: "w-64 rounded-md bg-surface px-1.5 py-0.5 text-xs text-text outline-none focus:ring-1 focus:ring-primary",
											"onUpdate:modelValue": ($event) => config.params[field.key] = $event,
											onChange: _cache[7] || (_cache[7] = ($event) => onRuleParamChange())
										}, null, 40, _hoisted_31), [[vModelText, config.params[field.key]]])]))], 64);
									}), 128)),
									createElementVNode("button", {
										type: "button",
										class: "pressable ml-auto rounded px-1 text-xs text-text-tertiary opacity-0 transition-opacity hover:text-up group-hover:opacity-100 active:scale-95",
										"aria-label": unref(RULE_REMOVE_LABEL),
										onClick: ($event) => onRemoveRule(config)
									}, " ✕ ", 8, _hoisted_32)
								]);
							}), 128)), ruleGroups.value[group].length === 0 ? (openBlock(), createElementBlock("p", _hoisted_33, " （本组暂无规则） ")) : createCommentVNode("v-if", true)])]);
						}), 64))]),
						createElementVNode("div", _hoisted_34, [
							withDirectives(createElementVNode("select", {
								"onUpdate:modelValue": _cache[8] || (_cache[8] = ($event) => selectedRuleType.value = $event),
								class: "rounded-lg bg-flat-weak px-2 py-1.5 text-xs text-text outline-none",
								"aria-label": unref(RULE_ADD_PLACEHOLDER)
							}, [createElementVNode("option", _hoisted_36, toDisplayString(unref(RULE_ADD_PLACEHOLDER)), 1), (openBlock(true), createElementBlock(Fragment, null, renderList(unref(RULE_TYPE_REGISTRY), (def, key) => {
								return openBlock(), createElementBlock("option", {
									key,
									value: key
								}, toDisplayString(def.label) + "（" + toDisplayString(def.defaultGroup === "filter" ? "筛选" : "剔除") + "） ", 9, _hoisted_37);
							}), 128))], 8, _hoisted_35), [[vModelSelect, selectedRuleType.value]]),
							(openBlock(), createBlock(resolveDynamicComponent(__props.deps.ui.Button), {
								disabled: selectedRuleType.value === "",
								onClick: onAddRule
							}, {
								default: withCtx(() => [createTextVNode("＋ " + toDisplayString(unref(RULE_ADD_BUTTON)), 1)]),
								_: 1
							}, 8, ["disabled"])),
							(openBlock(), createBlock(resolveDynamicComponent(__props.deps.ui.Button), {
								variant: "ghost",
								onClick: onResetRules
							}, {
								default: withCtx(() => [createTextVNode(toDisplayString(unref(RULE_RESET_DEFAULT)), 1)]),
								_: 1
							})),
							_cache[14] || (_cache[14] = createElementVNode("span", { class: "text-[11px] text-text-tertiary" }, "未通过的行默认不在列表，用上方「显示未通过」查看原因", -1))
						]),
						ruleNotice.value ? (openBlock(), createElementBlock("p", _hoisted_38, toDisplayString(ruleNotice.value), 1)) : createCommentVNode("v-if", true)
					]),
					_: 1
				}, 8, ["title"])) : createCommentVNode("v-if", true),
				(openBlock(), createBlock(resolveDynamicComponent(__props.deps.ui.Card), { title: activeTab.value === unref("watchlist") ? unref(WATCH_CARD_TITLE) : unref(DIVIDEND_DETAIL_TITLE) }, {
					extra: withCtx(() => [activeTab.value === unref("watchlist") ? (openBlock(), createElementBlock("span", _hoisted_39, toDisplayString(unref(WATCH_COUNT_TEXT)(watchRows.value.length)), 1)) : createCommentVNode("v-if", true), watchFetchProgress.value ? (openBlock(), createElementBlock("span", _hoisted_40, " 正在拉取快照外个股指标 " + toDisplayString(watchFetchProgress.value.done) + "/" + toDisplayString(watchFetchProgress.value.total) + "… ", 1)) : (openBlock(), createElementBlock(Fragment, { key: 2 }, [bulkAddableCount.value > 0 ? (openBlock(), createElementBlock("button", {
						key: 0,
						type: "button",
						class: "pressable rounded-md bg-flat-weak px-1.5 py-0.5 text-[11px] text-text-secondary hover:text-text active:scale-95",
						onClick: onAddAllToWatch
					}, toDisplayString(unref(WATCH_BULK_ADD)) + "（" + toDisplayString(bulkAddableCount.value) + "） ", 1)) : createCommentVNode("v-if", true), _cache[15] || (_cache[15] = createElementVNode("span", { class: "text-xs text-text-tertiary" }, "点行看推算明细，双击打开个股详情", -1))], 64))]),
					default: withCtx(() => [activeTab.value === unref("watchlist") && searchAvailable.value ? (openBlock(), createElementBlock("div", _hoisted_41, [
						withDirectives(createElementVNode("input", {
							"onUpdate:modelValue": _cache[9] || (_cache[9] = ($event) => searchKeyword.value = $event),
							type: "text",
							class: "w-full max-w-md rounded-lg bg-flat-weak px-3 py-1.5 text-sm text-text outline-none placeholder:text-text-tertiary focus:ring-1 focus:ring-primary",
							placeholder: unref(WATCH_SEARCH_PLACEHOLDER),
							"aria-label": unref(WATCH_SEARCH_LABEL),
							onFocus: _cache[10] || (_cache[10] = ($event) => searchOpen.value = searchResults.value.length > 0),
							onBlur: _cache[11] || (_cache[11] = ($event) => searchOpen.value = false)
						}, null, 40, _hoisted_42), [[vModelText, searchKeyword.value]]),
						searching.value ? (openBlock(), createElementBlock("span", _hoisted_43, "搜索中…")) : createCommentVNode("v-if", true),
						createCommentVNode(" 结果下拉：mousedown.prevent 抢在 blur 之前完成选中 "),
						searchOpen.value && searchResults.value.length > 0 ? (openBlock(), createElementBlock("div", _hoisted_44, [(openBlock(true), createElementBlock(Fragment, null, renderList(searchResults.value, (result) => {
							return openBlock(), createElementBlock("button", {
								key: result.code,
								type: "button",
								class: "flex w-full items-center justify-between gap-2 px-3 py-1.5 text-left text-xs hover:bg-flat-weak",
								onMousedown: withModifiers(($event) => onSelectResult(result), ["prevent"])
							}, [createElementVNode("span", _hoisted_46, toDisplayString(resultLabel(result)), 1), createElementVNode("span", _hoisted_47, toDisplayString(result.code), 1)], 40, _hoisted_45);
						}), 128))])) : createCommentVNode("v-if", true),
						searchOpen.value && searchKeyword.value.trim().length >= 2 && !searching.value && searchResults.value.length === 0 && !searchNotice.value ? (openBlock(), createElementBlock("p", _hoisted_48, toDisplayString(unref(WATCH_SEARCH_NO_RESULT)), 1)) : createCommentVNode("v-if", true),
						searchNotice.value ? (openBlock(), createElementBlock("p", _hoisted_49, toDisplayString(searchNotice.value), 1)) : createCommentVNode("v-if", true),
						createCommentVNode(" 预览：快照命中直接渲染；样本池外按需拉取（口径与扫描同源，不落库）。\r\n             自选是用户主动加入的清单，不参与筛选 tab 的规则判定，故预览不带规则徽标 "),
						previewResult.value ? (openBlock(), createElementBlock("div", _hoisted_50, [
							createElementVNode("div", _hoisted_51, [
								createElementVNode("span", _hoisted_52, toDisplayString(unref(WATCH_PREVIEW_TITLE)) + "：" + toDisplayString(previewResult.value.name || previewResult.value.code), 1),
								createElementVNode("span", _hoisted_53, toDisplayString(previewResult.value.code), 1),
								createElementVNode("button", {
									type: "button",
									class: "pressable ml-auto rounded px-1 text-xs text-text-tertiary hover:text-text active:scale-95",
									"aria-label": "关闭预览",
									onClick: onClosePreview
								}, " ✕ ")
							]),
							previewFetching.value ? (openBlock(), createElementBlock("p", _hoisted_54, toDisplayString(unref(WATCH_PREVIEW_FETCHING)), 1)) : previewFetchError.value ? (openBlock(), createElementBlock("p", _hoisted_55, toDisplayString(previewFetchError.value), 1)) : createCommentVNode("v-if", true),
							effectivePreviewRow.value ? (openBlock(), createElementBlock(Fragment, { key: 2 }, [createElementVNode("dl", _hoisted_56, [
								createElementVNode("div", null, [createElementVNode("dt", _hoisted_57, toDisplayString(unref(DIVIDEND_COLUMN_LABEL).price), 1), createElementVNode("dd", _hoisted_58, toDisplayString(formatPrice(effectivePreviewRow.value.price)), 1)]),
								createElementVNode("div", null, [createElementVNode("dt", _hoisted_59, toDisplayString(unref(DIVIDEND_COLUMN_LABEL).ttmYield), 1), createElementVNode("dd", _hoisted_60, toDisplayString(formatYield(effectivePreviewRow.value.ttmYield)), 1)]),
								createElementVNode("div", null, [createElementVNode("dt", _hoisted_61, toDisplayString(unref(DIVIDEND_COLUMN_LABEL).projectedYield), 1), createElementVNode("dd", _hoisted_62, toDisplayString(formatYield(effectivePreviewRow.value.projectedYield)), 1)]),
								createElementVNode("div", null, [createElementVNode("dt", _hoisted_63, toDisplayString(unref(DIVIDEND_COLUMN_LABEL).yieldLast), 1), createElementVNode("dd", _hoisted_64, toDisplayString(formatYield(effectivePreviewRow.value.yieldLast)), 1)]),
								createElementVNode("div", null, [createElementVNode("dt", _hoisted_65, toDisplayString(unref(DIVIDEND_COLUMN_LABEL).payoutLast), 1), createElementVNode("dd", _hoisted_66, toDisplayString(formatPayout(effectivePreviewRow.value.payoutLast)), 1)]),
								createElementVNode("div", null, [createElementVNode("dt", _hoisted_67, toDisplayString(unref(DIVIDEND_COLUMN_LABEL).dividendYears), 1), createElementVNode("dd", _hoisted_68, toDisplayString(formatDividendYears(effectivePreviewRow.value.dividendYears)), 1)]),
								createElementVNode("div", null, [createElementVNode("dt", _hoisted_69, toDisplayString(unref(DIVIDEND_COLUMN_LABEL).debtRatio), 1), createElementVNode("dd", _hoisted_70, toDisplayString(formatDebtRatio(effectivePreviewRow.value.debtRatio)), 1)]),
								createElementVNode("div", null, [createElementVNode("dt", _hoisted_71, toDisplayString(unref(DIVIDEND_COLUMN_LABEL).peTtm), 1), createElementVNode("dd", _hoisted_72, toDisplayString(effectivePreviewRow.value.peTtm === null ? unref("—") : effectivePreviewRow.value.peTtm.toFixed(1)), 1)])
							]), previewIsOnDemand.value ? (openBlock(), createElementBlock("p", _hoisted_73, toDisplayString(unref(WATCH_PREVIEW_ON_DEMAND_NOTE)), 1)) : createCommentVNode("v-if", true)], 64)) : createCommentVNode("v-if", true),
							createElementVNode("div", _hoisted_74, [(openBlock(), createBlock(resolveDynamicComponent(__props.deps.ui.Button), {
								variant: "ghost",
								onClick: onTogglePreviewWatch
							}, {
								default: withCtx(() => [createTextVNode(toDisplayString(previewWatched.value ? unref(WATCH_REMOVE_LABEL) : unref(WATCH_ADD_LABEL)), 1)]),
								_: 1
							})), (openBlock(), createBlock(resolveDynamicComponent(__props.deps.ui.Button), {
								variant: "ghost",
								onClick: onOpenPreviewDetail
							}, {
								default: withCtx(() => [createTextVNode(toDisplayString(unref(WATCH_PREVIEW_OPEN_DETAIL)), 1)]),
								_: 1
							}))])
						])) : createCommentVNode("v-if", true)
					])) : createCommentVNode("v-if", true), tableRows.value.length === 0 ? (openBlock(), createElementBlock("div", _hoisted_75, [(openBlock(), createBlock(resolveDynamicComponent(__props.deps.ui.Empty), { text: emptyText.value }, null, 8, ["text"])), activeTab.value === unref("screen") && allRows.value.length > 0 && ruleFailCount.value > 0 && !showFailing.value ? (openBlock(), createElementBlock("p", _hoisted_76, [createElementVNode("button", {
						type: "button",
						class: "pressable rounded-md bg-primary-weak px-2 py-1 text-xs text-primary active:scale-95",
						onClick: _cache[12] || (_cache[12] = ($event) => showFailing.value = true)
					}, toDisplayString(unref(RULE_SHOW_FAILED)) + "（" + toDisplayString(ruleFailCount.value) + "） ", 1)])) : activeTab.value === unref("screen") && allRows.value.length > 0 && filterActive.value ? (openBlock(), createElementBlock("p", _hoisted_77, [createElementVNode("button", {
						type: "button",
						class: "pressable rounded-md bg-primary-weak px-2 py-1 text-xs text-primary active:scale-95",
						onClick: onClearFilters
					}, toDisplayString(unref(DIVIDEND_FILTER_CLEAR)), 1)])) : createCommentVNode("v-if", true)])) : (openBlock(), createBlock(resolveDynamicComponent(__props.deps.ui.Table), {
						key: 2,
						columns: tableColumns.value,
						rows: tableRows.value,
						"row-key": rowKey,
						"row-clickable": true,
						"enable-dblclick-nav": true,
						expandable: true,
						"expanded-keys": expandedKeys.value,
						"min-width": tableMinWidth.value,
						onRowClick: onToggleExpand,
						onRowDblclick,
						onToggleExpand
					}, {
						name: withCtx(({ row }) => [createElementVNode("span", _hoisted_78, [
							createElementVNode("span", _hoisted_79, toDisplayString(row.name), 1),
							createElementVNode("span", _hoisted_80, toDisplayString(row.code), 1),
							row.status !== unref(DIVIDEND_PROJECT_STATUS).OK && !watchMissingCodes.value.has(row.code) ? (openBlock(), createElementBlock("span", {
								key: 0,
								class: normalizeClass(["rounded px-1 py-0.5 text-[10px]", statusBadgeClass(row.status)])
							}, toDisplayString(statusLabel(row.status)), 3)) : createCommentVNode("v-if", true),
							isPayoutOverdue(row) ? (openBlock(), createElementBlock("span", _hoisted_81, toDisplayString(unref(DIVIDEND_PAYOUT_OVERDUE_BADGE)), 1)) : createCommentVNode("v-if", true)
						])]),
						industry: withCtx(({ row }) => [createElementVNode("span", _hoisted_82, toDisplayString(row.industry || unref("—")), 1)]),
						price: withCtx(({ row }) => [createElementVNode("span", _hoisted_83, toDisplayString(formatPrice(row.price)), 1)]),
						ttmYield: withCtx(({ row }) => [createTextVNode(toDisplayString(formatYield(row.ttmYield)), 1)]),
						yieldLast: withCtx(({ row }) => [createTextVNode(toDisplayString(formatYield(row.yieldLast)), 1)]),
						payoutLast: withCtx(({ row }) => [createTextVNode(toDisplayString(formatPayout(row.payoutLast)), 1)]),
						dividendYears: withCtx(({ row }) => [createTextVNode(toDisplayString(formatDividendYears(row.dividendYears)), 1)]),
						netProfitH1: withCtx(({ row }) => [createTextVNode(toDisplayString(formatYuanToYi(row.netProfitH1)), 1)]),
						netProfitYoY: withCtx(({ row }) => [row.netProfitYoY !== null ? (openBlock(), createElementBlock("span", {
							key: 0,
							class: normalizeClass(changeClass(row.netProfitYoY))
						}, toDisplayString(unref(format).percent(row.netProfitYoY)), 3)) : (openBlock(), createElementBlock("span", _hoisted_84, toDisplayString(unref("—")), 1))]),
						projectedYield: withCtx(({ row }) => [row.projectedYield !== null ? (openBlock(), createElementBlock("span", _hoisted_85, toDisplayString(formatYield(row.projectedYield)), 1)) : (openBlock(), createElementBlock("span", _hoisted_86, toDisplayString(unref("—")), 1))]),
						projectedDelta: withCtx(({ row }) => [deltaValue(row) !== null ? (openBlock(), createElementBlock("span", {
							key: 0,
							class: normalizeClass(changeClass(deltaValue(row) ?? 0))
						}, toDisplayString(formatDelta(row)), 3)) : (openBlock(), createElementBlock("span", _hoisted_87, toDisplayString(unref("—")), 1))]),
						debtRatio: withCtx(({ row }) => [createTextVNode(toDisplayString(formatDebtRatio(row.debtRatio)), 1)]),
						peTtm: withCtx(({ row }) => [createTextVNode(toDisplayString(row.peTtm === null ? unref("—") : row.peTtm.toFixed(1)), 1)]),
						ruleResult: withCtx(({ row }) => [createElementVNode("span", {
							class: normalizeClass(["inline-block whitespace-nowrap rounded-full px-2 py-0.5 text-[11px] leading-none", ruleBadgeClass(row)]),
							title: ruleReasonText(row)
						}, toDisplayString(hasEnabledRules.value ? ruleBadgeText(row) : unref(RULE_NO_ACTIVE_HINT)), 11, _hoisted_88)]),
						action: withCtx(({ row }) => [createElementVNode("button", {
							type: "button",
							class: normalizeClass(["pressable whitespace-nowrap rounded-md px-1.5 py-0.5 text-[11px] leading-none active:scale-95", actionClass(row)]),
							title: activeTab.value === unref("watchlist") ? unref(WATCH_REMOVE_LABEL) : watchSet.value.has(row.code) ? unref(WATCH_REMOVE_LABEL) : unref(WATCH_ADD_LABEL),
							"aria-label": activeTab.value === unref("watchlist") ? unref(WATCH_REMOVE_LABEL) : watchSet.value.has(row.code) ? unref(WATCH_REMOVE_LABEL) : unref(WATCH_ADD_LABEL),
							onClick: withModifiers(($event) => onToggleWatch(row), ["stop"]),
							onDblclick: _cache[13] || (_cache[13] = withModifiers(() => {}, ["stop"]))
						}, toDisplayString(actionLabel(row)), 43, _hoisted_89)]),
						expanded: withCtx(({ row }) => [createElementVNode("div", _hoisted_90, [
							createElementVNode("p", _hoisted_91, toDisplayString(unref(DIVIDEND_FORMULA_TEXT)), 1),
							ruleMatches.value.has(row.code) && !ruleMatches.value.get(row.code)?.pass ? (openBlock(), createElementBlock("div", _hoisted_92, [
								createElementVNode("p", _hoisted_93, toDisplayString(unref(DIVIDEND_DETAIL_LABEL).ruleMatch), 1),
								(openBlock(true), createElementBlock(Fragment, null, renderList(ruleMatches.value.get(row.code)?.excludeReasons, (reason) => {
									return openBlock(), createElementBlock("p", {
										key: `e-${reason}`,
										class: "mt-1 text-xs text-down"
									}, " 剔除：" + toDisplayString(reason), 1);
								}), 128)),
								(openBlock(true), createElementBlock(Fragment, null, renderList(ruleMatches.value.get(row.code)?.failedFilters, (reason) => {
									return openBlock(), createElementBlock("p", {
										key: `f-${reason}`,
										class: "mt-1 text-xs text-text-tertiary"
									}, " 未过：" + toDisplayString(reason), 1);
								}), 128))
							])) : createCommentVNode("v-if", true),
							createElementVNode("dl", _hoisted_94, [
								createElementVNode("div", null, [createElementVNode("dt", _hoisted_95, toDisplayString(unref(DIVIDEND_DETAIL_LABEL).status), 1), createElementVNode("dd", null, [createElementVNode("span", { class: normalizeClass(["rounded px-1 py-0.5 text-[10px]", statusBadgeClass(row.status)]) }, toDisplayString(statusLabel(row.status)), 3)])]),
								createElementVNode("div", null, [createElementVNode("dt", _hoisted_96, toDisplayString(unref(DIVIDEND_DETAIL_LABEL).dpsLast), 1), createElementVNode("dd", _hoisted_97, toDisplayString(formatDps(row.dpsLast)), 1)]),
								createElementVNode("div", null, [createElementVNode("dt", _hoisted_98, toDisplayString(unref(DIVIDEND_DETAIL_LABEL).dividendTotalLast), 1), createElementVNode("dd", _hoisted_99, toDisplayString(formatYuanToYi(row.dividendTotalLast)), 1)]),
								createElementVNode("div", null, [createElementVNode("dt", _hoisted_100, toDisplayString(unref(DIVIDEND_DETAIL_LABEL).netProfitFyLast), 1), createElementVNode("dd", _hoisted_101, toDisplayString(formatYuanToYi(row.netProfitFyLast)), 1)]),
								createElementVNode("div", null, [createElementVNode("dt", _hoisted_102, toDisplayString(unref(DIVIDEND_DETAIL_LABEL).payoutLast), 1), createElementVNode("dd", _hoisted_103, toDisplayString(formatPayout(row.payoutLast)), 1)]),
								createElementVNode("div", null, [createElementVNode("dt", _hoisted_104, toDisplayString(unref(DIVIDEND_DETAIL_LABEL).dividendYears), 1), createElementVNode("dd", _hoisted_105, toDisplayString(formatDividendYears(row.dividendYears)), 1)]),
								createElementVNode("div", null, [createElementVNode("dt", _hoisted_106, toDisplayString(unref(DIVIDEND_DETAIL_LABEL).ocfPerShareLast), 1), createElementVNode("dd", _hoisted_107, toDisplayString(formatPerShare(row.ocfPerShareLast)), 1)]),
								createElementVNode("div", null, [createElementVNode("dt", _hoisted_108, toDisplayString(unref(DIVIDEND_DETAIL_LABEL).cashCoverLast), 1), createElementVNode("dd", _hoisted_109, toDisplayString(formatCover(row.cashCoverLast)), 1)]),
								createElementVNode("div", null, [createElementVNode("dt", _hoisted_110, toDisplayString(unref(DIVIDEND_DETAIL_LABEL).debtRatio), 1), createElementVNode("dd", _hoisted_111, toDisplayString(formatDebtRatio(row.debtRatio)), 1)]),
								createElementVNode("div", null, [createElementVNode("dt", _hoisted_112, toDisplayString(unref(DIVIDEND_DETAIL_LABEL).netProfitH1), 1), createElementVNode("dd", _hoisted_113, toDisplayString(formatYuanToYi(row.netProfitH1)), 1)]),
								createElementVNode("div", null, [createElementVNode("dt", _hoisted_114, toDisplayString(unref(DIVIDEND_DETAIL_LABEL).netProfitH1Last), 1), createElementVNode("dd", _hoisted_115, toDisplayString(formatYuanToYi(row.netProfitH1Last)), 1)]),
								createElementVNode("div", null, [createElementVNode("dt", _hoisted_116, toDisplayString(unref(DIVIDEND_DETAIL_LABEL).growthH1), 1), createElementVNode("dd", _hoisted_117, toDisplayString(formatGrowth(row.growthH1)), 1)]),
								createElementVNode("div", null, [createElementVNode("dt", _hoisted_118, toDisplayString(unref(DIVIDEND_DETAIL_LABEL).projectedNetProfit), 1), createElementVNode("dd", _hoisted_119, toDisplayString(formatYuanToYi(row.projectedNetProfit)), 1)]),
								createElementVNode("div", null, [createElementVNode("dt", _hoisted_120, toDisplayString(unref(DIVIDEND_DETAIL_LABEL).projectedDps), 1), createElementVNode("dd", _hoisted_121, toDisplayString(formatDps(row.projectedDps)), 1)]),
								createElementVNode("div", null, [createElementVNode("dt", _hoisted_122, toDisplayString(unref(DIVIDEND_DETAIL_LABEL).projectedYield), 1), createElementVNode("dd", _hoisted_123, toDisplayString(formatYield(row.projectedYield)), 1)]),
								createElementVNode("div", null, [createElementVNode("dt", _hoisted_124, toDisplayString(unref(DIVIDEND_DETAIL_LABEL).interimDps), 1), createElementVNode("dd", _hoisted_125, toDisplayString(formatDps(row.interimDps)), 1)]),
								createElementVNode("div", null, [createElementVNode("dt", _hoisted_126, toDisplayString(unref(DIVIDEND_DETAIL_LABEL).ttmYield), 1), createElementVNode("dd", _hoisted_127, toDisplayString(formatYield(row.ttmYield)), 1)]),
								createElementVNode("div", null, [createElementVNode("dt", _hoisted_128, toDisplayString(unref(DIVIDEND_DETAIL_LABEL).marketCap), 1), createElementVNode("dd", _hoisted_129, toDisplayString(formatYuanToYi(row.marketCap)), 1)]),
								createElementVNode("div", null, [createElementVNode("dt", _hoisted_130, toDisplayString(unref(DIVIDEND_DETAIL_LABEL).peTtm), 1), createElementVNode("dd", _hoisted_131, toDisplayString(row.peTtm === null ? unref("—") : row.peTtm.toFixed(1)), 1)]),
								createElementVNode("div", null, [createElementVNode("dt", _hoisted_132, toDisplayString(unref(DIVIDEND_DETAIL_LABEL).pb), 1), createElementVNode("dd", _hoisted_133, toDisplayString(row.pb === null ? unref("—") : row.pb.toFixed(2)), 1)])
							])
						])]),
						_: 1
					}, 40, [
						"columns",
						"rows",
						"expanded-keys",
						"min-width"
					]))]),
					_: 1
				}, 8, ["title"])),
				(openBlock(), createBlock(resolveDynamicComponent(__props.deps.ui.Card), null, {
					default: withCtx(() => [createElementVNode("p", _hoisted_134, toDisplayString(unref(DIVIDEND_DISCLAIMER)), 1)]),
					_: 1
				}))
			]);
		};
	}
});
//#endregion
//#region plugins/dsh-dividend-screen/storage.ts
/**
* 插件 dsh-dividend-screen（股息筛选）· 本地快照仓储
*
* 四张表（插件独立表，物理名 `plugin_dsh_dividend_screen_*`；Tauri 端 SQLite /
* 浏览器端 JSON 表仿真）：
* - `screen_rows`：一次扫描一只股票一行，**全部展示指标已在扫描时算好**——
*   读库即可渲染整页，重进页面零联网（用户明确要求：持久化缓存，避免重复查询触发上游限速）；
* - `scan_meta`：键值行，存扫描元信息（报告期 / 覆盖 / 告警）；
* - `config`：键值行，存用户自定义规则配置（`rules.ts` 清洗后回填，坏配置自动修复）；
* - `watchlist`：股息自选（代码 + 加入时的名称），整表全量替换（条目少，写放大可忽略）。
*
* 快照语义：`saveScan` 全量替换（clear + insert，行数 ≤ 样本池上限 500，
* 远低于逐行 upsert 的写放大）；旧快照只有「被新扫描覆盖」一种失效方式。
*
* ⚠️ 列声明只写业务列：`id` / `created_at` / `updated_at` 由宿主自动维护，
* 插件重复声明会让建表语句出现同名列（SQLite 报 duplicate column name）。
*/
/** 展示行表名（物理表 `plugin_dsh_dividend_screen_screen_rows`） */
var DIVIDEND_ROWS_TABLE = "screen_rows";
/** 扫描元信息表名（物理表 `plugin_dsh_dividend_screen_scan_meta`） */
var DIVIDEND_META_TABLE = "scan_meta";
/** 规则配置表名（物理表 `plugin_dsh_dividend_screen_config`） */
var DIVIDEND_CONFIG_TABLE = "config";
/** 股息自选表名（物理表 `plugin_dsh_dividend_screen_watchlist`） */
var DIVIDEND_WATCH_TABLE = "watchlist";
/** 扫描元信息在表里的键 */
var DIVIDEND_META_KEY = "last_scan";
/** 展示行表的列声明（snake_case；数值列 real，文本列 text，代码列建索引） */
var DIVIDEND_ROWS_COLUMNS = [
	{
		name: "code",
		type: "text",
		indexed: true
	},
	{
		name: "name",
		type: "text"
	},
	{
		name: "industry",
		type: "text"
	},
	{
		name: "price",
		type: "real"
	},
	{
		name: "change_percent",
		type: "real"
	},
	{
		name: "market_cap",
		type: "real"
	},
	{
		name: "pb",
		type: "real"
	},
	{
		name: "pe_ttm",
		type: "real"
	},
	{
		name: "total_shares",
		type: "real"
	},
	{
		name: "ttm_yield",
		type: "real"
	},
	{
		name: "dps_last",
		type: "real"
	},
	{
		name: "dividend_total_last",
		type: "real"
	},
	{
		name: "np_fy_last",
		type: "real"
	},
	{
		name: "payout_last",
		type: "real"
	},
	{
		name: "np_h1",
		type: "real"
	},
	{
		name: "np_h1_last",
		type: "real"
	},
	{
		name: "np_yoy",
		type: "real"
	},
	{
		name: "rev_yoy",
		type: "real"
	},
	{
		name: "growth_h1",
		type: "real"
	},
	{
		name: "np_proj",
		type: "real"
	},
	{
		name: "dps_proj",
		type: "real"
	},
	{
		name: "yield_proj",
		type: "real"
	},
	{
		name: "yield_last",
		type: "real"
	},
	{
		name: "interim_dps",
		type: "real"
	},
	{
		name: "dividend_years",
		type: "real"
	},
	{
		name: "ocf_per_share_last",
		type: "real"
	},
	{
		name: "cash_cover_last",
		type: "real"
	},
	{
		name: "debt_ratio",
		type: "real"
	},
	{
		name: "status",
		type: "text"
	}
];
/** 元信息表的列声明（键值行） */
var DIVIDEND_META_COLUMNS = [{
	name: "meta_key",
	type: "text",
	indexed: true
}, {
	name: "meta_value",
	type: "json"
}];
/** 规则配置表的列声明（键值行；value 存 `RuleConfig[]` 的 JSON） */
var DIVIDEND_CONFIG_COLUMNS = [{
	name: "config_key",
	type: "text",
	indexed: true
}, {
	name: "config_value",
	type: "json"
}];
/** 股息自选表的列声明（code 建索引；name 存加入时的名称，快照缺席时兜底展示） */
var DIVIDEND_WATCH_COLUMNS = [{
	name: "code",
	type: "text",
	indexed: true
}, {
	name: "name",
	type: "text"
}];
/**
* 把库里读出的行还原成展示行（脏数据兜底：数值列非数一律 null，状态列非法回退到未披露）
* @param row 库里的一行
* @returns 展示行
*/
var hydrateRow = (row) => {
	const num = (key) => {
		const value = row[key];
		return typeof value === "number" && Number.isFinite(value) ? value : null;
	};
	const text = (key) => typeof row[key] === "string" ? row[key] : "";
	const dpsLast = num("dps_last");
	return {
		code: text("code"),
		name: text("name"),
		industry: text("industry"),
		price: num("price"),
		changePercent: num("change_percent"),
		marketCap: num("market_cap"),
		pb: num("pb"),
		peTtm: num("pe_ttm"),
		totalShares: num("total_shares"),
		ttmYield: num("ttm_yield"),
		dpsLast: dpsLast ?? 0,
		dividendTotalLast: num("dividend_total_last"),
		netProfitFyLast: num("np_fy_last"),
		payoutLast: num("payout_last"),
		netProfitH1: num("np_h1"),
		netProfitH1Last: num("np_h1_last"),
		netProfitYoY: num("np_yoy"),
		revenueYoY: num("rev_yoy"),
		growthH1: num("growth_h1"),
		projectedNetProfit: num("np_proj"),
		projectedDps: num("dps_proj"),
		projectedYield: num("yield_proj"),
		yieldLast: num("yield_last"),
		interimDps: num("interim_dps"),
		dividendYears: num("dividend_years"),
		ocfPerShareLast: num("ocf_per_share_last"),
		cashCoverLast: num("cash_cover_last"),
		debtRatio: num("debt_ratio"),
		status: toStatus(text("status"))
	};
};
/**
* 库里的状态列还原成推算状态（非法值兜底回「中报未披露」）
* @param value 状态列文本
* @returns 推算状态
*/
var toStatus = (value) => {
	return Object.values(DIVIDEND_PROJECT_STATUS).includes(value) ? value : DIVIDEND_PROJECT_STATUS.NO_REPORT;
};
/**
* 建表并水合快照
* @param db 插件通用数据库（`ctx.db`）
* @returns 股息筛选仓储
*/
var createDividendRepo = async (db) => {
	await db.ensureTable(DIVIDEND_ROWS_TABLE, DIVIDEND_ROWS_COLUMNS);
	await db.ensureTable(DIVIDEND_META_TABLE, DIVIDEND_META_COLUMNS);
	await db.ensureTable(DIVIDEND_CONFIG_TABLE, DIVIDEND_CONFIG_COLUMNS);
	await db.ensureTable(DIVIDEND_WATCH_TABLE, DIVIDEND_WATCH_COLUMNS);
	const rows = ref([]);
	const meta = ref(null);
	const ruleConfigs = ref(createDefaultRules());
	const watchItems = ref([]);
	rows.value = (await db.select(DIVIDEND_ROWS_TABLE, { orderBy: { column: "id" } })).map(hydrateRow);
	const metaValue = (await db.select(DIVIDEND_META_TABLE, { where: { meta_key: DIVIDEND_META_KEY } }))[0]?.meta_value;
	if (metaValue && typeof metaValue === "object") meta.value = metaValue;
	const sanitized = sanitizeRuleConfigs((await db.select(DIVIDEND_CONFIG_TABLE, { where: { config_key: DIVIDEND_CONFIG_KEY } }))[0]?.config_value);
	if (sanitized) ruleConfigs.value = sanitized;
	/**
	* 行对象 → 落库行（saveScan 用；字段清单与列声明一一对应）
	* @param row 展示行
	* @returns 落库行
	*/
	const toRowRecord = (row) => ({
		code: row.code,
		name: row.name,
		industry: row.industry,
		price: row.price,
		change_percent: row.changePercent,
		market_cap: row.marketCap,
		pb: row.pb,
		pe_ttm: row.peTtm,
		total_shares: row.totalShares,
		ttm_yield: row.ttmYield,
		dps_last: row.dpsLast,
		dividend_total_last: row.dividendTotalLast,
		np_fy_last: row.netProfitFyLast,
		payout_last: row.payoutLast,
		np_h1: row.netProfitH1,
		np_h1_last: row.netProfitH1Last,
		np_yoy: row.netProfitYoY,
		rev_yoy: row.revenueYoY,
		growth_h1: row.growthH1,
		np_proj: row.projectedNetProfit,
		dps_proj: row.projectedDps,
		yield_proj: row.projectedYield,
		yield_last: row.yieldLast,
		interim_dps: row.interimDps,
		dividend_years: row.dividendYears,
		ocf_per_share_last: row.ocfPerShareLast,
		cash_cover_last: row.cashCoverLast,
		debt_ratio: row.debtRatio,
		status: row.status
	});
	/**
	* 全量重写自选表（add / remove 的共同实现；条目少，clear + insert 写放大可忽略）
	* @param items 新自选清单
	*/
	const rewriteWatch = async (items) => {
		await db.clear(DIVIDEND_WATCH_TABLE);
		for (const item of items) await db.insert(DIVIDEND_WATCH_TABLE, {
			code: item.code,
			name: item.name
		});
		watchItems.value = [...items];
	};
	return {
		snapshot: () => ({
			rows: rows.value,
			meta: meta.value
		}),
		ruleConfig: () => ruleConfigs.value,
		watchlist: () => watchItems.value,
		addWatch: async (incoming) => {
			const known = new Set(watchItems.value.map((item) => item.code));
			const additions = incoming.filter((item) => item.code !== "" && !known.has(item.code));
			if (additions.length === 0) return;
			await rewriteWatch([...watchItems.value, ...additions]);
		},
		removeWatch: async (codes) => {
			const dropped = new Set(codes);
			const remaining = watchItems.value.filter((item) => !dropped.has(item.code));
			if (remaining.length === watchItems.value.length) return;
			await rewriteWatch(remaining);
		},
		saveRuleConfig: async (configs) => {
			await db.clear(DIVIDEND_CONFIG_TABLE);
			await db.insert(DIVIDEND_CONFIG_TABLE, {
				config_key: DIVIDEND_CONFIG_KEY,
				config_value: [...configs]
			});
			ruleConfigs.value = sanitizeRuleConfigs([...configs]) ?? createDefaultRules();
		},
		saveScan: async (nextRows, nextMeta) => {
			await db.clear(DIVIDEND_ROWS_TABLE);
			for (const row of nextRows) await db.insert(DIVIDEND_ROWS_TABLE, toRowRecord(row));
			await db.clear(DIVIDEND_META_TABLE);
			await db.insert(DIVIDEND_META_TABLE, {
				meta_key: DIVIDEND_META_KEY,
				meta_value: nextMeta
			});
			rows.value = [...nextRows];
			meta.value = nextMeta;
		}
	};
};
//#endregion
//#region plugins/dsh-dividend-screen/plugin.ts
/**
* 插件 dsh-dividend-screen（股息筛选）
*
* 左侧导航新增「股息筛选」页面：市面股息排行的 TTM 口径只反映「过去派了多少」，
* 本插件在同一张表上叠加**今年推算**——以今年中报 ÷ 去年中报的净利比作全年增长系数、
* 保留去年分红率，推算「维持分红习惯下的今年股息率」。
*
* 数据落地：`ctx.db` 两张插件表（`screen_rows` / `scan_meta`），
* 扫描一次后重进页面只读库渲染、零联网（避免重复查询触发上游限速）；
* 重接口只在用户点击「扫描排行」时触发。
*/
/**
* 股息筛选插件定义
*/
var dividendScreenPlugin = {
	id: DIVIDEND_PLUGIN_ID,
	name: "股息筛选",
	version: "1.0.0",
	description: "左侧导航新增「股息筛选」看板：TTM 股息率排行（东财口径）+ 保留去年分红率、按中报净利增速推算今年股息率；结果落本地插件库，重进页面不联网。",
	author: "内置",
	settings: {
		title: "表格列配置",
		description: "控制结果表格显示哪些列、按什么顺序显示；改动对两个 tab 即时生效。",
		component: DividendColumnSettings_default
	},
	apply: async (ctx) => {
		const http = ctx.consume("app:http");
		const format = ctx.consume("app:format");
		const ui = ctx.consume("app:ui");
		const stockOpen = ctx.consume("app:stock-open");
		if (!http || !format || !ui || !stockOpen) throw new Error("宿主未提供 app:http / app:format / app:ui / app:stock-open 服务");
		const deps = {
			http,
			format,
			ui,
			stockOpen
		};
		const repo = await createDividendRepo(ctx.db);
		ctx.provide("dividend:repo", repo);
		const stockSearch = ctx.consume("app:stock-search");
		ctx.menu.add({
			path: DIVIDEND_MENU_PATH,
			title: DIVIDEND_MENU_TITLE,
			icon: DIVIDEND_MENU_ICON,
			component: DividendScreenView_default,
			props: {
				repo,
				stockSearch,
				settings: ctx.settings,
				deps
			}
		});
		ctx.logger.info("已注册「股息筛选」导航项与看板页面");
	}
};
//#endregion
export { dividendScreenPlugin as default, dividendScreenPlugin };
