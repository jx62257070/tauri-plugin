const __WHF_PLUGIN_RUNTIME__ = globalThis.__WHF_PLUGIN_RUNTIME__;
if (!__WHF_PLUGIN_RUNTIME__?.vue) {
  throw new Error('宿主运行时桥不可用：__WHF_PLUGIN_RUNTIME__（插件必须在该版本宿主里安装）');
}
const { computed, watch } = __WHF_PLUGIN_RUNTIME__.vue;
//#region node_modules/@tauri-apps/api/external/tslib/tslib.es6.js
/******************************************************************************
Copyright (c) Microsoft Corporation.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.
***************************************************************************** */
function __classPrivateFieldGet(receiver, state, kind, f) {
	if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a getter");
	if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
	return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
}
function __classPrivateFieldSet(receiver, state, value, kind, f) {
	if (kind === "m") throw new TypeError("Private method is not writable");
	if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a setter");
	if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
	return kind === "a" ? f.call(receiver, value) : f ? f.value = value : state.set(receiver, value), value;
}
var _Resource_rid;
/**
* Invoke your custom commands.
*
* This package is also accessible with `window.__TAURI__.core` when [`app.withGlobalTauri`](https://v2.tauri.app/reference/config/#withglobaltauri) in `tauri.conf.json` is set to `true`.
* @module
*/
/**
* A key to be used to implement a special function
* on your types that define how your type should be serialized
* when passing across the IPC.
* @example
* Given a type in Rust that looks like this
* ```rs
* #[derive(serde::Serialize, serde::Deserialize)
* enum UserId {
*   String(String),
*   Number(u32),
* }
* ```
* `UserId::String("id")` would be serialized into `{ String: "id" }`
* and so we need to pass the same structure back to Rust
* ```ts
* import { SERIALIZE_TO_IPC_FN } from "@tauri-apps/api/core"
*
* class UserIdString {
*   id
*   constructor(id) {
*     this.id = id
*   }
*
*   [SERIALIZE_TO_IPC_FN]() {
*     return { String: this.id }
*   }
* }
*
* class UserIdNumber {
*   id
*   constructor(id) {
*     this.id = id
*   }
*
*   [SERIALIZE_TO_IPC_FN]() {
*     return { Number: this.id }
*   }
* }
*
* type UserId = UserIdString | UserIdNumber
* ```
*
*/
var SERIALIZE_TO_IPC_FN = "__TAURI_TO_IPC_KEY__";
/**
* Stores the callback in a known location, and returns an identifier that can be passed to the backend.
* The backend uses the identifier to `eval()` the callback.
*
* @return An unique identifier associated with the callback function.
*
* @since 1.0.0
*/
function transformCallback(callback, once = false) {
	return window.__TAURI_INTERNALS__.transformCallback(callback, once);
}
/**
* Sends a message to the backend.
* @example
* ```typescript
* import { invoke } from '@tauri-apps/api/core';
* await invoke('login', { user: 'tauri', password: 'poiwe3h4r5ip3yrhtew9ty' });
* ```
*
* @param cmd The command name.
* @param args The optional arguments to pass to the command.
* @param options The request options.
* @return A promise resolving or rejecting to the backend response.
*
* @since 1.0.0
*/
async function invoke(cmd, args = {}, options) {
	return window.__TAURI_INTERNALS__.invoke(cmd, args, options);
}
/**
* A rust-backed resource stored through `tauri::Manager::resources_table` API.
*
* The resource lives in the main process and does not exist
* in the Javascript world, and thus will not be cleaned up automatically
* except on application exit. If you want to clean it up early, call {@linkcode Resource.close}
*
* @example
* ```typescript
* import { Resource, invoke } from '@tauri-apps/api/core';
* export class DatabaseHandle extends Resource {
*   static async open(path: string): Promise<DatabaseHandle> {
*     const rid: number = await invoke('open_db', { path });
*     return new DatabaseHandle(rid);
*   }
*
*   async execute(sql: string): Promise<void> {
*     await invoke('execute_sql', { rid: this.rid, sql });
*   }
* }
* ```
*/
var Resource = class {
	get rid() {
		return __classPrivateFieldGet(this, _Resource_rid, "f");
	}
	constructor(rid) {
		_Resource_rid.set(this, void 0);
		__classPrivateFieldSet(this, _Resource_rid, rid, "f");
	}
	/**
	* Destroys and cleans up this resource from memory.
	* **You should not call any method on this object anymore and should drop any reference to it.**
	*/
	async close() {
		return invoke("plugin:resources|close", { rid: this.rid });
	}
};
_Resource_rid = /* @__PURE__ */ new WeakMap();
function isTauri() {
	return !!(globalThis || window).isTauri;
}
//#endregion
//#region node_modules/@tauri-apps/api/event.js
/**
* The event system allows you to emit events to the backend and listen to events from it.
*
* This package is also accessible with `window.__TAURI__.event` when [`app.withGlobalTauri`](https://v2.tauri.app/reference/config/#withglobaltauri) in `tauri.conf.json` is set to `true`.
* @module
*/
/**
* @since 1.1.0
*/
var TauriEvent;
(function(TauriEvent) {
	TauriEvent["WINDOW_RESIZED"] = "tauri://resize";
	TauriEvent["WINDOW_MOVED"] = "tauri://move";
	TauriEvent["WINDOW_CLOSE_REQUESTED"] = "tauri://close-requested";
	TauriEvent["WINDOW_DESTROYED"] = "tauri://destroyed";
	TauriEvent["WINDOW_FOCUS"] = "tauri://focus";
	TauriEvent["WINDOW_BLUR"] = "tauri://blur";
	TauriEvent["WINDOW_SCALE_FACTOR_CHANGED"] = "tauri://scale-change";
	TauriEvent["WINDOW_THEME_CHANGED"] = "tauri://theme-changed";
	TauriEvent["WINDOW_CREATED"] = "tauri://window-created";
	TauriEvent["WINDOW_SUSPENDED"] = "tauri://suspended";
	TauriEvent["WINDOW_RESUMED"] = "tauri://resumed";
	TauriEvent["WEBVIEW_CREATED"] = "tauri://webview-created";
	TauriEvent["DRAG_ENTER"] = "tauri://drag-enter";
	TauriEvent["DRAG_OVER"] = "tauri://drag-over";
	TauriEvent["DRAG_DROP"] = "tauri://drag-drop";
	TauriEvent["DRAG_LEAVE"] = "tauri://drag-leave";
})(TauriEvent || (TauriEvent = {}));
/**
* Unregister the event listener associated with the given name and id.
*
* @ignore
* @param event The event name
* @param eventId Event identifier
* @returns
*/
async function _unlisten(event, eventId) {
	window.__TAURI_EVENT_PLUGIN_INTERNALS__.unregisterListener(event, eventId);
	await invoke("plugin:event|unlisten", {
		event,
		eventId
	});
}
/**
* Listen to an emitted event to any {@link EventTarget|target}.
*
* @example
* ```typescript
* import { listen } from '@tauri-apps/api/event';
* const unlisten = await listen<string>('error', (event) => {
*   console.log(`Got error, payload: ${event.payload}`);
* });
*
* // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
* unlisten();
* ```
*
* @param event Event name. Must include only alphanumeric characters, `-`, `/`, `:` and `_`.
* @param handler Event handler callback.
* @param options Event listening options.
* @returns A promise resolving to a function to unlisten to the event.
* Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
*
* @since 1.0.0
*/
async function listen(event, handler, options) {
	var _a;
	return invoke("plugin:event|listen", {
		event,
		target: typeof (options === null || options === void 0 ? void 0 : options.target) === "string" ? {
			kind: "AnyLabel",
			label: options.target
		} : (_a = options === null || options === void 0 ? void 0 : options.target) !== null && _a !== void 0 ? _a : { kind: "Any" },
		handler: transformCallback(handler)
	}).then((eventId) => {
		return async () => _unlisten(event, eventId);
	});
}
/**
* Listens once to an emitted event to any {@link EventTarget|target}.
*
* @example
* ```typescript
* import { once } from '@tauri-apps/api/event';
* interface LoadedPayload {
*   loggedIn: boolean,
*   token: string
* }
* const unlisten = await once<LoadedPayload>('loaded', (event) => {
*   console.log(`App is loaded, loggedIn: ${event.payload.loggedIn}, token: ${event.payload.token}`);
* });
*
* // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
* unlisten();
* ```
*
* @param event Event name. Must include only alphanumeric characters, `-`, `/`, `:` and `_`.
* @param handler Event handler callback.
* @param options Event listening options.
* @returns A promise resolving to a function to unlisten to the event.
* Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
*
* @since 1.0.0
*/
async function once(event, handler, options) {
	return listen(event, (eventData) => {
		_unlisten(event, eventData.id);
		handler(eventData);
	}, options);
}
/**
* Emits an event to all {@link EventTarget|targets}.
*
* @example
* ```typescript
* import { emit } from '@tauri-apps/api/event';
* await emit('frontend-loaded', { loggedIn: true, token: 'authToken' });
* ```
*
* @param event Event name. Must include only alphanumeric characters, `-`, `/`, `:` and `_`.
* @param payload Event payload.
*
* @since 1.0.0
*/
async function emit(event, payload) {
	await invoke("plugin:event|emit", {
		event,
		payload
	});
}
/**
* Emits an event to all {@link EventTarget|targets} matching the given target.
*
* @example
* ```typescript
* import { emitTo } from '@tauri-apps/api/event';
* await emitTo('main', 'frontend-loaded', { loggedIn: true, token: 'authToken' });
* ```
*
* @param target Label of the target Window/Webview/WebviewWindow or raw {@link EventTarget} object.
* @param event Event name. Must include only alphanumeric characters, `-`, `/`, `:` and `_`.
* @param payload Event payload.
*
* @since 2.0.0
*/
async function emitTo(target, event, payload) {
	await invoke("plugin:event|emit_to", {
		target: typeof target === "string" ? {
			kind: "AnyLabel",
			label: target
		} : target,
		event,
		payload
	});
}
//#endregion
//#region node_modules/@tauri-apps/api/dpi.js
/**
* A size represented in logical pixels.
* Logical pixels are scaled according to the window's DPI scale.
* Most browser APIs (i.e. `MouseEvent`'s `clientX`) will return logical pixels.
*
* For logical-pixel-based position, see {@linkcode LogicalPosition}.
*
* @since 2.0.0
*/
var LogicalSize = class {
	constructor(...args) {
		this.type = "Logical";
		if (args.length === 1) {
			if ("Logical" in args[0]) {
				this.width = args[0].Logical.width;
				this.height = args[0].Logical.height;
			} else {
				this.width = args[0].width;
				this.height = args[0].height;
			}
		} else {
			this.width = args[0];
			this.height = args[1];
		}
	}
	/**
	* Converts the logical size to a physical one.
	* @example
	* ```typescript
	* import { LogicalSize } from '@tauri-apps/api/dpi';
	* import { getCurrentWindow } from '@tauri-apps/api/window';
	*
	* const appWindow = getCurrentWindow();
	* const factor = await appWindow.scaleFactor();
	* const size = new LogicalSize(400, 500);
	* const physical = size.toPhysical(factor);
	* ```
	*
	* @since 2.0.0
	*/
	toPhysical(scaleFactor) {
		return new PhysicalSize(this.width * scaleFactor, this.height * scaleFactor);
	}
	[SERIALIZE_TO_IPC_FN]() {
		return {
			width: this.width,
			height: this.height
		};
	}
	toJSON() {
		return this[SERIALIZE_TO_IPC_FN]();
	}
};
/**
* A size represented in physical pixels.
*
* Physical pixels represent actual screen pixels, and are DPI-independent.
* For high-DPI windows, this means that any point in the window on the screen
* will have a different position in logical pixels {@linkcode LogicalSize}.
*
* For physical-pixel-based position, see {@linkcode PhysicalPosition}.
*
* @since 2.0.0
*/
var PhysicalSize = class {
	constructor(...args) {
		this.type = "Physical";
		if (args.length === 1) {
			if ("Physical" in args[0]) {
				this.width = args[0].Physical.width;
				this.height = args[0].Physical.height;
			} else {
				this.width = args[0].width;
				this.height = args[0].height;
			}
		} else {
			this.width = args[0];
			this.height = args[1];
		}
	}
	/**
	* Converts the physical size to a logical one.
	* @example
	* ```typescript
	* import { getCurrentWindow } from '@tauri-apps/api/window';
	* const appWindow = getCurrentWindow();
	* const factor = await appWindow.scaleFactor();
	* const size = await appWindow.innerSize(); // PhysicalSize
	* const logical = size.toLogical(factor);
	* ```
	*/
	toLogical(scaleFactor) {
		return new LogicalSize(this.width / scaleFactor, this.height / scaleFactor);
	}
	[SERIALIZE_TO_IPC_FN]() {
		return {
			width: this.width,
			height: this.height
		};
	}
	toJSON() {
		return this[SERIALIZE_TO_IPC_FN]();
	}
};
/**
* A size represented either in physical or in logical pixels.
*
* This type is basically a union type of {@linkcode LogicalSize} and {@linkcode PhysicalSize}
* but comes in handy when using `tauri::Size` in Rust as an argument to a command, as this class
* automatically serializes into a valid format so it can be deserialized correctly into `tauri::Size`
*
* So instead of
* ```typescript
* import { invoke } from '@tauri-apps/api/core';
* import { LogicalSize, PhysicalSize } from '@tauri-apps/api/dpi';
*
* const size: LogicalSize | PhysicalSize = someFunction(); // where someFunction returns either LogicalSize or PhysicalSize
* const validSize = size instanceof LogicalSize
*   ? { Logical: { width: size.width, height: size.height } }
*   : { Physical: { width: size.width, height: size.height } }
* await invoke("do_something_with_size", { size: validSize });
* ```
*
* You can just use {@linkcode Size}
* ```typescript
* import { invoke } from '@tauri-apps/api/core';
* import { LogicalSize, PhysicalSize, Size } from '@tauri-apps/api/dpi';
*
* const size: LogicalSize | PhysicalSize = someFunction(); // where someFunction returns either LogicalSize or PhysicalSize
* const validSize = new Size(size);
* await invoke("do_something_with_size", { size: validSize });
* ```
*
* @since 2.1.0
*/
var Size = class {
	constructor(size) {
		this.size = size;
	}
	toLogical(scaleFactor) {
		return this.size instanceof LogicalSize ? this.size : this.size.toLogical(scaleFactor);
	}
	toPhysical(scaleFactor) {
		return this.size instanceof PhysicalSize ? this.size : this.size.toPhysical(scaleFactor);
	}
	[SERIALIZE_TO_IPC_FN]() {
		return { [`${this.size.type}`]: {
			width: this.size.width,
			height: this.size.height
		} };
	}
	toJSON() {
		return this[SERIALIZE_TO_IPC_FN]();
	}
};
/**
* A position represented in logical pixels.
* For an explanation of what logical pixels are, see description of {@linkcode LogicalSize}.
*
* @since 2.0.0
*/
var LogicalPosition = class {
	constructor(...args) {
		this.type = "Logical";
		if (args.length === 1) {
			if ("Logical" in args[0]) {
				this.x = args[0].Logical.x;
				this.y = args[0].Logical.y;
			} else {
				this.x = args[0].x;
				this.y = args[0].y;
			}
		} else {
			this.x = args[0];
			this.y = args[1];
		}
	}
	/**
	* Converts the logical position to a physical one.
	* @example
	* ```typescript
	* import { LogicalPosition } from '@tauri-apps/api/dpi';
	* import { getCurrentWindow } from '@tauri-apps/api/window';
	*
	* const appWindow = getCurrentWindow();
	* const factor = await appWindow.scaleFactor();
	* const position = new LogicalPosition(400, 500);
	* const physical = position.toPhysical(factor);
	* ```
	*
	* @since 2.0.0
	*/
	toPhysical(scaleFactor) {
		return new PhysicalPosition(this.x * scaleFactor, this.y * scaleFactor);
	}
	[SERIALIZE_TO_IPC_FN]() {
		return {
			x: this.x,
			y: this.y
		};
	}
	toJSON() {
		return this[SERIALIZE_TO_IPC_FN]();
	}
};
/**
* A position represented in physical pixels.
*
* For an explanation of what physical pixels are, see description of {@linkcode PhysicalSize}.
*
* @since 2.0.0
*/
var PhysicalPosition = class {
	constructor(...args) {
		this.type = "Physical";
		if (args.length === 1) {
			if ("Physical" in args[0]) {
				this.x = args[0].Physical.x;
				this.y = args[0].Physical.y;
			} else {
				this.x = args[0].x;
				this.y = args[0].y;
			}
		} else {
			this.x = args[0];
			this.y = args[1];
		}
	}
	/**
	* Converts the physical position to a logical one.
	* @example
	* ```typescript
	* import { PhysicalPosition } from '@tauri-apps/api/dpi';
	* import { getCurrentWindow } from '@tauri-apps/api/window';
	*
	* const appWindow = getCurrentWindow();
	* const factor = await appWindow.scaleFactor();
	* const position = new PhysicalPosition(400, 500);
	* const physical = position.toLogical(factor);
	* ```
	*
	* @since 2.0.0
	*/
	toLogical(scaleFactor) {
		return new LogicalPosition(this.x / scaleFactor, this.y / scaleFactor);
	}
	[SERIALIZE_TO_IPC_FN]() {
		return {
			x: this.x,
			y: this.y
		};
	}
	toJSON() {
		return this[SERIALIZE_TO_IPC_FN]();
	}
};
/**
* A position represented either in physical or in logical pixels.
*
* This type is basically a union type of {@linkcode LogicalSize} and {@linkcode PhysicalSize}
* but comes in handy when using `tauri::Position` in Rust as an argument to a command, as this class
* automatically serializes into a valid format so it can be deserialized correctly into `tauri::Position`
*
* So instead of
* ```typescript
* import { invoke } from '@tauri-apps/api/core';
* import { LogicalPosition, PhysicalPosition } from '@tauri-apps/api/dpi';
*
* const position: LogicalPosition | PhysicalPosition = someFunction(); // where someFunction returns either LogicalPosition or PhysicalPosition
* const validPosition = position instanceof LogicalPosition
*   ? { Logical: { x: position.x, y: position.y } }
*   : { Physical: { x: position.x, y: position.y } }
* await invoke("do_something_with_position", { position: validPosition });
* ```
*
* You can just use {@linkcode Position}
* ```typescript
* import { invoke } from '@tauri-apps/api/core';
* import { LogicalPosition, PhysicalPosition, Position } from '@tauri-apps/api/dpi';
*
* const position: LogicalPosition | PhysicalPosition = someFunction(); // where someFunction returns either LogicalPosition or PhysicalPosition
* const validPosition = new Position(position);
* await invoke("do_something_with_position", { position: validPosition });
* ```
*
* @since 2.1.0
*/
var Position = class {
	constructor(position) {
		this.position = position;
	}
	toLogical(scaleFactor) {
		return this.position instanceof LogicalPosition ? this.position : this.position.toLogical(scaleFactor);
	}
	toPhysical(scaleFactor) {
		return this.position instanceof PhysicalPosition ? this.position : this.position.toPhysical(scaleFactor);
	}
	[SERIALIZE_TO_IPC_FN]() {
		return { [`${this.position.type}`]: {
			x: this.position.x,
			y: this.position.y
		} };
	}
	toJSON() {
		return this[SERIALIZE_TO_IPC_FN]();
	}
};
//#endregion
//#region node_modules/@tauri-apps/api/image.js
/** An RGBA Image in row-major order from top to bottom. */
var Image = class Image extends Resource {
	/**
	* Creates an Image from a resource ID. For internal use only.
	*
	* @ignore
	*/
	constructor(rid) {
		super(rid);
	}
	/** Creates a new Image using RGBA data, in row-major order from top to bottom, and with specified width and height. */
	static async new(rgba, width, height) {
		return invoke("plugin:image|new", {
			rgba: transformImage(rgba),
			width,
			height
		}).then((rid) => new Image(rid));
	}
	/**
	* Creates a new image using the provided bytes by inferring the file format.
	* If the format is known, prefer [@link Image.fromPngBytes] or [@link Image.fromIcoBytes].
	*
	* Only `ico` and `png` are supported (based on activated feature flag).
	*
	* Note that you need the `image-ico` or `image-png` Cargo features to use this API.
	* To enable it, change your Cargo.toml file:
	* ```toml
	* [dependencies]
	* tauri = { version = "...", features = ["...", "image-png"] }
	* ```
	*/
	static async fromBytes(bytes) {
		return invoke("plugin:image|from_bytes", { bytes: transformImage(bytes) }).then((rid) => new Image(rid));
	}
	/**
	* Creates a new image using the provided path.
	*
	* Only `ico` and `png` are supported (based on activated feature flag).
	*
	* Note that you need the `image-ico` or `image-png` Cargo features to use this API.
	* To enable it, change your Cargo.toml file:
	* ```toml
	* [dependencies]
	* tauri = { version = "...", features = ["...", "image-png"] }
	* ```
	*/
	static async fromPath(path) {
		return invoke("plugin:image|from_path", { path }).then((rid) => new Image(rid));
	}
	/** Returns the RGBA data for this image, in row-major order from top to bottom.  */
	async rgba() {
		return invoke("plugin:image|rgba", { rid: this.rid }).then((buffer) => new Uint8Array(buffer));
	}
	/** Returns the size of this image.  */
	async size() {
		return invoke("plugin:image|size", { rid: this.rid });
	}
};
/**
* Transforms image from various types into a type acceptable by Rust.
*
* See [tauri::image::JsImage](https://docs.rs/tauri/2/tauri/image/enum.JsImage.html) for more information.
* Note the API signature is not stable and might change.
*/
function transformImage(image) {
	return image == null ? null : typeof image === "string" ? image : image instanceof Image ? image.rid : image;
}
//#endregion
//#region node_modules/@tauri-apps/api/window.js
/**
* Provides APIs to create windows, communicate with other windows and manipulate the current window.
*
* #### Window events
*
* Events can be listened to using {@link Window.listen}:
* ```typescript
* import { getCurrentWindow } from "@tauri-apps/api/window";
* getCurrentWindow().listen("my-window-event", ({ event, payload }) => { });
* ```
*
* @module
*/
/**
* Attention type to request on a window.
*
* @since 1.0.0
*/
var UserAttentionType;
(function(UserAttentionType) {
	/**
	* #### Platform-specific
	* - **macOS:** Bounces the dock icon until the application is in focus.
	* - **Windows:** Flashes both the window and the taskbar button until the application is in focus.
	*/
	UserAttentionType[UserAttentionType["Critical"] = 1] = "Critical";
	/**
	* #### Platform-specific
	* - **macOS:** Bounces the dock icon once.
	* - **Windows:** Flashes the taskbar button until the application is in focus.
	*/
	UserAttentionType[UserAttentionType["Informational"] = 2] = "Informational";
})(UserAttentionType || (UserAttentionType = {}));
var CloseRequestedEvent = class {
	constructor(event) {
		this._preventDefault = false;
		this.event = event.event;
		this.id = event.id;
	}
	preventDefault() {
		this._preventDefault = true;
	}
	isPreventDefault() {
		return this._preventDefault;
	}
};
var ProgressBarStatus;
(function(ProgressBarStatus) {
	/**
	* Hide progress bar.
	*/
	ProgressBarStatus["None"] = "none";
	/**
	* Normal state.
	*/
	ProgressBarStatus["Normal"] = "normal";
	/**
	* Indeterminate state. **Treated as Normal on Linux and macOS**
	*/
	ProgressBarStatus["Indeterminate"] = "indeterminate";
	/**
	* Paused state. **Treated as Normal on Linux**
	*/
	ProgressBarStatus["Paused"] = "paused";
	/**
	* Error state. **Treated as Normal on linux**
	*/
	ProgressBarStatus["Error"] = "error";
})(ProgressBarStatus || (ProgressBarStatus = {}));
/**
* Get an instance of `Window` for the current window.
*
* @since 1.0.0
*/
function getCurrentWindow() {
	return new Window(window.__TAURI_INTERNALS__.metadata.currentWindow.label, { skip: true });
}
/**
* Gets a list of instances of `Window` for all available windows.
*
* @since 1.0.0
*/
async function getAllWindows() {
	return invoke("plugin:window|get_all_windows").then((windows) => windows.map((w) => new Window(w, { skip: true })));
}
/** @ignore */
var localTauriEvents$1 = ["tauri://created", "tauri://error"];
/**
* Create new window or get a handle to an existing one.
*
* Windows are identified by a *label*  a unique identifier that can be used to reference it later.
* It may only contain alphanumeric characters `a-zA-Z` plus the following special characters `-`, `/`, `:` and `_`.
*
* @example
* ```typescript
* import { Window } from "@tauri-apps/api/window"
*
* const appWindow = new Window('theUniqueLabel');
*
* appWindow.once('tauri://created', function () {
*  // window successfully created
* });
* appWindow.once('tauri://error', function (e) {
*  // an error happened creating the window
* });
*
* // emit an event to the backend
* await appWindow.emit("some-event", "data");
* // listen to an event from the backend
* const unlisten = await appWindow.listen("event-name", e => {});
* unlisten();
* ```
*
* @since 2.0.0
*/
var Window = class {
	/**
	* Creates a new Window.
	* @example
	* ```typescript
	* import { Window } from '@tauri-apps/api/window';
	* const appWindow = new Window('my-label');
	* appWindow.once('tauri://created', function () {
	*  // window successfully created
	* });
	* appWindow.once('tauri://error', function (e) {
	*  // an error happened creating the window
	* });
	* ```
	*
	* @param label The unique window label. Must be alphanumeric: `a-zA-Z-/:_`.
	* @returns The {@link Window} instance to communicate with the window.
	*/
	constructor(label, options = {}) {
		var _a;
		this.label = label;
		this.listeners = Object.create(null);
		if (!(options === null || options === void 0 ? void 0 : options.skip)) invoke("plugin:window|create", { options: {
			...options,
			parent: typeof options.parent === "string" ? options.parent : (_a = options.parent) === null || _a === void 0 ? void 0 : _a.label,
			label
		} }).then(async () => this.emit("tauri://created")).catch(async (e) => this.emit("tauri://error", e));
	}
	/**
	* Gets the Window associated with the given label.
	* @example
	* ```typescript
	* import { Window } from '@tauri-apps/api/window';
	* const mainWindow = Window.getByLabel('main');
	* ```
	*
	* @param label The window label.
	* @returns The Window instance to communicate with the window or null if the window doesn't exist.
	*/
	static async getByLabel(label) {
		var _a;
		return (_a = (await getAllWindows()).find((w) => w.label === label)) !== null && _a !== void 0 ? _a : null;
	}
	/**
	* Get an instance of `Window` for the current window.
	*/
	static getCurrent() {
		return getCurrentWindow();
	}
	/**
	* Gets a list of instances of `Window` for all available windows.
	*/
	static async getAll() {
		return getAllWindows();
	}
	/**
	*  Gets the focused window.
	* @example
	* ```typescript
	* import { Window } from '@tauri-apps/api/window';
	* const focusedWindow = Window.getFocusedWindow();
	* ```
	*
	* @returns The Window instance or `undefined` if there is not any focused window.
	*/
	static async getFocusedWindow() {
		for (const w of await getAllWindows()) if (await w.isFocused()) return w;
		return null;
	}
	/**
	* Listen to an emitted event on this window.
	*
	* @example
	* ```typescript
	* import { getCurrentWindow } from '@tauri-apps/api/window';
	* const unlisten = await getCurrentWindow().listen<string>('state-changed', (event) => {
	*   console.log(`Got error: ${payload}`);
	* });
	*
	* // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
	* unlisten();
	* ```
	*
	* @param event Event name. Must include only alphanumeric characters, `-`, `/`, `:` and `_`.
	* @param handler Event handler.
	* @returns A promise resolving to a function to unlisten to the event.
	* Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
	*/
	async listen(event, handler) {
		if (this._handleTauriEvent(event, handler)) return () => {
			const listeners = this.listeners[event];
			listeners.splice(listeners.indexOf(handler), 1);
		};
		return listen(event, handler, { target: {
			kind: "Window",
			label: this.label
		} });
	}
	/**
	* Listen to an emitted event on this window only once.
	*
	* @example
	* ```typescript
	* import { getCurrentWindow } from '@tauri-apps/api/window';
	* const unlisten = await getCurrentWindow().once<null>('initialized', (event) => {
	*   console.log(`Window initialized!`);
	* });
	*
	* // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
	* unlisten();
	* ```
	*
	* @param event Event name. Must include only alphanumeric characters, `-`, `/`, `:` and `_`.
	* @param handler Event handler.
	* @returns A promise resolving to a function to unlisten to the event.
	* Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
	*/
	async once(event, handler) {
		if (this._handleTauriEvent(event, handler)) return () => {
			const listeners = this.listeners[event];
			listeners.splice(listeners.indexOf(handler), 1);
		};
		return once(event, handler, { target: {
			kind: "Window",
			label: this.label
		} });
	}
	/**
	* Emits an event to all {@link EventTarget|targets}.
	* @example
	* ```typescript
	* import { getCurrentWindow } from '@tauri-apps/api/window';
	* await getCurrentWindow().emit('window-loaded', { loggedIn: true, token: 'authToken' });
	* ```
	*
	* @param event Event name. Must include only alphanumeric characters, `-`, `/`, `:` and `_`.
	* @param payload Event payload.
	*/
	async emit(event, payload) {
		if (localTauriEvents$1.includes(event)) {
			for (const handler of this.listeners[event] || []) handler({
				event,
				id: -1,
				payload
			});
			return;
		}
		return emit(event, payload);
	}
	/**
	* Emits an event to all {@link EventTarget|targets} matching the given target.
	*
	* @example
	* ```typescript
	* import { getCurrentWindow } from '@tauri-apps/api/window';
	* await getCurrentWindow().emit('main', 'window-loaded', { loggedIn: true, token: 'authToken' });
	* ```
	* @param target Label of the target Window/Webview/WebviewWindow or raw {@link EventTarget} object.
	* @param event Event name. Must include only alphanumeric characters, `-`, `/`, `:` and `_`.
	* @param payload Event payload.
	*/
	async emitTo(target, event, payload) {
		if (localTauriEvents$1.includes(event)) {
			for (const handler of this.listeners[event] || []) handler({
				event,
				id: -1,
				payload
			});
			return;
		}
		return emitTo(target, event, payload);
	}
	/** @ignore */
	_handleTauriEvent(event, handler) {
		if (localTauriEvents$1.includes(event)) {
			if (!(event in this.listeners)) this.listeners[event] = [handler];
			else this.listeners[event].push(handler);
			return true;
		}
		return false;
	}
	/**
	* The scale factor that can be used to map physical pixels to logical pixels.
	* @example
	* ```typescript
	* import { getCurrentWindow } from '@tauri-apps/api/window';
	* const factor = await getCurrentWindow().scaleFactor();
	* ```
	*
	* @returns The window's monitor scale factor.
	*/
	async scaleFactor() {
		return invoke("plugin:window|scale_factor", { label: this.label });
	}
	/**
	* The position of the top-left hand corner of the window's client area relative to the top-left hand corner of the desktop.
	* @example
	* ```typescript
	* import { getCurrentWindow } from '@tauri-apps/api/window';
	* const position = await getCurrentWindow().innerPosition();
	* ```
	*
	* @returns The window's inner position.
	*/
	async innerPosition() {
		return invoke("plugin:window|inner_position", { label: this.label }).then((p) => new PhysicalPosition(p));
	}
	/**
	* The position of the top-left hand corner of the window relative to the top-left hand corner of the desktop.
	* @example
	* ```typescript
	* import { getCurrentWindow } from '@tauri-apps/api/window';
	* const position = await getCurrentWindow().outerPosition();
	* ```
	*
	* @returns The window's outer position.
	*/
	async outerPosition() {
		return invoke("plugin:window|outer_position", { label: this.label }).then((p) => new PhysicalPosition(p));
	}
	/**
	* The physical size of the window's client area.
	* The client area is the content of the window, excluding the title bar and borders.
	* @example
	* ```typescript
	* import { getCurrentWindow } from '@tauri-apps/api/window';
	* const size = await getCurrentWindow().innerSize();
	* ```
	*
	* @returns The window's inner size.
	*/
	async innerSize() {
		return invoke("plugin:window|inner_size", { label: this.label }).then((s) => new PhysicalSize(s));
	}
	/**
	* The physical size of the entire window.
	* These dimensions include the title bar and borders. If you don't want that (and you usually don't), use inner_size instead.
	* @example
	* ```typescript
	* import { getCurrentWindow } from '@tauri-apps/api/window';
	* const size = await getCurrentWindow().outerSize();
	* ```
	*
	* @returns The window's outer size.
	*/
	async outerSize() {
		return invoke("plugin:window|outer_size", { label: this.label }).then((s) => new PhysicalSize(s));
	}
	/**
	* Gets the window's current fullscreen state.
	* @example
	* ```typescript
	* import { getCurrentWindow } from '@tauri-apps/api/window';
	* const fullscreen = await getCurrentWindow().isFullscreen();
	* ```
	*
	* @returns Whether the window is in fullscreen mode or not.
	*/
	async isFullscreen() {
		return invoke("plugin:window|is_fullscreen", { label: this.label });
	}
	/**
	* Gets the window's current minimized state.
	* @example
	* ```typescript
	* import { getCurrentWindow } from '@tauri-apps/api/window';
	* const minimized = await getCurrentWindow().isMinimized();
	* ```
	*/
	async isMinimized() {
		return invoke("plugin:window|is_minimized", { label: this.label });
	}
	/**
	* Gets the window's current maximized state.
	* @example
	* ```typescript
	* import { getCurrentWindow } from '@tauri-apps/api/window';
	* const maximized = await getCurrentWindow().isMaximized();
	* ```
	*
	* @returns Whether the window is maximized or not.
	*/
	async isMaximized() {
		return invoke("plugin:window|is_maximized", { label: this.label });
	}
	/**
	* Gets the window's current focus state.
	* @example
	* ```typescript
	* import { getCurrentWindow } from '@tauri-apps/api/window';
	* const focused = await getCurrentWindow().isFocused();
	* ```
	*
	* @returns Whether the window is focused or not.
	*/
	async isFocused() {
		return invoke("plugin:window|is_focused", { label: this.label });
	}
	/**
	* Gets the window's current decorated state.
	* @example
	* ```typescript
	* import { getCurrentWindow } from '@tauri-apps/api/window';
	* const decorated = await getCurrentWindow().isDecorated();
	* ```
	*
	* @returns Whether the window is decorated or not.
	*/
	async isDecorated() {
		return invoke("plugin:window|is_decorated", { label: this.label });
	}
	/**
	* Gets the window's current resizable state.
	* @example
	* ```typescript
	* import { getCurrentWindow } from '@tauri-apps/api/window';
	* const resizable = await getCurrentWindow().isResizable();
	* ```
	*
	* @returns Whether the window is resizable or not.
	*/
	async isResizable() {
		return invoke("plugin:window|is_resizable", { label: this.label });
	}
	/**
	* Gets the window's native maximize button state.
	*
	* #### Platform-specific
	*
	* - **Linux / iOS / Android:** Unsupported.
	*
	* @example
	* ```typescript
	* import { getCurrentWindow } from '@tauri-apps/api/window';
	* const maximizable = await getCurrentWindow().isMaximizable();
	* ```
	*
	* @returns Whether the window's native maximize button is enabled or not.
	*/
	async isMaximizable() {
		return invoke("plugin:window|is_maximizable", { label: this.label });
	}
	/**
	* Gets the window's native minimize button state.
	*
	* #### Platform-specific
	*
	* - **Linux / iOS / Android:** Unsupported.
	*
	* @example
	* ```typescript
	* import { getCurrentWindow } from '@tauri-apps/api/window';
	* const minimizable = await getCurrentWindow().isMinimizable();
	* ```
	*
	* @returns Whether the window's native minimize button is enabled or not.
	*/
	async isMinimizable() {
		return invoke("plugin:window|is_minimizable", { label: this.label });
	}
	/**
	* Gets the window's native close button state.
	*
	* #### Platform-specific
	*
	* - **iOS / Android:** Unsupported.
	*
	* @example
	* ```typescript
	* import { getCurrentWindow } from '@tauri-apps/api/window';
	* const closable = await getCurrentWindow().isClosable();
	* ```
	*
	* @returns Whether the window's native close button is enabled or not.
	*/
	async isClosable() {
		return invoke("plugin:window|is_closable", { label: this.label });
	}
	/**
	* Gets the window's current visible state.
	* @example
	* ```typescript
	* import { getCurrentWindow } from '@tauri-apps/api/window';
	* const visible = await getCurrentWindow().isVisible();
	* ```
	*
	* @returns Whether the window is visible or not.
	*/
	async isVisible() {
		return invoke("plugin:window|is_visible", { label: this.label });
	}
	/**
	* Gets the window's current title.
	* @example
	* ```typescript
	* import { getCurrentWindow } from '@tauri-apps/api/window';
	* const title = await getCurrentWindow().title();
	* ```
	*/
	async title() {
		return invoke("plugin:window|title", { label: this.label });
	}
	/**
	* Gets the window's current theme.
	*
	* #### Platform-specific
	*
	* - **macOS:** Theme was introduced on macOS 10.14. Returns `light` on macOS 10.13 and below.
	*
	* @example
	* ```typescript
	* import { getCurrentWindow } from '@tauri-apps/api/window';
	* const theme = await getCurrentWindow().theme();
	* ```
	*
	* @returns The window theme.
	*/
	async theme() {
		return invoke("plugin:window|theme", { label: this.label });
	}
	/**
	* Whether the window is configured to be always on top of other windows or not.
	* @example
	* ```typescript
	* import { getCurrentWindow } from '@tauri-apps/api/window';
	* const alwaysOnTop = await getCurrentWindow().isAlwaysOnTop();
	* ```
	*
	* @returns Whether the window is visible or not.
	*/
	async isAlwaysOnTop() {
		return invoke("plugin:window|is_always_on_top", { label: this.label });
	}
	async activityName() {
		return invoke("plugin:window|activity_name", { label: this.label });
	}
	async sceneIdentifier() {
		return invoke("plugin:window|scene_identifier", { label: this.label });
	}
	/**
	* Centers the window.
	* @example
	* ```typescript
	* import { getCurrentWindow } from '@tauri-apps/api/window';
	* await getCurrentWindow().center();
	* ```
	*
	* @returns A promise indicating the success or failure of the operation.
	*/
	async center() {
		return invoke("plugin:window|center", { label: this.label });
	}
	/**
	*  Requests user attention to the window, this has no effect if the application
	* is already focused. How requesting for user attention manifests is platform dependent,
	* see `UserAttentionType` for details.
	*
	* Providing `null` will unset the request for user attention. Unsetting the request for
	* user attention might not be done automatically by the WM when the window receives input.
	*
	* #### Platform-specific
	*
	* - **macOS:** `null` has no effect.
	* - **Linux:** Urgency levels have the same effect.
	* @example
	* ```typescript
	* import { getCurrentWindow } from '@tauri-apps/api/window';
	* await getCurrentWindow().requestUserAttention();
	* ```
	*
	* @returns A promise indicating the success or failure of the operation.
	*/
	async requestUserAttention(requestType) {
		let requestType_ = null;
		if (requestType) {
			if (requestType === UserAttentionType.Critical) requestType_ = { type: "Critical" };
			else requestType_ = { type: "Informational" };
		}
		return invoke("plugin:window|request_user_attention", {
			label: this.label,
			value: requestType_
		});
	}
	/**
	* Updates the window resizable flag.
	* @example
	* ```typescript
	* import { getCurrentWindow } from '@tauri-apps/api/window';
	* await getCurrentWindow().setResizable(false);
	* ```
	*
	* @returns A promise indicating the success or failure of the operation.
	*/
	async setResizable(resizable) {
		return invoke("plugin:window|set_resizable", {
			label: this.label,
			value: resizable
		});
	}
	/**
	* Enable or disable the window.
	* @example
	* ```typescript
	* import { getCurrentWindow } from '@tauri-apps/api/window';
	* await getCurrentWindow().setEnabled(false);
	* ```
	*
	* @returns A promise indicating the success or failure of the operation.
	*
	* @since 2.0.0
	*/
	async setEnabled(enabled) {
		return invoke("plugin:window|set_enabled", {
			label: this.label,
			value: enabled
		});
	}
	/**
	* Whether the window is enabled or disabled.
	* @example
	* ```typescript
	* import { getCurrentWindow } from '@tauri-apps/api/window';
	* await getCurrentWindow().setEnabled(false);
	* ```
	*
	* @returns A promise indicating the success or failure of the operation.
	*
	* @since 2.0.0
	*/
	async isEnabled() {
		return invoke("plugin:window|is_enabled", { label: this.label });
	}
	/**
	* Sets whether the window's native maximize button is enabled or not.
	* If resizable is set to false, this setting is ignored.
	*
	* #### Platform-specific
	*
	* - **macOS:** Disables the "zoom" button in the window titlebar, which is also used to enter fullscreen mode.
	* - **Linux / iOS / Android:** Unsupported.
	*
	* @example
	* ```typescript
	* import { getCurrentWindow } from '@tauri-apps/api/window';
	* await getCurrentWindow().setMaximizable(false);
	* ```
	*
	* @returns A promise indicating the success or failure of the operation.
	*/
	async setMaximizable(maximizable) {
		return invoke("plugin:window|set_maximizable", {
			label: this.label,
			value: maximizable
		});
	}
	/**
	* Sets whether the window's native minimize button is enabled or not.
	*
	* #### Platform-specific
	*
	* - **Linux / iOS / Android:** Unsupported.
	*
	* @example
	* ```typescript
	* import { getCurrentWindow } from '@tauri-apps/api/window';
	* await getCurrentWindow().setMinimizable(false);
	* ```
	*
	* @returns A promise indicating the success or failure of the operation.
	*/
	async setMinimizable(minimizable) {
		return invoke("plugin:window|set_minimizable", {
			label: this.label,
			value: minimizable
		});
	}
	/**
	* Sets whether the window's native close button is enabled or not.
	*
	* #### Platform-specific
	*
	* - **Linux:** GTK+ will do its best to convince the window manager not to show a close button. Depending on the system, this function may not have any effect when called on a window that is already visible
	* - **iOS / Android:** Unsupported.
	*
	* @example
	* ```typescript
	* import { getCurrentWindow } from '@tauri-apps/api/window';
	* await getCurrentWindow().setClosable(false);
	* ```
	*
	* @returns A promise indicating the success or failure of the operation.
	*/
	async setClosable(closable) {
		return invoke("plugin:window|set_closable", {
			label: this.label,
			value: closable
		});
	}
	/**
	* Sets the window title.
	* @example
	* ```typescript
	* import { getCurrentWindow } from '@tauri-apps/api/window';
	* await getCurrentWindow().setTitle('Tauri');
	* ```
	*
	* @param title The new title
	* @returns A promise indicating the success or failure of the operation.
	*/
	async setTitle(title) {
		return invoke("plugin:window|set_title", {
			label: this.label,
			value: title
		});
	}
	/**
	* Maximizes the window.
	* @example
	* ```typescript
	* import { getCurrentWindow } from '@tauri-apps/api/window';
	* await getCurrentWindow().maximize();
	* ```
	*
	* @returns A promise indicating the success or failure of the operation.
	*/
	async maximize() {
		return invoke("plugin:window|maximize", { label: this.label });
	}
	/**
	* Unmaximizes the window.
	* @example
	* ```typescript
	* import { getCurrentWindow } from '@tauri-apps/api/window';
	* await getCurrentWindow().unmaximize();
	* ```
	*
	* @returns A promise indicating the success or failure of the operation.
	*/
	async unmaximize() {
		return invoke("plugin:window|unmaximize", { label: this.label });
	}
	/**
	* Toggles the window maximized state.
	* @example
	* ```typescript
	* import { getCurrentWindow } from '@tauri-apps/api/window';
	* await getCurrentWindow().toggleMaximize();
	* ```
	*
	* @returns A promise indicating the success or failure of the operation.
	*/
	async toggleMaximize() {
		return invoke("plugin:window|toggle_maximize", { label: this.label });
	}
	/**
	* Minimizes the window.
	* @example
	* ```typescript
	* import { getCurrentWindow } from '@tauri-apps/api/window';
	* await getCurrentWindow().minimize();
	* ```
	*
	* @returns A promise indicating the success or failure of the operation.
	*/
	async minimize() {
		return invoke("plugin:window|minimize", { label: this.label });
	}
	/**
	* Unminimizes the window.
	* @example
	* ```typescript
	* import { getCurrentWindow } from '@tauri-apps/api/window';
	* await getCurrentWindow().unminimize();
	* ```
	*
	* @returns A promise indicating the success or failure of the operation.
	*/
	async unminimize() {
		return invoke("plugin:window|unminimize", { label: this.label });
	}
	/**
	* Sets the window visibility to true.
	* @example
	* ```typescript
	* import { getCurrentWindow } from '@tauri-apps/api/window';
	* await getCurrentWindow().show();
	* ```
	*
	* @returns A promise indicating the success or failure of the operation.
	*/
	async show() {
		return invoke("plugin:window|show", { label: this.label });
	}
	/**
	* Sets the window visibility to false.
	* @example
	* ```typescript
	* import { getCurrentWindow } from '@tauri-apps/api/window';
	* await getCurrentWindow().hide();
	* ```
	*
	* @returns A promise indicating the success or failure of the operation.
	*/
	async hide() {
		return invoke("plugin:window|hide", { label: this.label });
	}
	/**
	* Closes the window.
	*
	* Note this emits a closeRequested event so you can intercept it. To force window close, use {@link Window.destroy}.
	* @example
	* ```typescript
	* import { getCurrentWindow } from '@tauri-apps/api/window';
	* await getCurrentWindow().close();
	* ```
	*
	* @returns A promise indicating the success or failure of the operation.
	*/
	async close() {
		return invoke("plugin:window|close", { label: this.label });
	}
	/**
	* Destroys the window. Behaves like {@link Window.close} but forces the window close instead of emitting a closeRequested event.
	* @example
	* ```typescript
	* import { getCurrentWindow } from '@tauri-apps/api/window';
	* await getCurrentWindow().destroy();
	* ```
	*
	* @returns A promise indicating the success or failure of the operation.
	*/
	async destroy() {
		return invoke("plugin:window|destroy", { label: this.label });
	}
	/**
	* Whether the window should have borders and bars.
	* @example
	* ```typescript
	* import { getCurrentWindow } from '@tauri-apps/api/window';
	* await getCurrentWindow().setDecorations(false);
	* ```
	*
	* @param decorations Whether the window should have borders and bars.
	* @returns A promise indicating the success or failure of the operation.
	*/
	async setDecorations(decorations) {
		return invoke("plugin:window|set_decorations", {
			label: this.label,
			value: decorations
		});
	}
	/**
	* Whether or not the window should have shadow.
	*
	* #### Platform-specific
	*
	* - **Windows:**
	*   - `false` has no effect on decorated window, shadows are always ON.
	*   - `true` will make undecorated window have a 1px white border,
	* and on Windows 11, it will have a rounded corners.
	* - **Linux:** Unsupported.
	*
	* @example
	* ```typescript
	* import { getCurrentWindow } from '@tauri-apps/api/window';
	* await getCurrentWindow().setShadow(false);
	* ```
	*
	* @returns A promise indicating the success or failure of the operation.
	*/
	async setShadow(enable) {
		return invoke("plugin:window|set_shadow", {
			label: this.label,
			value: enable
		});
	}
	/**
	* Set window effects.
	*/
	async setEffects(effects) {
		return invoke("plugin:window|set_effects", {
			label: this.label,
			value: effects
		});
	}
	/**
	* Clear any applied effects if possible.
	*/
	async clearEffects() {
		return invoke("plugin:window|set_effects", {
			label: this.label,
			value: null
		});
	}
	/**
	* Whether the window should always be on top of other windows.
	* @example
	* ```typescript
	* import { getCurrentWindow } from '@tauri-apps/api/window';
	* await getCurrentWindow().setAlwaysOnTop(true);
	* ```
	*
	* @param alwaysOnTop Whether the window should always be on top of other windows or not.
	* @returns A promise indicating the success or failure of the operation.
	*/
	async setAlwaysOnTop(alwaysOnTop) {
		return invoke("plugin:window|set_always_on_top", {
			label: this.label,
			value: alwaysOnTop
		});
	}
	/**
	* Whether the window should always be below other windows.
	* @example
	* ```typescript
	* import { getCurrentWindow } from '@tauri-apps/api/window';
	* await getCurrentWindow().setAlwaysOnBottom(true);
	* ```
	*
	* @param alwaysOnBottom Whether the window should always be below other windows or not.
	* @returns A promise indicating the success or failure of the operation.
	*/
	async setAlwaysOnBottom(alwaysOnBottom) {
		return invoke("plugin:window|set_always_on_bottom", {
			label: this.label,
			value: alwaysOnBottom
		});
	}
	/**
	* Prevents the window contents from being captured by other apps.
	* @example
	* ```typescript
	* import { getCurrentWindow } from '@tauri-apps/api/window';
	* await getCurrentWindow().setContentProtected(true);
	* ```
	*
	* @returns A promise indicating the success or failure of the operation.
	*/
	async setContentProtected(protected_) {
		return invoke("plugin:window|set_content_protected", {
			label: this.label,
			value: protected_
		});
	}
	/**
	* Resizes the window with a new inner size.
	* @example
	* ```typescript
	* import { getCurrentWindow, LogicalSize } from '@tauri-apps/api/window';
	* await getCurrentWindow().setSize(new LogicalSize(600, 500));
	* ```
	*
	* @param size The logical or physical inner size.
	* @returns A promise indicating the success or failure of the operation.
	*/
	async setSize(size) {
		return invoke("plugin:window|set_size", {
			label: this.label,
			value: size instanceof Size ? size : new Size(size)
		});
	}
	/**
	* Sets the window minimum inner size. If the `size` argument is not provided, the constraint is unset.
	* @example
	* ```typescript
	* import { getCurrentWindow, PhysicalSize } from '@tauri-apps/api/window';
	* await getCurrentWindow().setMinSize(new PhysicalSize(600, 500));
	* ```
	*
	* @param size The logical or physical inner size, or `null` to unset the constraint.
	* @returns A promise indicating the success or failure of the operation.
	*/
	async setMinSize(size) {
		return invoke("plugin:window|set_min_size", {
			label: this.label,
			value: size instanceof Size ? size : size ? new Size(size) : null
		});
	}
	/**
	* Sets the window maximum inner size. If the `size` argument is undefined, the constraint is unset.
	* @example
	* ```typescript
	* import { getCurrentWindow, LogicalSize } from '@tauri-apps/api/window';
	* await getCurrentWindow().setMaxSize(new LogicalSize(600, 500));
	* ```
	*
	* @param size The logical or physical inner size, or `null` to unset the constraint.
	* @returns A promise indicating the success or failure of the operation.
	*/
	async setMaxSize(size) {
		return invoke("plugin:window|set_max_size", {
			label: this.label,
			value: size instanceof Size ? size : size ? new Size(size) : null
		});
	}
	/**
	* Sets the window inner size constraints.
	* @example
	* ```typescript
	* import { getCurrentWindow } from '@tauri-apps/api/window';
	* await getCurrentWindow().setSizeConstraints({ minWidth: 300 });
	* ```
	*
	* @param constraints The logical or physical inner size, or `null` to unset the constraint.
	* @returns A promise indicating the success or failure of the operation.
	*/
	async setSizeConstraints(constraints) {
		function logical(pixel) {
			return pixel ? { Logical: pixel } : null;
		}
		return invoke("plugin:window|set_size_constraints", {
			label: this.label,
			value: {
				minWidth: logical(constraints === null || constraints === void 0 ? void 0 : constraints.minWidth),
				minHeight: logical(constraints === null || constraints === void 0 ? void 0 : constraints.minHeight),
				maxWidth: logical(constraints === null || constraints === void 0 ? void 0 : constraints.maxWidth),
				maxHeight: logical(constraints === null || constraints === void 0 ? void 0 : constraints.maxHeight)
			}
		});
	}
	/**
	* Sets the window outer position.
	* @example
	* ```typescript
	* import { getCurrentWindow, LogicalPosition } from '@tauri-apps/api/window';
	* await getCurrentWindow().setPosition(new LogicalPosition(600, 500));
	* ```
	*
	* @param position The new position, in logical or physical pixels.
	* @returns A promise indicating the success or failure of the operation.
	*/
	async setPosition(position) {
		return invoke("plugin:window|set_position", {
			label: this.label,
			value: position instanceof Position ? position : new Position(position)
		});
	}
	/**
	* Sets the window fullscreen state.
	* @example
	* ```typescript
	* import { getCurrentWindow } from '@tauri-apps/api/window';
	* await getCurrentWindow().setFullscreen(true);
	* ```
	*
	* @param fullscreen Whether the window should go to fullscreen or not.
	* @returns A promise indicating the success or failure of the operation.
	*/
	async setFullscreen(fullscreen) {
		return invoke("plugin:window|set_fullscreen", {
			label: this.label,
			value: fullscreen
		});
	}
	/**
	* On macOS, Toggles a fullscreen mode that doesn’t require a new macOS space. Returns a boolean indicating whether the transition was successful (this won’t work if the window was already in the native fullscreen).
	* This is how fullscreen used to work on macOS in versions before Lion. And allows the user to have a fullscreen window without using another space or taking control over the entire monitor.
	*
	* On other platforms, this is the same as {@link Window.setFullscreen}.
	*
	* @param fullscreen Whether the window should go to simple fullscreen or not.
	* @returns A promise indicating the success or failure of the operation.
	*/
	async setSimpleFullscreen(fullscreen) {
		return invoke("plugin:window|set_simple_fullscreen", {
			label: this.label,
			value: fullscreen
		});
	}
	/**
	* Bring the window to front and focus.
	* @example
	* ```typescript
	* import { getCurrentWindow } from '@tauri-apps/api/window';
	* await getCurrentWindow().setFocus();
	* ```
	*
	* @returns A promise indicating the success or failure of the operation.
	*/
	async setFocus() {
		return invoke("plugin:window|set_focus", { label: this.label });
	}
	/**
	* Sets whether the window can be focused.
	*
	* #### Platform-specific
	*
	* - **macOS**: If the window is already focused, it is not possible to unfocus it after calling `set_focusable(false)`.
	*   In this case, you might consider calling {@link Window.setFocus} but it will move the window to the back i.e. at the bottom in terms of z-order.
	*
	* @example
	* ```typescript
	* import { getCurrentWindow } from '@tauri-apps/api/window';
	* await getCurrentWindow().setFocusable(true);
	* ```
	*
	* @param focusable Whether the window can be focused.
	* @returns A promise indicating the success or failure of the operation.
	*/
	async setFocusable(focusable) {
		return invoke("plugin:window|set_focusable", {
			label: this.label,
			value: focusable
		});
	}
	/**
	* Sets the window icon.
	* @example
	* ```typescript
	* import { getCurrentWindow } from '@tauri-apps/api/window';
	* await getCurrentWindow().setIcon('/tauri/awesome.png');
	* ```
	*
	* Note that you may need the `image-ico` or `image-png` Cargo features to use this API.
	* To enable it, change your Cargo.toml file:
	* ```toml
	* [dependencies]
	* tauri = { version = "...", features = ["...", "image-png"] }
	* ```
	*
	* @param icon Icon bytes or path to the icon file.
	* @returns A promise indicating the success or failure of the operation.
	*/
	async setIcon(icon) {
		return invoke("plugin:window|set_icon", {
			label: this.label,
			value: transformImage(icon)
		});
	}
	/**
	* Whether the window icon should be hidden from the taskbar or not.
	*
	* #### Platform-specific
	*
	* - **macOS:** Unsupported.
	* @example
	* ```typescript
	* import { getCurrentWindow } from '@tauri-apps/api/window';
	* await getCurrentWindow().setSkipTaskbar(true);
	* ```
	*
	* @param skip true to hide window icon, false to show it.
	* @returns A promise indicating the success or failure of the operation.
	*/
	async setSkipTaskbar(skip) {
		return invoke("plugin:window|set_skip_taskbar", {
			label: this.label,
			value: skip
		});
	}
	/**
	* Grabs the cursor, preventing it from leaving the window.
	*
	* There's no guarantee that the cursor will be hidden. You should
	* hide it by yourself if you want so.
	*
	* #### Platform-specific
	*
	* - **Linux:** Unsupported.
	* - **macOS:** This locks the cursor in a fixed location, which looks visually awkward.
	* @example
	* ```typescript
	* import { getCurrentWindow } from '@tauri-apps/api/window';
	* await getCurrentWindow().setCursorGrab(true);
	* ```
	*
	* @param grab `true` to grab the cursor icon, `false` to release it.
	* @returns A promise indicating the success or failure of the operation.
	*/
	async setCursorGrab(grab) {
		return invoke("plugin:window|set_cursor_grab", {
			label: this.label,
			value: grab
		});
	}
	/**
	* Modifies the cursor's visibility.
	*
	* #### Platform-specific
	*
	* - **Windows:** The cursor is only hidden within the confines of the window.
	* - **macOS:** The cursor is hidden as long as the window has input focus, even if the cursor is
	*   outside of the window.
	* @example
	* ```typescript
	* import { getCurrentWindow } from '@tauri-apps/api/window';
	* await getCurrentWindow().setCursorVisible(false);
	* ```
	*
	* @param visible If `false`, this will hide the cursor. If `true`, this will show the cursor.
	* @returns A promise indicating the success or failure of the operation.
	*/
	async setCursorVisible(visible) {
		return invoke("plugin:window|set_cursor_visible", {
			label: this.label,
			value: visible
		});
	}
	/**
	* Modifies the cursor icon of the window.
	* @example
	* ```typescript
	* import { getCurrentWindow } from '@tauri-apps/api/window';
	* await getCurrentWindow().setCursorIcon('help');
	* ```
	*
	* @param icon The new cursor icon.
	* @returns A promise indicating the success or failure of the operation.
	*/
	async setCursorIcon(icon) {
		return invoke("plugin:window|set_cursor_icon", {
			label: this.label,
			value: icon
		});
	}
	/**
	* Sets the window background color.
	*
	* #### Platform-specific:
	*
	* - **Windows:** alpha channel is ignored.
	* - **iOS / Android:** Unsupported.
	*
	* @returns A promise indicating the success or failure of the operation.
	*
	* @since 2.1.0
	*/
	async setBackgroundColor(color) {
		return invoke("plugin:window|set_background_color", { color });
	}
	/**
	* Changes the position of the cursor in window coordinates.
	* @example
	* ```typescript
	* import { getCurrentWindow, LogicalPosition } from '@tauri-apps/api/window';
	* await getCurrentWindow().setCursorPosition(new LogicalPosition(600, 300));
	* ```
	*
	* @param position The new cursor position.
	* @returns A promise indicating the success or failure of the operation.
	*/
	async setCursorPosition(position) {
		return invoke("plugin:window|set_cursor_position", {
			label: this.label,
			value: position instanceof Position ? position : new Position(position)
		});
	}
	/**
	* Changes the cursor events behavior.
	*
	* @example
	* ```typescript
	* import { getCurrentWindow } from '@tauri-apps/api/window';
	* await getCurrentWindow().setIgnoreCursorEvents(true);
	* ```
	*
	* @param ignore `true` to ignore the cursor events; `false` to process them as usual.
	* @returns A promise indicating the success or failure of the operation.
	*/
	async setIgnoreCursorEvents(ignore) {
		return invoke("plugin:window|set_ignore_cursor_events", {
			label: this.label,
			value: ignore
		});
	}
	/**
	* Starts dragging the window.
	* @example
	* ```typescript
	* import { getCurrentWindow } from '@tauri-apps/api/window';
	* await getCurrentWindow().startDragging();
	* ```
	*
	* @return A promise indicating the success or failure of the operation.
	*/
	async startDragging() {
		return invoke("plugin:window|start_dragging", { label: this.label });
	}
	/**
	* Starts resize-dragging the window.
	* @example
	* ```typescript
	* import { getCurrentWindow } from '@tauri-apps/api/window';
	* await getCurrentWindow().startResizeDragging();
	* ```
	*
	* @return A promise indicating the success or failure of the operation.
	*/
	async startResizeDragging(direction) {
		return invoke("plugin:window|start_resize_dragging", {
			label: this.label,
			value: direction
		});
	}
	/**
	* Sets the badge count. It is app wide and not specific to this window.
	*
	* #### Platform-specific
	*
	* - **Windows**: Unsupported. Use @{linkcode Window.setOverlayIcon} instead.
	*
	* @example
	* ```typescript
	* import { getCurrentWindow } from '@tauri-apps/api/window';
	* await getCurrentWindow().setBadgeCount(5);
	* ```
	*
	* @param count The badge count. Use `undefined` to remove the badge.
	* @return A promise indicating the success or failure of the operation.
	*/
	async setBadgeCount(count) {
		return invoke("plugin:window|set_badge_count", {
			label: this.label,
			value: count
		});
	}
	/**
	* Sets the badge cont **macOS only**.
	*
	* @example
	* ```typescript
	* import { getCurrentWindow } from '@tauri-apps/api/window';
	* await getCurrentWindow().setBadgeLabel("Hello");
	* ```
	*
	* @param label The badge label. Use `undefined` to remove the badge.
	* @return A promise indicating the success or failure of the operation.
	*/
	async setBadgeLabel(label) {
		return invoke("plugin:window|set_badge_label", {
			label: this.label,
			value: label
		});
	}
	/**
	* Sets the overlay icon. **Windows only**
	* The overlay icon can be set for every window.
	*
	*
	* Note that you may need the `image-ico` or `image-png` Cargo features to use this API.
	* To enable it, change your Cargo.toml file:
	*
	* ```toml
	* [dependencies]
	* tauri = { version = "...", features = ["...", "image-png"] }
	* ```
	*
	* @example
	* ```typescript
	* import { getCurrentWindow } from '@tauri-apps/api/window';
	* await getCurrentWindow().setOverlayIcon("/tauri/awesome.png");
	* ```
	*
	* @param icon Icon bytes or path to the icon file. Use `undefined` to remove the overlay icon.
	* @return A promise indicating the success or failure of the operation.
	*/
	async setOverlayIcon(icon) {
		return invoke("plugin:window|set_overlay_icon", {
			label: this.label,
			value: icon ? transformImage(icon) : void 0
		});
	}
	/**
	* Sets the taskbar progress state.
	*
	* #### Platform-specific
	*
	* - **Linux / macOS**: Progress bar is app-wide and not specific to this window.
	* - **Linux**: Only supported desktop environments with `libunity` (e.g. GNOME).
	*
	* @example
	* ```typescript
	* import { getCurrentWindow, ProgressBarStatus } from '@tauri-apps/api/window';
	* await getCurrentWindow().setProgressBar({
	*   status: ProgressBarStatus.Normal,
	*   progress: 50,
	* });
	* ```
	*
	* @return A promise indicating the success or failure of the operation.
	*/
	async setProgressBar(state) {
		return invoke("plugin:window|set_progress_bar", {
			label: this.label,
			value: state
		});
	}
	/**
	* Sets whether the window should be visible on all workspaces or virtual desktops.
	*
	* #### Platform-specific
	*
	* - **Windows / iOS / Android:** Unsupported.
	*
	* @since 2.0.0
	*/
	async setVisibleOnAllWorkspaces(visible) {
		return invoke("plugin:window|set_visible_on_all_workspaces", {
			label: this.label,
			value: visible
		});
	}
	/**
	* Sets the title bar style. **macOS only**.
	*
	* @since 2.0.0
	*/
	async setTitleBarStyle(style) {
		return invoke("plugin:window|set_title_bar_style", {
			label: this.label,
			value: style
		});
	}
	/**
	* Set window theme, pass in `null` or `undefined` to follow system theme
	*
	* #### Platform-specific
	*
	* - **Linux / macOS**: Theme is app-wide and not specific to this window.
	* - **iOS / Android:** Unsupported.
	*
	* @since 2.0.0
	*/
	async setTheme(theme) {
		return invoke("plugin:window|set_theme", {
			label: this.label,
			value: theme
		});
	}
	/**
	* Listen to window resize.
	*
	* @example
	* ```typescript
	* import { getCurrentWindow } from "@tauri-apps/api/window";
	* const unlisten = await getCurrentWindow().onResized(({ payload: size }) => {
	*  console.log('Window resized', size);
	* });
	*
	* // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
	* unlisten();
	* ```
	*
	* @returns A promise resolving to a function to unlisten to the event.
	* Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
	*/
	async onResized(handler) {
		return this.listen(TauriEvent.WINDOW_RESIZED, (e) => {
			e.payload = new PhysicalSize(e.payload);
			handler(e);
		});
	}
	/**
	* Listen to window move.
	*
	* @example
	* ```typescript
	* import { getCurrentWindow } from "@tauri-apps/api/window";
	* const unlisten = await getCurrentWindow().onMoved(({ payload: position }) => {
	*  console.log('Window moved', position);
	* });
	*
	* // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
	* unlisten();
	* ```
	*
	* @returns A promise resolving to a function to unlisten to the event.
	* Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
	*/
	async onMoved(handler) {
		return this.listen(TauriEvent.WINDOW_MOVED, (e) => {
			e.payload = new PhysicalPosition(e.payload);
			handler(e);
		});
	}
	/**
	* Listen to window close requested. Emitted when the user requests to closes the window.
	*
	* @example
	* ```typescript
	* import { getCurrentWindow } from "@tauri-apps/api/window";
	* import { confirm } from '@tauri-apps/api/dialog';
	* const unlisten = await getCurrentWindow().onCloseRequested(async (event) => {
	*   const confirmed = await confirm('Are you sure?');
	*   if (!confirmed) {
	*     // user did not confirm closing the window; let's prevent it
	*     event.preventDefault();
	*   }
	* });
	*
	* // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
	* unlisten();
	* ```
	*
	* @returns A promise resolving to a function to unlisten to the event.
	* Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
	*/
	async onCloseRequested(handler) {
		return this.listen(TauriEvent.WINDOW_CLOSE_REQUESTED, async (event) => {
			const evt = new CloseRequestedEvent(event);
			await handler(evt);
			if (!evt.isPreventDefault()) await this.destroy();
		});
	}
	/**
	* Listen to a file drop event.
	* The listener is triggered when the user hovers the selected files on the webview,
	* drops the files or cancels the operation.
	*
	* @example
	* ```typescript
	* import { getCurrentWindow } from "@tauri-apps/api/webview";
	* const unlisten = await getCurrentWindow().onDragDropEvent((event) => {
	*  if (event.payload.type === 'over') {
	*    console.log('User hovering', event.payload.position);
	*  } else if (event.payload.type === 'drop') {
	*    console.log('User dropped', event.payload.paths);
	*  } else {
	*    console.log('File drop cancelled');
	*  }
	* });
	*
	* // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
	* unlisten();
	* ```
	*
	* @returns A promise resolving to a function to unlisten to the event.
	* Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
	*/
	async onDragDropEvent(handler) {
		const unlistenDrag = await this.listen(TauriEvent.DRAG_ENTER, (event) => {
			handler({
				...event,
				payload: {
					type: "enter",
					paths: event.payload.paths,
					position: new PhysicalPosition(event.payload.position)
				}
			});
		});
		const unlistenDragOver = await this.listen(TauriEvent.DRAG_OVER, (event) => {
			handler({
				...event,
				payload: {
					type: "over",
					position: new PhysicalPosition(event.payload.position)
				}
			});
		});
		const unlistenDrop = await this.listen(TauriEvent.DRAG_DROP, (event) => {
			handler({
				...event,
				payload: {
					type: "drop",
					paths: event.payload.paths,
					position: new PhysicalPosition(event.payload.position)
				}
			});
		});
		const unlistenCancel = await this.listen(TauriEvent.DRAG_LEAVE, (event) => {
			handler({
				...event,
				payload: { type: "leave" }
			});
		});
		return () => {
			unlistenDrag();
			unlistenDrop();
			unlistenDragOver();
			unlistenCancel();
		};
	}
	/**
	* Listen to window focus change.
	*
	* @example
	* ```typescript
	* import { getCurrentWindow } from "@tauri-apps/api/window";
	* const unlisten = await getCurrentWindow().onFocusChanged(({ payload: focused }) => {
	*  console.log('Focus changed, window is focused? ' + focused);
	* });
	*
	* // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
	* unlisten();
	* ```
	*
	* @returns A promise resolving to a function to unlisten to the event.
	* Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
	*/
	async onFocusChanged(handler) {
		const unlistenFocus = await this.listen(TauriEvent.WINDOW_FOCUS, (event) => {
			handler({
				...event,
				payload: true
			});
		});
		const unlistenBlur = await this.listen(TauriEvent.WINDOW_BLUR, (event) => {
			handler({
				...event,
				payload: false
			});
		});
		return () => {
			unlistenFocus();
			unlistenBlur();
		};
	}
	/**
	* Listen to window scale change. Emitted when the window's scale factor has changed.
	* The following user actions can cause DPI changes:
	* - Changing the display's resolution.
	* - Changing the display's scale factor (e.g. in Control Panel on Windows).
	* - Moving the window to a display with a different scale factor.
	*
	* @example
	* ```typescript
	* import { getCurrentWindow } from "@tauri-apps/api/window";
	* const unlisten = await getCurrentWindow().onScaleChanged(({ payload }) => {
	*  console.log('Scale changed', payload.scaleFactor, payload.size);
	* });
	*
	* // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
	* unlisten();
	* ```
	*
	* @returns A promise resolving to a function to unlisten to the event.
	* Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
	*/
	async onScaleChanged(handler) {
		return this.listen(TauriEvent.WINDOW_SCALE_FACTOR_CHANGED, handler);
	}
	/**
	* Listen to the system theme change.
	*
	* @example
	* ```typescript
	* import { getCurrentWindow } from "@tauri-apps/api/window";
	* const unlisten = await getCurrentWindow().onThemeChanged(({ payload: theme }) => {
	*  console.log('New theme: ' + theme);
	* });
	*
	* // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
	* unlisten();
	* ```
	*
	* @returns A promise resolving to a function to unlisten to the event.
	* Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
	*/
	async onThemeChanged(handler) {
		return this.listen(TauriEvent.WINDOW_THEME_CHANGED, handler);
	}
};
/**
* Background throttling policy
*
* @since 2.0.0
*/
var BackgroundThrottlingPolicy;
(function(BackgroundThrottlingPolicy) {
	BackgroundThrottlingPolicy["Disabled"] = "disabled";
	BackgroundThrottlingPolicy["Throttle"] = "throttle";
	BackgroundThrottlingPolicy["Suspend"] = "suspend";
})(BackgroundThrottlingPolicy || (BackgroundThrottlingPolicy = {}));
/**
* The scrollbar style to use in the webview.
*
* ## Platform-specific
*
* **Windows**: This option must be given the same value for all webviews.
*
* @since 2.8.0
*/
var ScrollBarStyle;
(function(ScrollBarStyle) {
	/**
	* The default scrollbar style for the webview.
	*/
	ScrollBarStyle["Default"] = "default";
	/**
	* Fluent UI style overlay scrollbars. **Windows Only**
	*
	* Requires WebView2 Runtime version 125.0.2535.41 or higher, does nothing on older versions,
	* see https://learn.microsoft.com/en-us/microsoft-edge/webview2/release-notes/?tabs=dotnetcsharp#10253541
	*/
	ScrollBarStyle["FluentOverlay"] = "fluentOverlay";
})(ScrollBarStyle || (ScrollBarStyle = {}));
/**
* Platform-specific window effects
*
* @since 2.0.0
*/
var Effect;
(function(Effect) {
	/**
	* A default material appropriate for the view's effectiveAppearance.  **macOS 10.14-**
	*
	* @deprecated since macOS 10.14. You should instead choose an appropriate semantic material.
	*/
	Effect["AppearanceBased"] = "appearanceBased";
	/**
	*  **macOS 10.14-**
	*
	* @deprecated since macOS 10.14. Use a semantic material instead.
	*/
	Effect["Light"] = "light";
	/**
	*  **macOS 10.14-**
	*
	* @deprecated since macOS 10.14. Use a semantic material instead.
	*/
	Effect["Dark"] = "dark";
	/**
	*  **macOS 10.14-**
	*
	* @deprecated since macOS 10.14. Use a semantic material instead.
	*/
	Effect["MediumLight"] = "mediumLight";
	/**
	*  **macOS 10.14-**
	*
	* @deprecated since macOS 10.14. Use a semantic material instead.
	*/
	Effect["UltraDark"] = "ultraDark";
	/**
	*  **macOS 10.10+**
	*/
	Effect["Titlebar"] = "titlebar";
	/**
	*  **macOS 10.10+**
	*/
	Effect["Selection"] = "selection";
	/**
	*  **macOS 10.11+**
	*/
	Effect["Menu"] = "menu";
	/**
	*  **macOS 10.11+**
	*/
	Effect["Popover"] = "popover";
	/**
	*  **macOS 10.11+**
	*/
	Effect["Sidebar"] = "sidebar";
	/**
	*  **macOS 10.14+**
	*/
	Effect["HeaderView"] = "headerView";
	/**
	*  **macOS 10.14+**
	*/
	Effect["Sheet"] = "sheet";
	/**
	*  **macOS 10.14+**
	*/
	Effect["WindowBackground"] = "windowBackground";
	/**
	*  **macOS 10.14+**
	*/
	Effect["HudWindow"] = "hudWindow";
	/**
	*  **macOS 10.14+**
	*/
	Effect["FullScreenUI"] = "fullScreenUI";
	/**
	*  **macOS 10.14+**
	*/
	Effect["Tooltip"] = "tooltip";
	/**
	*  **macOS 10.14+**
	*/
	Effect["ContentBackground"] = "contentBackground";
	/**
	*  **macOS 10.14+**
	*/
	Effect["UnderWindowBackground"] = "underWindowBackground";
	/**
	*  **macOS 10.14+**
	*/
	Effect["UnderPageBackground"] = "underPageBackground";
	/**
	*  **Windows 11 Only**
	*/
	Effect["Mica"] = "mica";
	/**
	* **Windows 7/10/11(22H1) Only**
	*
	* #### Notes
	*
	* This effect has bad performance when resizing/dragging the window on Windows 11 build 22621.
	*/
	Effect["Blur"] = "blur";
	/**
	* **Windows 10/11**
	*
	* #### Notes
	*
	* This effect has bad performance when resizing/dragging the window on Windows 10 v1903+ and Windows 11 build 22000.
	*/
	Effect["Acrylic"] = "acrylic";
	/**
	* Tabbed effect that matches the system dark preference **Windows 11 Only**
	*/
	Effect["Tabbed"] = "tabbed";
	/**
	* Tabbed effect with dark mode but only if dark mode is enabled on the system **Windows 11 Only**
	*/
	Effect["TabbedDark"] = "tabbedDark";
	/**
	* Tabbed effect with light mode **Windows 11 Only**
	*/
	Effect["TabbedLight"] = "tabbedLight";
})(Effect || (Effect = {}));
/**
* Window effect state **macOS only**
*
* @see https://developer.apple.com/documentation/appkit/nsvisualeffectview/state
*
* @since 2.0.0
*/
var EffectState;
(function(EffectState) {
	/**
	*  Make window effect state follow the window's active state **macOS only**
	*/
	EffectState["FollowsWindowActiveState"] = "followsWindowActiveState";
	/**
	*  Make window effect state always active **macOS only**
	*/
	EffectState["Active"] = "active";
	/**
	*  Make window effect state always inactive **macOS only**
	*/
	EffectState["Inactive"] = "inactive";
})(EffectState || (EffectState = {}));
function mapMonitor(m) {
	return m === null ? null : {
		name: m.name,
		scaleFactor: m.scaleFactor,
		position: new PhysicalPosition(m.position),
		size: new PhysicalSize(m.size),
		workArea: {
			position: new PhysicalPosition(m.workArea.position),
			size: new PhysicalSize(m.workArea.size)
		}
	};
}
/**
* Returns the monitor on which the window currently resides.
* Returns `null` if current monitor can't be detected.
* @example
* ```typescript
* import { currentMonitor } from '@tauri-apps/api/window';
* const monitor = await currentMonitor();
* ```
*
* @since 1.0.0
*/
async function currentMonitor() {
	return invoke("plugin:window|current_monitor").then(mapMonitor);
}
/**
* Returns the primary monitor of the system.
* Returns `null` if it can't identify any monitor as a primary one.
* @example
* ```typescript
* import { primaryMonitor } from '@tauri-apps/api/window';
* const monitor = await primaryMonitor();
* ```
*
* @since 1.0.0
*/
async function primaryMonitor() {
	return invoke("plugin:window|primary_monitor").then(mapMonitor);
}
/**
* Get the cursor position relative to the top-left hand corner of the desktop.
*
* Note that the top-left hand corner of the desktop is not necessarily the same as the screen.
* If the user uses a desktop with multiple monitors,
* the top-left hand corner of the desktop is the top-left hand corner of the main monitor on Windows and macOS
* or the top-left of the leftmost monitor on X11.
*
* The coordinates can be negative if the top-left hand corner of the window is outside of the visible screen region.
*/
async function cursorPosition() {
	return invoke("plugin:window|cursor_position").then((v) => new PhysicalPosition(v));
}
//#endregion
//#region node_modules/@tauri-apps/api/webview.js
/**
* Provides APIs to create webviews, communicate with other webviews and manipulate the current webview.
*
* #### Webview events
*
* Events can be listened to using {@link Webview.listen}:
* ```typescript
* import { getCurrentWebview } from "@tauri-apps/api/webview";
* getCurrentWebview().listen("my-webview-event", ({ event, payload }) => { });
* ```
*
* @module
*/
/**
* Get an instance of `Webview` for the current webview.
*
* @since 2.0.0
*/
function getCurrentWebview() {
	return new Webview(getCurrentWindow(), window.__TAURI_INTERNALS__.metadata.currentWebview.label, { skip: true });
}
/**
* Gets a list of instances of `Webview` for all available webviews.
*
* @since 2.0.0
*/
async function getAllWebviews() {
	return invoke("plugin:webview|get_all_webviews").then((webviews) => webviews.map((w) => new Webview(new Window(w.windowLabel, { skip: true }), w.label, { skip: true })));
}
/** @ignore */
var localTauriEvents = ["tauri://created", "tauri://error"];
/**
* Create new webview or get a handle to an existing one.
*
* Webviews are identified by a *label*  a unique identifier that can be used to reference it later.
* It may only contain alphanumeric characters `a-zA-Z` plus the following special characters `-`, `/`, `:` and `_`.
*
* @example
* ```typescript
* import { Window } from "@tauri-apps/api/window"
* import { Webview } from "@tauri-apps/api/webview"
*
* const appWindow = new Window('uniqueLabel');
*
* appWindow.once('tauri://created', async function () {
*   // `new Webview` Should be called after the window is successfully created,
*   // or webview may not be attached to the window since window is not created yet.
*
*   // loading embedded asset:
*   const webview = new Webview(appWindow, 'theUniqueLabel', {
*     url: 'path/to/page.html',
*
*     // create a webview with specific logical position and size
*     x: 0,
*     y: 0,
*     width: 800,
*     height: 600,
*   });
*   // alternatively, load a remote URL:
*   const webview = new Webview(appWindow, 'theUniqueLabel', {
*     url: 'https://github.com/tauri-apps/tauri',
*
*     // create a webview with specific logical position and size
*     x: 0,
*     y: 0,
*     width: 800,
*     height: 600,
*   });
*
*   webview.once('tauri://created', function () {
*     // webview successfully created
*   });
*   webview.once('tauri://error', function (e) {
*     // an error happened creating the webview
*   });
*
*
*   // emit an event to the backend
*   await webview.emit("some-event", "data");
*   // listen to an event from the backend
*   const unlisten = await webview.listen("event-name", e => { });
*   unlisten();
* });
* ```
*
* @since 2.0.0
*/
var Webview = class {
	/**
	* Creates a new Webview.
	* @example
	* ```typescript
	* import { Window } from '@tauri-apps/api/window'
	* import { Webview } from '@tauri-apps/api/webview'
	* const appWindow = new Window('my-label')
	*
	* appWindow.once('tauri://created', async function() {
	*   const webview = new Webview(appWindow, 'my-label', {
	*     url: 'https://github.com/tauri-apps/tauri',
	*
	*     // create a webview with specific logical position and size
	*     x: 0,
	*     y: 0,
	*     width: 800,
	*     height: 600,
	*   });
	*
	*   webview.once('tauri://created', function () {
	*     // webview successfully created
	*   });
	*   webview.once('tauri://error', function (e) {
	*     // an error happened creating the webview
	*   });
	* });
	* ```
	*
	* @param window the window to add this webview to.
	* @param label The unique webview label. Must be alphanumeric: `a-zA-Z-/:_`.
	* @returns The {@link Webview} instance to communicate with the webview.
	*/
	constructor(window, label, options) {
		this.window = window;
		this.label = label;
		this.listeners = Object.create(null);
		if (!(options === null || options === void 0 ? void 0 : options.skip)) invoke("plugin:webview|create_webview", {
			windowLabel: window.label,
			options: {
				...options,
				label
			}
		}).then(async () => this.emit("tauri://created")).catch(async (e) => this.emit("tauri://error", e));
	}
	/**
	* Gets the Webview for the webview associated with the given label.
	* @example
	* ```typescript
	* import { Webview } from '@tauri-apps/api/webview';
	* const mainWebview = Webview.getByLabel('main');
	* ```
	*
	* @param label The webview label.
	* @returns The Webview instance to communicate with the webview or null if the webview doesn't exist.
	*/
	static async getByLabel(label) {
		var _a;
		return (_a = (await getAllWebviews()).find((w) => w.label === label)) !== null && _a !== void 0 ? _a : null;
	}
	/**
	* Get an instance of `Webview` for the current webview.
	*/
	static getCurrent() {
		return getCurrentWebview();
	}
	/**
	* Gets a list of instances of `Webview` for all available webviews.
	*/
	static async getAll() {
		return getAllWebviews();
	}
	/**
	* Listen to an emitted event on this webview.
	*
	* @example
	* ```typescript
	* import { getCurrentWebview } from '@tauri-apps/api/webview';
	* const unlisten = await getCurrentWebview().listen<string>('state-changed', (event) => {
	*   console.log(`Got error: ${payload}`);
	* });
	*
	* // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
	* unlisten();
	* ```
	*
	* @param event Event name. Must include only alphanumeric characters, `-`, `/`, `:` and `_`.
	* @param handler Event handler.
	* @returns A promise resolving to a function to unlisten to the event.
	* Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
	*/
	async listen(event, handler) {
		if (this._handleTauriEvent(event, handler)) return () => {
			const listeners = this.listeners[event];
			listeners.splice(listeners.indexOf(handler), 1);
		};
		return listen(event, handler, { target: {
			kind: "Webview",
			label: this.label
		} });
	}
	/**
	* Listen to an emitted event on this webview only once.
	*
	* @example
	* ```typescript
	* import { getCurrentWebview } from '@tauri-apps/api/webview';
	* const unlisten = await getCurrent().once<null>('initialized', (event) => {
	*   console.log(`Webview initialized!`);
	* });
	*
	* // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
	* unlisten();
	* ```
	*
	* @param event Event name. Must include only alphanumeric characters, `-`, `/`, `:` and `_`.
	* @param handler Event handler.
	* @returns A promise resolving to a function to unlisten to the event.
	* Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
	*/
	async once(event, handler) {
		if (this._handleTauriEvent(event, handler)) return () => {
			const listeners = this.listeners[event];
			listeners.splice(listeners.indexOf(handler), 1);
		};
		return once(event, handler, { target: {
			kind: "Webview",
			label: this.label
		} });
	}
	/**
	* Emits an event to all {@link EventTarget|targets}.
	*
	* @example
	* ```typescript
	* import { getCurrentWebview } from '@tauri-apps/api/webview';
	* await getCurrentWebview().emit('webview-loaded', { loggedIn: true, token: 'authToken' });
	* ```
	*
	* @param event Event name. Must include only alphanumeric characters, `-`, `/`, `:` and `_`.
	* @param payload Event payload.
	*/
	async emit(event, payload) {
		if (localTauriEvents.includes(event)) {
			for (const handler of this.listeners[event] || []) handler({
				event,
				id: -1,
				payload
			});
			return;
		}
		return emit(event, payload);
	}
	/**
	* Emits an event to all {@link EventTarget|targets} matching the given target.
	*
	* @example
	* ```typescript
	* import { getCurrentWebview } from '@tauri-apps/api/webview';
	* await getCurrentWebview().emitTo('main', 'webview-loaded', { loggedIn: true, token: 'authToken' });
	* ```
	*
	* @param target Label of the target Window/Webview/WebviewWindow or raw {@link EventTarget} object.
	* @param event Event name. Must include only alphanumeric characters, `-`, `/`, `:` and `_`.
	* @param payload Event payload.
	*/
	async emitTo(target, event, payload) {
		if (localTauriEvents.includes(event)) {
			for (const handler of this.listeners[event] || []) handler({
				event,
				id: -1,
				payload
			});
			return;
		}
		return emitTo(target, event, payload);
	}
	/** @ignore */
	_handleTauriEvent(event, handler) {
		if (localTauriEvents.includes(event)) {
			if (!(event in this.listeners)) this.listeners[event] = [handler];
			else this.listeners[event].push(handler);
			return true;
		}
		return false;
	}
	/**
	* The position of the top-left hand corner of the webview's client area relative to the top-left hand corner of the desktop.
	* @example
	* ```typescript
	* import { getCurrentWebview } from '@tauri-apps/api/webview';
	* const position = await getCurrentWebview().position();
	* ```
	*
	* @returns The webview's position.
	*/
	async position() {
		return invoke("plugin:webview|webview_position", { label: this.label }).then((p) => new PhysicalPosition(p));
	}
	/**
	* The physical size of the webview's client area.
	* The client area is the content of the webview, excluding the title bar and borders.
	* @example
	* ```typescript
	* import { getCurrentWebview } from '@tauri-apps/api/webview';
	* const size = await getCurrentWebview().size();
	* ```
	*
	* @returns The webview's size.
	*/
	async size() {
		return invoke("plugin:webview|webview_size", { label: this.label }).then((s) => new PhysicalSize(s));
	}
	/**
	* Closes the webview.
	* @example
	* ```typescript
	* import { getCurrentWebview } from '@tauri-apps/api/webview';
	* await getCurrentWebview().close();
	* ```
	*
	* @returns A promise indicating the success or failure of the operation.
	*/
	async close() {
		return invoke("plugin:webview|webview_close", { label: this.label });
	}
	/**
	* Resizes the webview.
	* @example
	* ```typescript
	* import { getCurrent, LogicalSize } from '@tauri-apps/api/webview';
	* await getCurrentWebview().setSize(new LogicalSize(600, 500));
	* ```
	*
	* @param size The logical or physical size.
	* @returns A promise indicating the success or failure of the operation.
	*/
	async setSize(size) {
		return invoke("plugin:webview|set_webview_size", {
			label: this.label,
			value: size instanceof Size ? size : new Size(size)
		});
	}
	/**
	* Sets the webview position.
	* @example
	* ```typescript
	* import { getCurrent, LogicalPosition } from '@tauri-apps/api/webview';
	* await getCurrentWebview().setPosition(new LogicalPosition(600, 500));
	* ```
	*
	* @param position The new position, in logical or physical pixels.
	* @returns A promise indicating the success or failure of the operation.
	*/
	async setPosition(position) {
		return invoke("plugin:webview|set_webview_position", {
			label: this.label,
			value: position instanceof Position ? position : new Position(position)
		});
	}
	/**
	* Bring the webview to front and focus.
	* @example
	* ```typescript
	* import { getCurrentWebview } from '@tauri-apps/api/webview';
	* await getCurrentWebview().setFocus();
	* ```
	*
	* @returns A promise indicating the success or failure of the operation.
	*/
	async setFocus() {
		return invoke("plugin:webview|set_webview_focus", { label: this.label });
	}
	/**
	* Sets whether the webview should automatically grow and shrink its size and position when the parent window resizes.
	* @example
	* ```typescript
	* import { getCurrentWebview } from '@tauri-apps/api/webview';
	* await getCurrentWebview().setAutoResize(true);
	* ```
	*
	* @returns A promise indicating the success or failure of the operation.
	*/
	async setAutoResize(autoResize) {
		return invoke("plugin:webview|set_webview_auto_resize", {
			label: this.label,
			value: autoResize
		});
	}
	/**
	* Hide the webview.
	* @example
	* ```typescript
	* import { getCurrentWebview } from '@tauri-apps/api/webview';
	* await getCurrentWebview().hide();
	* ```
	*
	* @returns A promise indicating the success or failure of the operation.
	*/
	async hide() {
		return invoke("plugin:webview|webview_hide", { label: this.label });
	}
	/**
	* Show the webview.
	* @example
	* ```typescript
	* import { getCurrentWebview } from '@tauri-apps/api/webview';
	* await getCurrentWebview().show();
	* ```
	*
	* @returns A promise indicating the success or failure of the operation.
	*/
	async show() {
		return invoke("plugin:webview|webview_show", { label: this.label });
	}
	/**
	* Set webview zoom level.
	* @example
	* ```typescript
	* import { getCurrentWebview } from '@tauri-apps/api/webview';
	* await getCurrentWebview().setZoom(1.5);
	* ```
	*
	* @returns A promise indicating the success or failure of the operation.
	*/
	async setZoom(scaleFactor) {
		return invoke("plugin:webview|set_webview_zoom", {
			label: this.label,
			value: scaleFactor
		});
	}
	/**
	* Moves this webview to the given label.
	* @example
	* ```typescript
	* import { getCurrentWebview } from '@tauri-apps/api/webview';
	* await getCurrentWebview().reparent('other-window');
	* ```
	*
	* @returns A promise indicating the success or failure of the operation.
	*/
	async reparent(window) {
		return invoke("plugin:webview|reparent", {
			label: this.label,
			window: typeof window === "string" ? window : window.label
		});
	}
	/**
	* Clears all browsing data for this webview.
	* @example
	* ```typescript
	* import { getCurrentWebview } from '@tauri-apps/api/webview';
	* await getCurrentWebview().clearAllBrowsingData();
	* ```
	*
	* @returns A promise indicating the success or failure of the operation.
	*/
	async clearAllBrowsingData() {
		return invoke("plugin:webview|clear_all_browsing_data");
	}
	/**
	* Specify the webview background color.
	*
	* #### Platfrom-specific:
	*
	* - **macOS / iOS**: Not implemented.
	* - **Windows**:
	*   - On Windows 7, transparency is not supported and the alpha value will be ignored.
	*   - On Windows higher than 7: translucent colors are not supported so any alpha value other than `0` will be replaced by `255`
	*
	* @returns A promise indicating the success or failure of the operation.
	*
	* @since 2.1.0
	*/
	async setBackgroundColor(color) {
		return invoke("plugin:webview|set_webview_background_color", { color });
	}
	/**
	* Listen to a file drop event.
	* The listener is triggered when the user hovers the selected files on the webview,
	* drops the files or cancels the operation.
	*
	* @example
	* ```typescript
	* import { getCurrentWebview } from "@tauri-apps/api/webview";
	* const unlisten = await getCurrentWebview().onDragDropEvent((event) => {
	*  if (event.payload.type === 'over') {
	*    console.log('User hovering', event.payload.position);
	*  } else if (event.payload.type === 'drop') {
	*    console.log('User dropped', event.payload.paths);
	*  } else {
	*    console.log('File drop cancelled');
	*  }
	* });
	*
	* // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
	* unlisten();
	* ```
	*
	* When the debugger panel is open, the drop position of this event may be inaccurate due to a known limitation.
	* To retrieve the correct drop position, please detach the debugger.
	*
	* @returns A promise resolving to a function to unlisten to the event.
	* Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
	*/
	async onDragDropEvent(handler) {
		const unlistenDragEnter = await this.listen(TauriEvent.DRAG_ENTER, (event) => {
			handler({
				...event,
				payload: {
					type: "enter",
					paths: event.payload.paths,
					position: new PhysicalPosition(event.payload.position)
				}
			});
		});
		const unlistenDragOver = await this.listen(TauriEvent.DRAG_OVER, (event) => {
			handler({
				...event,
				payload: {
					type: "over",
					position: new PhysicalPosition(event.payload.position)
				}
			});
		});
		const unlistenDragDrop = await this.listen(TauriEvent.DRAG_DROP, (event) => {
			handler({
				...event,
				payload: {
					type: "drop",
					paths: event.payload.paths,
					position: new PhysicalPosition(event.payload.position)
				}
			});
		});
		const unlistenDragLeave = await this.listen(TauriEvent.DRAG_LEAVE, (event) => {
			handler({
				...event,
				payload: { type: "leave" }
			});
		});
		return () => {
			unlistenDragEnter();
			unlistenDragDrop();
			unlistenDragOver();
			unlistenDragLeave();
		};
	}
};
//#endregion
//#region node_modules/@tauri-apps/api/webviewWindow.js
/**
* Get an instance of `Webview` for the current webview window.
*
* @since 2.0.0
*/
function getCurrentWebviewWindow() {
	return new WebviewWindow(getCurrentWebview().label, { skip: true });
}
/**
* Gets a list of instances of `Webview` for all available webview windows.
*
* @since 2.0.0
*/
async function getAllWebviewWindows() {
	return invoke("plugin:window|get_all_windows").then((windows) => windows.map((w) => new WebviewWindow(w, { skip: true })));
}
var WebviewWindow = class WebviewWindow {
	/**
	* Creates a new {@link Window} hosting a {@link Webview}.
	* @example
	* ```typescript
	* import { WebviewWindow } from '@tauri-apps/api/webviewWindow'
	* const webview = new WebviewWindow('my-label', {
	*   url: 'https://github.com/tauri-apps/tauri'
	* });
	* webview.once('tauri://created', function () {
	*  // webview successfully created
	* });
	* webview.once('tauri://error', function (e) {
	*  // an error happened creating the webview
	* });
	* ```
	*
	* @param label The unique webview label. Must be alphanumeric: `a-zA-Z-/:_`.
	* @returns The {@link WebviewWindow} instance to communicate with the window and webview.
	*/
	constructor(label, options = {}) {
		var _a;
		this.label = label;
		this.listeners = Object.create(null);
		if (!(options === null || options === void 0 ? void 0 : options.skip)) invoke("plugin:webview|create_webview_window", { options: {
			...options,
			parent: typeof options.parent === "string" ? options.parent : (_a = options.parent) === null || _a === void 0 ? void 0 : _a.label,
			label
		} }).then(async () => this.emit("tauri://created")).catch(async (e) => this.emit("tauri://error", e));
	}
	/**
	* Gets the Webview for the webview associated with the given label.
	* @example
	* ```typescript
	* import { WebviewWindow } from '@tauri-apps/api/webviewWindow';
	* const mainWebview = WebviewWindow.getByLabel('main');
	* ```
	*
	* @param label The webview label.
	* @returns The Webview instance to communicate with the webview or null if the webview doesn't exist.
	*/
	static async getByLabel(label) {
		var _a;
		const webview = (_a = (await getAllWebviewWindows()).find((w) => w.label === label)) !== null && _a !== void 0 ? _a : null;
		if (webview) return new WebviewWindow(webview.label, { skip: true });
		return null;
	}
	/**
	* Get an instance of `Webview` for the current webview.
	*/
	static getCurrent() {
		return getCurrentWebviewWindow();
	}
	/**
	* Gets a list of instances of `Webview` for all available webviews.
	*/
	static async getAll() {
		return getAllWebviewWindows();
	}
	/**
	* Listen to an emitted event on this webview window.
	*
	* @example
	* ```typescript
	* import { WebviewWindow } from '@tauri-apps/api/webviewWindow';
	* const unlisten = await WebviewWindow.getCurrent().listen<string>('state-changed', (event) => {
	*   console.log(`Got error: ${payload}`);
	* });
	*
	* // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
	* unlisten();
	* ```
	*
	* @param event Event name. Must include only alphanumeric characters, `-`, `/`, `:` and `_`.
	* @param handler Event handler.
	* @returns A promise resolving to a function to unlisten to the event.
	* Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
	*/
	async listen(event, handler) {
		if (this._handleTauriEvent(event, handler)) return () => {
			const listeners = this.listeners[event];
			listeners.splice(listeners.indexOf(handler), 1);
		};
		return listen(event, handler, { target: {
			kind: "WebviewWindow",
			label: this.label
		} });
	}
	/**
	* Listen to an emitted event on this webview window only once.
	*
	* @example
	* ```typescript
	* import { WebviewWindow } from '@tauri-apps/api/webviewWindow';
	* const unlisten = await WebviewWindow.getCurrent().once<null>('initialized', (event) => {
	*   console.log(`Webview initialized!`);
	* });
	*
	* // you need to call unlisten if your handler goes out of scope e.g. the component is unmounted
	* unlisten();
	* ```
	*
	* @param event Event name. Must include only alphanumeric characters, `-`, `/`, `:` and `_`.
	* @param handler Event handler.
	* @returns A promise resolving to a function to unlisten to the event.
	* Note that removing the listener is required if your listener goes out of scope e.g. the component is unmounted.
	*/
	async once(event, handler) {
		if (this._handleTauriEvent(event, handler)) return () => {
			const listeners = this.listeners[event];
			listeners.splice(listeners.indexOf(handler), 1);
		};
		return once(event, handler, { target: {
			kind: "WebviewWindow",
			label: this.label
		} });
	}
	/**
	* Set the window and webview background color.
	*
	* #### Platform-specific:
	*
	* - **Android / iOS:** Unsupported for the window layer.
	* - **macOS / iOS**: Not implemented for the webview layer.
	* - **Windows**:
	*   - alpha channel is ignored for the window layer.
	*   - On Windows 7, alpha channel is ignored for the webview layer.
	*   - On Windows 8 and newer, if alpha channel is not `0`, it will be ignored.
	*
	* @returns A promise indicating the success or failure of the operation.
	*
	* @since 2.1.0
	*/
	async setBackgroundColor(color) {
		return invoke("plugin:window|set_background_color", { color }).then(() => {
			return invoke("plugin:webview|set_webview_background_color", { color });
		});
	}
};
applyMixins(WebviewWindow, [Window, Webview]);
/** Extends a base class by other specified classes, without overriding existing properties */
function applyMixins(baseClass, extendedClasses) {
	(Array.isArray(extendedClasses) ? extendedClasses : [extendedClasses]).forEach((extendedClass) => {
		Object.getOwnPropertyNames(extendedClass.prototype).forEach((name) => {
			var _a;
			if (typeof baseClass.prototype === "object" && baseClass.prototype && name in baseClass.prototype) return;
			Object.defineProperty(baseClass.prototype, name, (_a = Object.getOwnPropertyDescriptor(extendedClass.prototype, name)) !== null && _a !== void 0 ? _a : Object.create(null));
		});
	});
}
//#endregion
//#region host/constants/watch-widget.constants.ts
/** 小组件显示模式 */
var WATCH_WIDGET_MODE = {
	/** 常驻显示 */
	ALWAYS: "always",
	/** 鼠标离开自动隐藏（移到屏幕右下角热区唤回） */
	HOVER: "hover"
};
/** 小组件三态电源（条是否出现；条出现后的行为由 WATCH_WIDGET_MODE 决定，二者正交） */
var WATCH_WIDGET_POWER = {
	/** 关闭：不显示迷你条 */
	OFF: "off",
	/** 常驻：始终显示迷你条（原「开启」） */
	ALWAYS: "always",
	/** 智能开启：仅交易日盘中显示（盘前、盘后、非交易日自动隐藏） */
	SMART: "smart"
};
WATCH_WIDGET_POWER.OFF;
WATCH_WIDGET_MODE.ALWAYS;
//#endregion
//#region host/constants/notify.constants.ts
/**
* 应用通知（右侧浮窗）常量
*
* 全部为「够用且克制」的值：浮窗是打断性 UI，同屏条数与存活时长都必须收敛
*/
/** 浮窗语气：中性 / 上涨语义 / 下跌语义 / 主色（信息类） */
var NOTIFY_TONE = {
	/** 中性（一般信息） */
	FLAT: "flat",
	/** 上涨语义色（A 股默认红；随 data-trend 主题切换） */
	UP: "up",
	/** 下跌语义色（A 股默认绿；随 data-trend 主题切换） */
	DOWN: "down",
	/** 品牌主色（纯信息提示，不表达涨跌） */
	PRIMARY: "primary"
};
//#endregion
//#region plugins/dsh-sidebar-watch/candidates.ts
/**
* 过滤出「仍在自选股里」的候选
*
* 候选池是用户逐只点出来的，但自选股会被删（删单只 / 删分组 / 清空）：
* 面板只渲染候选池与当前自选股的交集 —— 已删掉的票自然从面板消失，
* 既不会出现「盯盘里还挂着一只已不在自选的票」这种迷惑状态，
* 也不会因为取不到行情 / 名称而报错。
*
* 库里那条候选记录**保留**（不静默删数据）：用户重新把票加回自选，标记即自动恢复。
* @param candidates 候选池（按加入顺序）
* @param watchlistSymbols 当前自选股符号列表
* @returns 仍有效的候选（保持原顺序）
*/
var filterCandidatesByWatchlist = (candidates, watchlistSymbols) => {
	const known = new Set(watchlistSymbols);
	return candidates.filter((candidate) => known.has(candidate.symbol));
};
//#endregion
//#region host/plugins/watch-widget/constants.ts
/**
* 插件 dsh-watch-widget · 私有常量
*
* 窗口 label / 尺寸 / 事件名 / 显隐策略阈值全部集中于此。
* 本插件的常量会被小组件独立入口（`src/widget/`）跨目录复用 —— 两端共享同一份
* 事件名与路由参数是事件协议的一部分，不能各自写字面量。
*/
/** 盯盘条窗口 label（capabilities 按此授权；全局唯一） */
var WATCH_WIDGET_WINDOW_LABEL = "watch-widget";
/** 浮窗提醒的来源标签（创建失败等插件级提示用） */
var WATCH_WIDGET_NOTIFY_SOURCE = "任务栏小组件";
/** 气泡窗口 label（capabilities 按此授权；全局唯一） */
var WATCH_WIDGET_POPOVER_LABEL = "watch-widget-popover";
/** 独立入口的视图路由参数名（`watch-widget.html?page=…`） */
var WATCH_WIDGET_PAGE_PARAM = "page";
/** 盯盘条视图路由 */
var WATCH_WIDGET_BAR_ROUTE = "/watch-widget";
/** 气泡视图路由 */
var WATCH_WIDGET_POPOVER_ROUTE = "/watch-widget-popover";
/** 盯盘条窗口加载地址（独立多页入口，规避 SPA 子路径回退问题） */
var WATCH_WIDGET_WINDOW_URL = `watch-widget.html?${WATCH_WIDGET_PAGE_PARAM}=${WATCH_WIDGET_BAR_ROUTE}`;
/** 气泡窗口加载地址 */
var WATCH_WIDGET_POPOVER_WINDOW_URL = `watch-widget.html?${WATCH_WIDGET_PAGE_PARAM}=${WATCH_WIDGET_POPOVER_ROUTE}`;
/** 跨窗口事件名（主窗口 ⇄ 小组件窗口的通信协议） */
var WATCH_WIDGET_EVENTS = {
	/** 主窗口 → 小组件窗口：轮播行载荷（条与气泡共用同一事件） */
	LINES: "watch-widget://lines",
	/** 小组件窗口 → 主窗口：请求当前快照（挂载即拉一次，免等下一轮轮询） */
	REQUEST: "watch-widget://request",
	/** 盯盘条 → 主窗口：切换气泡显隐（气泡「收起」按钮同走此事件） */
	POPOVER_TOGGLE: "watch-widget://popover-toggle",
	/** 盯盘条 → 主窗口：条被拖动（实时携带物理坐标；主窗口负责气泡跟随与落点记忆） */
	BAR_MOVED: "watch-widget://bar-moved",
	/** 条 / 气泡 → 主窗口：打开某只股票（唤起主窗口 + 跳详情页，左列=盯盘候选） */
	OPEN_STOCK: "watch-widget://open-stock",
	/**
	* 主窗口 → 小组件窗口：主题三要素（明暗 / 主题色 / 涨跌配色）实时同步。
	* 不走 storage 事件 —— WebView2 跨窗口 storage 事件在实测中不可靠，
	* 主题跟随必须走与行情数据同一条已验证的事件通道。
	*/
	THEME: "watch-widget://theme"
};
//#endregion
//#region host/constants/plugin.constants.ts
/** 插件运行时状态 */
var PLUGIN_STATUS = {
	/** 已挂载（贡献点全部生效） */
	MOUNTED: "mounted",
	/** 挂载中：apply 返回了 Promise，尚未完成 */
	MOUNTING: "mounting",
	/** 等待依赖：inject 声明的插件尚未挂载 */
	PENDING: "pending",
	/** 被用户禁用（持久化黑名单命中，或依赖被禁用） */
	DISABLED: "disabled",
	/** 挂载失败（apply 抛错，贡献点已回滚） */
	FAILED: "failed"
};
PLUGIN_STATUS.MOUNTED, PLUGIN_STATUS.MOUNTING, PLUGIN_STATUS.PENDING, PLUGIN_STATUS.DISABLED, PLUGIN_STATUS.FAILED;
PLUGIN_STATUS.MOUNTED, PLUGIN_STATUS.MOUNTING, PLUGIN_STATUS.PENDING, PLUGIN_STATUS.DISABLED, PLUGIN_STATUS.FAILED;
/**
* 顶栏轮播行的语义色调
*
* 与涨跌语义色完全同源（红涨绿跌跟随 `data-trend` 主题）：插件只声明「这是什么语气」，
* 具体色值由宿主在 `constants/header.constants.ts` 里映射，插件不碰色值。
*/
var HEADER_MARQUEE_TONE = {
	/** 中性（默认）：次级信息，如「2 只待触发」 */
	DEFAULT: "default",
	/** 涨向：红色（跟随涨跌主题） */
	UP: "up",
	/** 跌向：绿色（跟随涨跌主题） */
	DOWN: "down",
	/** 平盘：中性灰 */
	FLAT: "flat",
	/** 品牌主色：提示 / 强调 */
	PRIMARY: "primary"
};
//#endregion
//#region plugins/dsh-sidebar-watch/constants.ts
/**
* 轮播语气（与宿主 `HEADER_MARQUEE_TONE` 同字面量）
*
* 本插件以单文件产物分发，拿不到宿主的常量对象，因此这里私有一份**字面量**：
* 值不一致会在类型层（`satisfies`）直接报错，不会等到运行时才发现轮播不上色。
*/
var WATCH_MARQUEE_TONE = {
	UP: "up",
	DOWN: "down",
	FLAT: "flat"
};
/**
* 涨跌方向 → 轮播行色调
*
* 插件只声明语气（涨 / 跌 / 平），具体色值由宿主按涨跌主题映射
* （见 `constants/header.constants.ts` 的 HEADER_MARQUEE_TONE_CLASS）。
*/
var WATCH_MARQUEE_TONE_BY_TREND = {
	up: WATCH_MARQUEE_TONE.UP,
	down: WATCH_MARQUEE_TONE.DOWN,
	flat: WATCH_MARQUEE_TONE.FLAT
};
/** 阈值类型 */
var WATCH_ALERT_KIND = {
	/** 未设阈值 */
	NONE: "",
	/** 按价格设阈值（元） */
	PRICE: "price",
	/** 按涨跌幅设阈值（%） */
	CHANGE: "change"
};
/** 阈值比较方向 */
var WATCH_ALERT_DIRECTION = {
	/** 涨到 / 达到或超过 */
	ABOVE: "above",
	/** 跌到 / 达到或低于 */
	BELOW: "below"
};
WATCH_ALERT_KIND.NONE, WATCH_ALERT_KIND.PRICE, WATCH_ALERT_KIND.CHANGE;
WATCH_ALERT_DIRECTION.ABOVE, WATCH_ALERT_DIRECTION.BELOW;
WATCH_ALERT_DIRECTION.ABOVE, WATCH_ALERT_DIRECTION.BELOW;
/**
* 阈值提醒的语气（与宿主 `NOTIFY_TONE` 同字面量）
*
* 只用到涨 / 跌两个：提醒语气跟的是**触发方向**（设了「跌到」就是坏消息），
* 与当日涨跌无关。
*/
var WATCH_ALERT_TONE = {
	UP: "up",
	DOWN: "down"
};
WATCH_ALERT_TONE.UP, WATCH_ALERT_TONE.DOWN;
//#endregion
//#region plugins/dsh-sidebar-watch/alerts.ts
/**
* 自选盯盘插件 · 阈值提醒规则（纯函数层）
*
* 抽成纯函数的原因：阈值判定是本插件最容易出错、也最值得回归保护的部分 ——
* 「什么时候该提醒、什么时候该闭嘴」全在这里，与报价来源、DB、UI 都无关，
* 因此可以被冒烟断言直接覆盖（见 `.ai/tmp/watch-alerts-smoke.mjs`）。
*
* 生命周期的核心是 **armed（待触发）** 两态：
* - `armed = true`：条件满足就提醒，提醒后转 false；
* - `armed = false`：闭嘴，直到价格回到阈值**内侧**并越过回差（防抖动刷屏）才转回 true。
*
* 「内侧」= 与触发方向相反的一侧：涨到型阈值的条件是 `≥`，回到 `<` 即内侧。
*
* 另有一处易错点：用户填的涨跌幅是**幅度**（恒正），方向由「涨幅/跌幅达到」表达，
* 因此比较前必须先把阈值解析成带符号的值 —— 见 `resolveAlertThreshold`。
*/
/**
* 规则是否已配置完整（类型非空且数值有限）
* @param rule 阈值规则
* @returns 是否已配置
*/
var isAlertConfigured = (rule) => rule.kind !== WATCH_ALERT_KIND.NONE && rule.value !== null && Number.isFinite(rule.value);
//#endregion
//#region plugins/dsh-sidebar-watch/marquee.ts
/**
* 插件 dsh-sidebar-watch · 顶栏轮播行
*
* 顶栏收起态展示的那一条「名称 现价 涨跌幅」，由这里构造。
*
* 单独成文件的原因：**它是纯函数**（只依赖几个纯 utils，不碰 pinia、不碰网络），
* 因此可以被冒烟脚本直跑 —— 文案格式与语气（涨 / 跌 / 平）一旦错了，
* 顶栏那条轮播就会长期挂着错信息，而它恰恰是用户扫得最多的一行。
* 引擎（monitor.ts）负责取数与判阈值，展示口径放在这里，各自单一职责。
*/
/**
* 造顶栏轮播行（收起态逐条展示的那一行：名称 + 现价 + 涨跌幅）
*
* **不做过滤**：还没取到报价的候选也出行（价格 / 涨跌幅用 `--` 占位）——
* 新加的票要立刻在轮播里露脸，而不是等引擎补拉完报价才出现；
* 占位只是暂时的，引擎对新候选会补一轮报价（见 monitor.ts），到时自动换成真实数字。
*
* @param candidates 候选（已过滤为仍在自选股里的）
* @param quotes 报价快照（key 为上游原始 `code`，查询走 `format.findQuote`）
* @param format 宿主格式化服务（价格 / 百分比 / 涨跌语气，口径只有宿主一份）
* @returns 轮播行（保持候选池顺序）
*/
var buildMarqueeLines = (candidates, quotes, format) => {
	const lines = [];
	for (const candidate of candidates) {
		const quote = format.findQuote(quotes, candidate.symbol);
		const name = quote?.name || candidate.name;
		const price = format.price(quote?.price ?? null);
		const percent = format.percent(quote?.changePercent ?? null);
		lines.push({
			text: [
				name,
				price,
				percent
			].join(" "),
			label: name,
			price,
			percent,
			tone: WATCH_MARQUEE_TONE_BY_TREND[format.trend(quote?.changePercent ?? 0)]
		});
	}
	return lines;
};
//#endregion
//#region plugins/dsh-watch-widget/presenter.ts
/**
* 插件 dsh-watch-widget · 展示载荷构造（纯函数）
*
* 与 dsh-sidebar-watch 的 marquee.ts 同一思路：文案与口径一旦错了，
* 小组件就是用户扫得最多的那行字，因此构造逻辑独立成纯函数、可被冒烟直跑。
* 数据全部来自主窗口既有盯盘引擎的快照 —— 小组件窗口自身不发任何上游请求。
*
* 格式化与符号归一化一律走宿主 `app:format`（口径只有宿主一份）；
* 上下文列表的 symbol 交给 `app:stock-open` 宿主侧归一化，这里保持原样。
*/
/**
* 构造小组件轮播行（顶栏轮播同一份口径：名称 + 现价 + 涨跌幅 + 语气）
*
* 行与候选按下标一一对应（buildMarqueeLines 不做过滤、保持候选顺序），
* symbol / 阈值触发态从候选侧补齐 —— 顶栏轮播行本身不带这两个交互字段。
* @param candidates 候选（已过滤为仍在自选股里的）
* @param quotes 报价快照（key 为上游原始 `code`，查询走 `format.findQuote`）
* @param format 宿主格式化服务（价格 / 百分比 / 涨跌语气，口径只有宿主一份）
* @returns 小组件载荷行（保持候选池顺序）
*/
var buildWatchWidgetRows = (candidates, quotes, format) => {
	return buildMarqueeLines(candidates, quotes, format).map((line, index) => {
		const candidate = candidates[index];
		return {
			symbol: candidate?.symbol ?? "",
			name: line.label ?? line.text,
			price: line.price ?? "--",
			percent: line.percent ?? "--",
			tone: line.tone ?? HEADER_MARQUEE_TONE.FLAT,
			fired: Boolean(candidate && isAlertConfigured(candidate.alert) && !candidate.alert.armed)
		};
	});
};
/**
* 构造详情页左侧上下文列表（= 盯盘候选，与顶栏下拉「跳详情整页」同一口径）
*
* symbol 交给 `app:stock-open` 的宿主侧归一化（契约注释明确），这里保持候选原值；
* 名称与价格从报价快照补齐，快照未覆盖时回退候选自身字段。
* @param candidates 候选（已过滤为仍在自选股里的）
* @param quotes 报价快照
* @param format 宿主格式化服务（按本地符号查报价）
* @returns 上下文股票列表
*/
var buildWatchContextList = (candidates, quotes, format) => candidates.map((candidate) => {
	const quote = format.findQuote(quotes, candidate.symbol);
	return {
		symbol: candidate.symbol,
		name: quote?.name || candidate.name,
		price: quote?.price ?? null,
		changePercent: quote?.changePercent ?? null
	};
});
//#endregion
//#region plugins/dsh-watch-widget/windows.ts
/**
* 插件 dsh-watch-widget · 小组件窗口管理
*
* 两个无边框置顶窗口（盯盘条 / 气泡）的创建、停靠定位与尺寸计算。
* 这些函数只在**主窗口侧**调用：窗口操控类权限挂在主窗口的 capability 上，
* 小组件窗口自身只保留「事件收发 + 条窗口拖拽」的最小权限。
*
* 坐标系约定：Tauri 的窗口构造 x / y、outerPosition / outerSize、cursorPosition
* 与 Rust 侧 SPI_GETWORKAREA 全部是**物理像素**；窗口 width / height 与 setSize
* 是**逻辑像素** —— 换算只发生在「逻辑尺寸 × 缩放比」这一处。
*
* 契约化说明：窗口常量（label / 尺寸 / URL）与渲染端（宿主 `src/widget/`）共享
* 同一份事实源（宿主 `src/plugins/watch-widget/constants.ts`），经宿主契约快照
* 引用 —— 事件名与 label 写岔任何一边，窗口就静默失联。
*/
/**
* 读取主屏工作区（物理像素）
*
* 优先走 Rust `get_work_area`（SPI_GETWORKAREA，精确剔除任务栏）；
* 命令不可用（旧后端 / 非 Windows）时回退「主屏尺寸 - 48px 任务栏」启发式。
* @returns 工作区矩形
*/
var getWorkArea = async () => {
	try {
		const area = await invoke("get_work_area");
		if (area && area.every((value) => Number.isFinite(value))) return {
			left: area[0],
			top: area[1],
			right: area[2],
			bottom: area[3]
		};
	} catch {}
	const monitor = await currentMonitor() ?? await primaryMonitor();
	if (!monitor) throw new Error("watch-widget: 无可用显示器");
	return {
		left: monitor.position.x,
		top: monitor.position.y,
		right: monitor.position.x + monitor.size.width,
		bottom: monitor.position.y + monitor.size.height - 48
	};
};
/**
* 计算盯盘条默认停靠位（工作区右下角，物理像素）
* @param scaleFactor 显示缩放比（逻辑尺寸 → 物理尺寸的换算系数）
* @returns 物理坐标
*/
var computeDockedBarPosition = async (scaleFactor) => {
	const area = await getWorkArea();
	const width = Math.round(288 * scaleFactor);
	const height = Math.round(30 * scaleFactor);
	const margin = Math.round(8 * scaleFactor);
	return {
		x: area.right - width - margin,
		y: area.bottom - height - margin
	};
};
/**
* 读取窗口的物理矩形（位置 + 尺寸；鼠标靠近判定用）
* @param win 目标窗口
* @returns 物理矩形
*/
var getWindowRect = async (win) => {
	const [position, size] = await Promise.all([win.outerPosition(), win.outerSize()]);
	return {
		x: position.x,
		y: position.y,
		width: size.width,
		height: size.height
	};
};
/**
* 判断物理坐标是否落在矩形内（允许外扩 padding，给鼠标判定留容差）
* @param rect 矩形（null 视为不在任何矩形内）
* @param x 物理像素 x
* @param y 物理像素 y
* @param padding 外扩像素
* @returns 是否在矩形内
*/
var rectContains = (rect, x, y, padding = 0) => rect !== null && x >= rect.x - padding && x <= rect.x + rect.width + padding && y >= rect.y - padding && y <= rect.y + rect.height + padding;
/**
* 解析盯盘条初始位置：优先用户记忆位置，但落点必须仍在工作区内
* （换显示器 / 改分辨率 / 缩放比变化后，记忆位置可能在屏幕外 —— 此时回退停靠位）
* @param savedPosition 用户拖动后记忆的位置（物理像素；null = 停靠右下角）
* @param monitor 目标显示器（取缩放比）
* @returns 物理坐标
*/
var resolveBarPosition = async (savedPosition, monitor) => {
	const docked = await computeDockedBarPosition(monitor.scaleFactor);
	if (!savedPosition) return docked;
	const area = await getWorkArea();
	const width = Math.round(288 * monitor.scaleFactor);
	const height = Math.round(30 * monitor.scaleFactor);
	return savedPosition.x >= area.left - width && savedPosition.x <= area.right && savedPosition.y >= area.top - height && savedPosition.y <= area.bottom ? savedPosition : docked;
};
/**
* 创建盯盘条窗口（隐藏创建 → 定位 → 显示；已存在则直接显示）
*
* `focusable: false` 是摸鱼刚需：点击条 / 气泡都不会把焦点从工作窗口抢走。
* @param savedPosition 用户拖动后记忆的位置（物理像素；null = 停靠右下角）
* @returns 窗口句柄；创建失败返回 null（调用方降级为不启用）
*/
var openBarWindow = async (savedPosition) => {
	const existing = await WebviewWindow.getByLabel(WATCH_WIDGET_WINDOW_LABEL);
	if (existing) {
		await existing.show().catch(() => void 0);
		return existing;
	}
	const monitor = await currentMonitor() ?? await primaryMonitor();
	if (!monitor) return null;
	const position = await resolveBarPosition(savedPosition, monitor);
	return await new Promise((resolve) => {
		const win = new WebviewWindow(WATCH_WIDGET_WINDOW_LABEL, {
			url: WATCH_WIDGET_WINDOW_URL,
			title: "盯盘小组件",
			width: 288,
			height: 30,
			decorations: false,
			transparent: true,
			alwaysOnTop: true,
			skipTaskbar: true,
			resizable: false,
			focusable: false,
			shadow: false,
			visible: false
		});
		win.once("tauri://created", () => {
			(async () => {
				await win.setPosition(new PhysicalPosition(position.x, position.y)).catch(() => void 0);
				await win.show().catch(() => void 0);
				resolve(win);
			})();
		});
		win.once("tauri://error", (event) => {
			console.error("[watch-widget] 盯盘条创建失败", event);
			resolve(null);
		});
	});
};
/**
* 创建气泡窗口（隐藏态创建一次复用；尺寸与位置在每次展开前按行数设定）
* @returns 窗口句柄；创建失败返回 null
*/
var openPopoverWindow = async () => {
	const existing = await WebviewWindow.getByLabel(WATCH_WIDGET_POPOVER_LABEL);
	if (existing) return existing;
	return await new Promise((resolve) => {
		const win = new WebviewWindow(WATCH_WIDGET_POPOVER_LABEL, {
			url: WATCH_WIDGET_POPOVER_WINDOW_URL,
			title: "盯盘候选",
			x: 0,
			y: 0,
			width: 288,
			height: 74,
			decorations: false,
			transparent: true,
			alwaysOnTop: true,
			skipTaskbar: true,
			resizable: false,
			focusable: false,
			shadow: false,
			visible: false
		});
		win.once("tauri://created", () => resolve(win));
		win.once("tauri://error", (event) => {
			console.error("[watch-widget] 气泡创建失败", event);
			resolve(null);
		});
	});
};
/**
* 计算气泡相对盯盘条的停靠布局（右对齐、条正上方）
*
* 拆成独立纯查询函数：`positionPopover`（展开时，含尺寸）与
* `movePopoverToBar`（拖动跟随，只平移不改尺寸）共用同一份几何口径，
* 保证两条路径算出的落点一致。
* @param bar 盯盘条窗口（定位基准）
* @param rowCount 当前行数（决定气泡高度，封顶 MAX_ROWS）
* @returns 气泡布局
*/
var computePopoverLayout = async (bar, rowCount) => {
	const [barPosition, barSize, scaleFactor] = await Promise.all([
		bar.outerPosition(),
		bar.outerSize(),
		bar.scaleFactor()
	]);
	const logicalHeight = 40 + Math.min(Math.max(rowCount, 1), 12) * 34 + 6;
	const height = Math.round(logicalHeight * scaleFactor);
	const width = Math.round(288 * scaleFactor);
	return {
		x: barPosition.x + barSize.width - width,
		y: barPosition.y - height - Math.round(6 * scaleFactor),
		logicalHeight
	};
};
/**
* 把气泡定位到盯盘条正上方（右对齐），并按行数设定尺寸（展开时用）
* @param popover 气泡窗口
* @param bar 盯盘条窗口（定位基准）
* @param rowCount 当前行数（决定气泡高度，封顶 MAX_ROWS）
*/
var positionPopover = async (popover, bar, rowCount) => {
	const layout = await computePopoverLayout(bar, rowCount);
	await popover.setSize(new LogicalSize(288, layout.logicalHeight));
	await popover.setPosition(new PhysicalPosition(layout.x, layout.y));
};
/**
* 拖动跟随：把气泡平移到盯盘条正上方（不改尺寸；条拖动期间高频调用）
* @param popover 气泡窗口
* @param bar 盯盘条窗口（定位基准）
* @param rowCount 当前行数（跟随期间行数不变，仅用于几何口径一致）
*/
var movePopoverToBar = async (popover, bar, rowCount) => {
	const layout = await computePopoverLayout(bar, rowCount);
	await popover.setPosition(new PhysicalPosition(layout.x, layout.y));
};
//#endregion
//#region plugins/dsh-watch-widget/plugin.ts
/**
* 插件 dsh-watch-widget · 任务栏盯盘小组件
*
* 把顶栏「自选盯盘」的轮播内容常驻成 **Windows 任务栏上方的置顶迷你条**
* （摸鱼场景：上班时不开炒股软件也能一眼扫到自选盯盘标的）。架构上三件事：
*
* - **数据零冗余**：本插件不发任何上游请求。声明 `inject: ['watch:repo', 'watch:monitor']`
*   等盯盘插件就绪后消费**同一份引擎实例**的报价快照（第二份引擎会导致上游请求
*   翻倍 + 阈值 armed 状态双写，见 dsh-sidebar-watch/monitor.ts）；
*   快照经 Tauri 事件 `watch-widget://lines` 推给小组件窗口，窗口是纯渲染端
*   （渲染端是宿主 `src/widget/` 独立轻量入口，不属于本插件产物）。
* - **宿主能力全走服务**：配置（`app:watch-widget-settings`，UI 与持久化归宿主
*   设置页）、盘中判定（`app:market-status`）、主题（`app:theme`）、自选股
*   （`app:watchlist`）、打开个股（`app:stock-open`）、格式化（`app:format`）、
*   浮窗（`app:notify`，可降级）。窗口 API 经 @tauri-apps/api 打进本产物。
* - **摸鱼交互**：条与气泡都 `focusable: false`（点击不抢工作窗口焦点）；
*   hover 模式下鼠标离开自动隐藏、移到屏幕右下角热区唤回；
*   单击条展开气泡看全部候选，点气泡标的 / 双击条上标的 → 唤起主窗口并跳
*   股票详情整页（左侧列表 = 盯盘候选，经 app:stock-open 携带上下文）。
*/
/** 必需宿主服务缺失时的统一报错文案 */
var MISSING_SERVICES_HINT = "宿主未提供 app:watchlist / app:stock-open / app:market-status / app:watch-widget-settings / app:theme / app:format 服务";
/**
* 任务栏盯盘小组件插件定义
*/
var watchWidgetPlugin = {
	id: "dsh-watch-widget",
	name: "任务栏盯盘小组件",
	version: "1.0.0",
	description: "在 Windows 任务栏上方常驻一个置顶盯盘迷你条（设置里三态选择，默认关：关闭 / 常驻 / 智能开启，智能开启仅交易日盘中显示）：轮播自选盯盘标的的名称 / 现价 / 涨跌幅，阈值触发带提示点；单击迷你条展开气泡看全部候选，点气泡里的标的（或双击迷你条当前标的）自动唤起主窗口并打开该股详情页（左侧列表即盯盘候选）。支持常驻显示 / 鼠标离开自动隐藏两种模式；仅桌面端，迷你条自身不产生任何行情请求。",
	author: "内置",
	inject: ["watch:repo", "watch:monitor"],
	apply: async (ctx) => {
		if (!isTauri()) {
			ctx.logger.info("非 Tauri 环境，任务栏小组件不挂载");
			return;
		}
		const repo = ctx.consume("watch:repo");
		const monitor = ctx.consume("watch:monitor");
		if (!repo || !monitor) {
			ctx.logger.warn("盯盘服务未就绪，任务栏小组件跳过");
			return;
		}
		const watchlist = ctx.consume("app:watchlist");
		const stockOpen = ctx.consume("app:stock-open");
		const marketStatus = ctx.consume("app:market-status");
		const widgetSettings = ctx.consume("app:watch-widget-settings");
		const theme = ctx.consume("app:theme");
		const format = ctx.consume("app:format");
		if (!watchlist || !stockOpen || !marketStatus || !widgetSettings || !theme || !format) throw new Error(MISSING_SERVICES_HINT);
		const notify = ctx.consume("app:notify");
		/** 监控中的候选（候选池 ∩ 自选股，与顶栏轮播同一口径） */
		const candidates = computed(() => filterCandidatesByWatchlist(repo.list(), watchlist.symbols()));
		/** 推送给小组件窗口的展示行（引擎报价一变即重算） */
		const rows = computed(() => buildWatchWidgetRows(candidates.value, monitor.quotes.value, format));
		let barWindow = null;
		let popoverWindow = null;
		let barVisible = false;
		let popoverVisible = false;
		/**
		* 光标是否在「本次显示之后」到访过条 / 气泡
		*
		* hover 模式的隐藏以它为前提：条刚出现（或刚被角落热区唤回）时用户还没看过它，
		* 立刻隐藏等于「永远看不到」—— 必须先 hover 到访一次、再离开，超时才隐藏。
		*/
		let cursorArmed = false;
		/** 条 / 气泡的物理矩形（鼠标靠近判定用；窗口显隐、拖动后刷新） */
		let barRect = null;
		let popoverRect = null;
		/** hover 模式的唤回热区（工作区右下角；停靠定位后计算一次） */
		let revealZone = null;
		/** 把当前快照推给条 / 气泡（两个窗口都不存在时跳过） */
		const pushLines = () => {
			if (!barWindow && !popoverWindow) return;
			emit(WATCH_WIDGET_EVENTS.LINES, { rows: rows.value });
		};
		ctx.effect(() => watch(rows, pushLines, { immediate: true }));
		/**
		* 主窗口主题三要素变化即广播给条 / 气泡。
		* 不依赖 storage 事件：WebView2 跨窗口 storage 事件实测不可达，
		* 主题跟随与行情数据共用同一条已验证的事件通道。
		*/
		ctx.effect(() => watch([
			theme.isDark,
			theme.themeColor,
			theme.trendTheme
		], ([dark, color, trend]) => {
			if (!barWindow && !popoverWindow) return;
			emit(WATCH_WIDGET_EVENTS.THEME, {
				dark,
				theme: color,
				trend
			});
		}, { immediate: true }));
		const showPopover = async () => {
			if (!barWindow) return;
			if (!popoverWindow) popoverWindow = await openPopoverWindow();
			if (!popoverWindow) return;
			await positionPopover(popoverWindow, barWindow, rows.value.length);
			popoverRect = await getWindowRect(popoverWindow);
			await popoverWindow.show().catch(() => void 0);
			popoverVisible = true;
		};
		const hidePopover = async () => {
			if (!popoverWindow || !popoverVisible) return;
			await popoverWindow.hide().catch(() => void 0);
			popoverVisible = false;
		};
		const togglePopover = async () => {
			if (popoverVisible) await hidePopover();
			else await showPopover();
		};
		const destroyWindows = async () => {
			await hidePopover();
			if (popoverWindow) {
				popoverWindow.close().catch(() => void 0);
				popoverWindow = null;
				popoverVisible = false;
				popoverRect = null;
			}
			if (barWindow) {
				barWindow.close().catch(() => void 0);
				barWindow = null;
				barVisible = false;
				barRect = null;
				revealZone = null;
			}
		};
		const ensureBar = async () => {
			if (barWindow) {
				await barWindow.show().catch(() => void 0);
				barVisible = true;
				return;
			}
			barWindow = await openBarWindow(widgetSettings.settings.value.position);
			if (!barWindow) {
				ctx.logger.warn("盯盘条创建失败（多为 capabilities 未重编译），请重启应用重试");
				notify?.notify({
					title: "任务栏小组件创建失败",
					body: "多为窗口权限未随构建生效：重启应用后重新开启即可",
					tone: NOTIFY_TONE.DOWN,
					source: WATCH_WIDGET_NOTIFY_SOURCE,
					dedupeKey: WATCH_WIDGET_NOTIFY_SOURCE
				});
				return;
			}
			barVisible = true;
			cursorArmed = false;
			barRect = await getWindowRect(barWindow);
			try {
				const area = await getWorkArea();
				revealZone = {
					x: area.right - 160,
					y: area.bottom - 160,
					width: 160,
					height: 160
				};
			} catch {
				revealZone = null;
			}
			pushLines();
		};
		/** 三态电源 → 条是否应显示（智能态叠加盘中判定；tick 每分钟重算，跨界自动隐现） */
		const shouldShowBar = computed(() => {
			const power = widgetSettings.settings.value.power;
			if (power === WATCH_WIDGET_POWER.OFF) return false;
			if (power === WATCH_WIDGET_POWER.ALWAYS) return true;
			return marketStatus.isIntraday.value;
		});
		ctx.effect(() => watch(shouldShowBar, (show) => {
			if (show) ensureBar();
			else destroyWindows();
		}, { immediate: true }));
		const openStockInMain = (symbol) => {
			if (!symbol) return;
			hidePopover();
			const main = getCurrentWebviewWindow();
			main.show().then(() => main.unminimize()).then(() => main.setFocus()).catch(() => void 0);
			stockOpen.openPage(symbol, buildWatchContextList(candidates.value, monitor.quotes.value, format));
		};
		const unlistens = [];
		/** 气泡跟随条拖动的节流时间戳（条拖动期间 onMoved 高频到达，只按间隔摆位） */
		let lastFollowAt = 0;
		/** 拖动落点记忆的防抖句柄（超过 SETTLE 窗口无新位置才落库 + 精确校正一次） */
		let settleTimer;
		unlistens.push(await listen(WATCH_WIDGET_EVENTS.REQUEST, () => {
			pushLines();
		}));
		unlistens.push(await listen(WATCH_WIDGET_EVENTS.POPOVER_TOGGLE, () => {
			togglePopover();
		}));
		unlistens.push(await listen(WATCH_WIDGET_EVENTS.BAR_MOVED, (event) => {
			if (barWindow) getWindowRect(barWindow).then((rect) => {
				barRect = rect;
			});
			const now = Date.now();
			const popoverLive = popoverWindow;
			const barLive = barWindow;
			if (popoverVisible && popoverLive && barLive && now - lastFollowAt >= 50) {
				lastFollowAt = now;
				movePopoverToBar(popoverLive, barLive, rows.value.length).then(() => getWindowRect(popoverLive).then((rect) => {
					popoverRect = rect;
				}));
			}
			if (settleTimer) window.clearTimeout(settleTimer);
			settleTimer = window.setTimeout(() => {
				settleTimer = void 0;
				widgetSettings.set({ position: {
					x: event.payload.x,
					y: event.payload.y
				} });
				const popover = popoverWindow;
				const bar = barWindow;
				if (popoverVisible && popover && bar) positionPopover(popover, bar, rows.value.length).then(() => getWindowRect(popover).then((rect) => {
					popoverRect = rect;
				}));
			}, 300);
		}));
		unlistens.push(await listen(WATCH_WIDGET_EVENTS.OPEN_STOCK, (event) => {
			openStockInMain(event.payload.symbol);
		}));
		let lastInsideAt = Date.now();
		const cursorTimer = window.setInterval(() => {
			if (!barWindow) return;
			(async () => {
				let cursor;
				try {
					cursor = await cursorPosition();
				} catch {
					return;
				}
				if (rectContains(barRect, cursor.x, cursor.y, 4) || rectContains(popoverRect, cursor.x, cursor.y, 4)) {
					lastInsideAt = Date.now();
					cursorArmed = true;
					return;
				}
				if (!barVisible && revealZone && rectContains(revealZone, cursor.x, cursor.y)) {
					await barWindow.show().catch(() => void 0);
					barVisible = true;
					cursorArmed = false;
					lastInsideAt = Date.now();
					return;
				}
				const config = widgetSettings.settings.value;
				if (barVisible && cursorArmed && config.mode === WATCH_WIDGET_MODE.HOVER && Date.now() - lastInsideAt >= config.hideDelaySec * 1e3) {
					await barWindow.hide().catch(() => void 0);
					barVisible = false;
					cursorArmed = false;
					await hidePopover();
				}
			})();
		}, 600);
		ctx.onDispose(() => {
			window.clearInterval(cursorTimer);
			if (settleTimer) window.clearTimeout(settleTimer);
			for (const unlisten of unlistens) unlisten();
			destroyWindows();
		});
		ctx.logger.info(`任务栏小组件就绪（条 288×30、气泡宽 288，显示模式 ${widgetSettings.settings.value.mode}）`);
	}
};
//#endregion
export { watchWidgetPlugin as default, watchWidgetPlugin };
