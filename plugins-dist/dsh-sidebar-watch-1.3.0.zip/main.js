const __WHF_PLUGIN_RUNTIME__ = globalThis.__WHF_PLUGIN_RUNTIME__;
if (!__WHF_PLUGIN_RUNTIME__?.vue) {
  throw new Error('宿主运行时桥不可用：__WHF_PLUGIN_RUNTIME__（插件必须在该版本宿主里安装）');
}
const { Fragment, computed, createBlock, createCommentVNode, createElementBlock, createElementVNode, createTextVNode, defineComponent, effectScope, normalizeClass, openBlock, ref, renderList, resolveDynamicComponent, shallowRef, toDisplayString, unref, watch, withCtx, withModifiers } = __WHF_PLUGIN_RUNTIME__.vue;
//#region plugins/dsh-sidebar-watch/constants.ts
/** 顶栏条目 id（内核会拼成 `dsh-sidebar-watch#<id>` 全局键） */
var WATCH_HEADER_ITEM_ID = "watch";
/** 顶栏条目名（触发按钮提示 / 下拉面板标题；无可轮播内容时的占位文案） */
var WATCH_HEADER_ITEM_TITLE = "自选盯盘";
/** 顶栏条目图标（MenuIcon key：铃铛，与阈值提醒语义一致） */
var WATCH_HEADER_ITEM_ICON = "bell";
/** 空态引导文案（说清候选从哪来，避免用户以为面板坏了） */
var WATCH_EMPTY_HINT = "在自选股「操作」列点一下「盯盘」，这只票就会盯在这里";
/**
* 轮播语气（与宿主 `HEADER_MARQUEE_TONE` 同字面量）
*
* 本插件以单文件产物分发，拿不到宿主的常量对象，因此这里私有一份**字面量**：
* 值不一致会在类型层（`satisfies`）直接报错，不会等到运行时才发现轮播不上色。
*/
var WATCH_MARQUEE_TONE = {
	UP: "up",
	DOWN: "down",
	FLAT: "flat"
};
/**
* 涨跌方向 → 轮播行色调
*
* 插件只声明语气（涨 / 跌 / 平），具体色值由宿主按涨跌主题映射
* （见 `constants/header.constants.ts` 的 HEADER_MARQUEE_TONE_CLASS）。
*/
var WATCH_MARQUEE_TONE_BY_TREND = {
	up: WATCH_MARQUEE_TONE.UP,
	down: WATCH_MARQUEE_TONE.DOWN,
	flat: WATCH_MARQUEE_TONE.FLAT
};
/** 行操作 id（内核会拼成 `dsh-sidebar-watch#<id>` 全局键） */
var STOCK_ROW_ACTION_ID = "watch-toggle";
/** 行操作文案（未加入候选时） */
var STOCK_ROW_ACTION_TITLE = "盯盘";
/** 行操作文案（已在候选池里） */
var STOCK_ROW_ACTION_ACTIVE_TITLE = "取消盯盘";
/** 阈值类型 */
var WATCH_ALERT_KIND = {
	/** 未设阈值 */
	NONE: "",
	/** 按价格设阈值（元） */
	PRICE: "price",
	/** 按涨跌幅设阈值（%） */
	CHANGE: "change"
};
/** 阈值比较方向 */
var WATCH_ALERT_DIRECTION = {
	/** 涨到 / 达到或超过 */
	ABOVE: "above",
	/** 跌到 / 达到或低于 */
	BELOW: "below"
};
/** 阈值类型下拉选项文案 */
var WATCH_ALERT_KIND_LABEL = {
	[WATCH_ALERT_KIND.NONE]: "不提醒",
	[WATCH_ALERT_KIND.PRICE]: "价格",
	[WATCH_ALERT_KIND.CHANGE]: "涨跌幅"
};
/** 比较方向下拉选项文案（价格态） */
var WATCH_ALERT_DIRECTION_PRICE_LABEL = {
	[WATCH_ALERT_DIRECTION.ABOVE]: "涨到",
	[WATCH_ALERT_DIRECTION.BELOW]: "跌到"
};
/** 比较方向下拉选项文案（涨跌幅态） */
var WATCH_ALERT_DIRECTION_CHANGE_LABEL = {
	[WATCH_ALERT_DIRECTION.ABOVE]: "涨幅达到",
	[WATCH_ALERT_DIRECTION.BELOW]: "跌幅达到"
};
/**
* 价格阈值「重新武装」的相对回差
*
* 触发一次后不再重复提醒，直到价格回到阈值内侧并**多走这么多**才重新武装。
* 没有回差的话，价格在阈值上下抖动会触发刷屏（真实盯盘里最常见的抱怨）。
*/
var WATCH_ALERT_REARM_PRICE_RATIO = .001;
/** 涨跌幅阈值「重新武装」的绝对回差（百分点） */
var WATCH_ALERT_REARM_CHANGE_MARGIN = .1;
/** 阈值编辑器标题 */
var WATCH_ALERT_EDITOR_TITLE = "阈值提醒";
/** 阈值编辑器说明文案 */
var WATCH_ALERT_EDITOR_HINT = "到价后右下角弹提醒；触发过一次，等回到阈值内侧再重新生效";
/** 未设阈值时行内按钮的提示文案 */
var WATCH_ALERT_BUTTON_TITLE = "设阈值提醒";
/** 已设阈值时行内按钮的提示文案 */
var WATCH_ALERT_BUTTON_ACTIVE_TITLE = "调整阈值提醒";
/** 阈值输入框占位文案（价格态） */
var WATCH_ALERT_INPUT_PLACEHOLDER_PRICE = "如 1700.00";
/** 阈值输入框占位文案（涨跌幅态） */
var WATCH_ALERT_INPUT_PLACEHOLDER_CHANGE = "如 5.00";
/** 阈值提醒的浮窗来源标签（宿主用它做「同类只占一格」与插件卸载时的清场） */
var WATCH_NOTIFY_SOURCE = "盯盘提醒";
/**
* 阈值提醒的语气（与宿主 `NOTIFY_TONE` 同字面量）
*
* 只用到涨 / 跌两个：提醒语气跟的是**触发方向**（设了「跌到」就是坏消息），
* 与当日涨跌无关。
*/
var WATCH_ALERT_TONE = {
	UP: "up",
	DOWN: "down"
};
/**
* 提醒语气 → 文字色类名（与宿主 `NOTIFY_TONE_CLASS[*].label` 同口径）
*
* 直接用主题 token 类名而不是自己造色值：Tailwind 是构建期扫描的，
* 插件独有的类名没有 CSS，只有 token 类（宿主自己也在用）才一定有样式。
*/
var WATCH_ALERT_TONE_LABEL_CLASS = {
	[WATCH_ALERT_TONE.UP]: "text-up",
	[WATCH_ALERT_TONE.DOWN]: "text-down"
};
/**
* 盘中轮询间隔（毫秒）
*
* 与宿主 `POLLING_INTERVAL.QUOTES_INTRADAY` 同值：盯的是自选股现价，
* 快了没意义（上游就是这个刷新率），慢了阈值提醒会迟到。
*/
var WATCH_POLL_INTERVAL_MS = 4e3;
/** 自选股页路由（命令「打开自选股页」与面板底部入口共用） */
var WATCHLIST_ROUTE_PATH = "/watchlist";
//#endregion
//#region plugins/dsh-sidebar-watch/alerts.ts
/**
* 自选盯盘插件 · 阈值提醒规则（纯函数层）
*
* 抽成纯函数的原因：阈值判定是本插件最容易出错、也最值得回归保护的部分 ——
* 「什么时候该提醒、什么时候该闭嘴」全在这里，与报价来源、DB、UI 都无关，
* 因此可以被冒烟断言直接覆盖（见 `.ai/tmp/watch-alerts-smoke.mjs`）。
*
* 生命周期的核心是 **armed（待触发）** 两态：
* - `armed = true`：条件满足就提醒，提醒后转 false；
* - `armed = false`：闭嘴，直到价格回到阈值**内侧**并越过回差（防抖动刷屏）才转回 true。
*
* 「内侧」= 与触发方向相反的一侧：涨到型阈值的条件是 `≥`，回到 `<` 即内侧。
*
* 另有一处易错点：用户填的涨跌幅是**幅度**（恒正），方向由「涨幅/跌幅达到」表达，
* 因此比较前必须先把阈值解析成带符号的值 —— 见 `resolveAlertThreshold`。
*/
/**
* 未设阈值的规则（新增候选时的初值）
* @returns 默认规则
*/
var createEmptyAlertRule = () => ({
	kind: WATCH_ALERT_KIND.NONE,
	value: null,
	above: true,
	armed: true
});
/**
* 规则是否已配置完整（类型非空且数值有限）
* @param rule 阈值规则
* @returns 是否已配置
*/
var isAlertConfigured = (rule) => rule.kind !== WATCH_ALERT_KIND.NONE && rule.value !== null && Number.isFinite(rule.value);
/**
* 取规则当前用于比较的行情数值
* @param rule 阈值规则
* @param snapshot 行情快照
* @returns 当前值；规则未配置或行情缺值时为 null
*/
var resolveAlertCurrent = (rule, snapshot) => {
	if (!isAlertConfigured(rule)) return null;
	const current = rule.kind === WATCH_ALERT_KIND.PRICE ? snapshot.price : snapshot.changePercent;
	return current === null || current === void 0 || Number.isNaN(current) ? null : current;
};
/**
* 把规则里的「用户填的数值」解析成**带符号的比较阈值**
*
* 这是本模块最容易写错的一处，必须说清楚：
* - **价格**阈值本身就是价位，用户填正的、比较也用它（`跌到 28.50` = `price <= 28.50`）；
* - **涨跌幅**阈值用户填的是**幅度**（恒为正，方向由「涨幅达到 / 跌幅达到」表达），
*   所以 `跌幅达到 3%` 的真实含义是 `changePercent <= -3` —— 阈值取负号。
*
* 曾经漏掉这个取负，`跌幅达到 3%` 被算成 `changePercent <= 3`（几乎恒成立），
* 表现为「一设就疯狂提醒」。这也是本模块必须被冒烟断言覆盖的原因。
* @param rule 阈值规则
* @returns 带符号阈值；规则未配置时为 null
*/
var resolveAlertThreshold = (rule) => {
	if (!isAlertConfigured(rule) || rule.value === null) return null;
	if (rule.kind === WATCH_ALERT_KIND.CHANGE) return rule.above ? rule.value : -rule.value;
	return rule.value;
};
/**
* 提醒条件是否满足（价格/涨跌幅达到或越过阈值）
* @param rule 阈值规则
* @param snapshot 行情快照
* @returns 条件是否满足；规则未配置或行情缺值时为 false
*/
var isAlertMet = (rule, snapshot) => {
	const current = resolveAlertCurrent(rule, snapshot);
	const threshold = resolveAlertThreshold(rule);
	if (current === null || threshold === null) return false;
	return rule.above ? current >= threshold : current <= threshold;
};
/**
* 价格是否已回到阈值内侧**并越过回差**（用于重新武装）
*
* 回差的存在是为了防抖动：价格在阈值上下小幅摆动时不必反复提醒。
* 价格阈值按相对比例取回差，涨跌幅阈值按其自身单位（百分点）取绝对回差。
* @param rule 阈值规则
* @param snapshot 行情快照
* @returns 是否应当重新武装
*/
var shouldRearmAlert = (rule, snapshot) => {
	const current = resolveAlertCurrent(rule, snapshot);
	const threshold = resolveAlertThreshold(rule);
	if (current === null || threshold === null) return false;
	const margin = rule.kind === WATCH_ALERT_KIND.PRICE ? Math.abs(threshold) * WATCH_ALERT_REARM_PRICE_RATIO : WATCH_ALERT_REARM_CHANGE_MARGIN;
	return rule.above ? current < threshold - margin : current > threshold + margin;
};
/**
* 判定一条规则在本轮行情下的动作
*
* 两个分支互斥：待触发态只看「是否该提醒」，已触发态只看「是否该重新武装」。
* @param rule 阈值规则
* @param snapshot 行情快照
* @returns 判定结果
*/
var evaluateAlert = (rule, snapshot) => {
	if (!isAlertConfigured(rule)) return {
		fire: false,
		rearm: false
	};
	if (rule.armed) return {
		fire: isAlertMet(rule, snapshot),
		rearm: false
	};
	return {
		fire: false,
		rearm: shouldRearmAlert(rule, snapshot)
	};
};
/**
* 规则的中文简述（面板行内展示，如 `跌到 28.50` / `涨幅达到 5.00%`）
* @param rule 阈值规则
* @param format 宿主格式化服务（价格 / 百分比口径只有宿主一份）
* @returns 简述文案；未配置时为空串
*/
var describeAlertRule = (rule, format) => {
	if (!isAlertConfigured(rule) || rule.value === null) return "";
	const direction = rule.above ? WATCH_ALERT_DIRECTION.ABOVE : WATCH_ALERT_DIRECTION.BELOW;
	if (rule.kind === WATCH_ALERT_KIND.PRICE) return `${WATCH_ALERT_DIRECTION_PRICE_LABEL[direction]} ${format.price(rule.value)}`;
	return `${WATCH_ALERT_DIRECTION_CHANGE_LABEL[direction]} ${format.percentUnsigned(rule.value)}`;
};
/**
* 阈值到达时的提醒文案
*
* 语气色跟随**触发方向**而不是当日涨跌：设了「跌到 28.50」时，价格真跌到那里
* 本身就是坏消息，提醒应当是跌色（A 股默认绿），与当日是红是绿无关。
* @param rule 阈值规则
* @param name 股票名称
* @param snapshot 行情快照
* @param format 宿主格式化服务（价格 / 百分比口径只有宿主一份）
* @returns 提醒文案（标题 / 说明 / 语气）
*/
var buildAlertNotice = (rule, name, snapshot, format) => {
	const direction = rule.above ? WATCH_ALERT_DIRECTION.ABOVE : WATCH_ALERT_DIRECTION.BELOW;
	return {
		title: `${name} ${rule.kind === WATCH_ALERT_KIND.PRICE ? WATCH_ALERT_DIRECTION_PRICE_LABEL[direction] : WATCH_ALERT_DIRECTION_CHANGE_LABEL[direction]} ${rule.kind === WATCH_ALERT_KIND.PRICE ? format.price(rule.value) : format.percentUnsigned(rule.value)}`,
		body: `现价 ${format.price(snapshot.price)}（${format.percent(snapshot.changePercent)}）`,
		tone: rule.above ? WATCH_ALERT_TONE.UP : WATCH_ALERT_TONE.DOWN
	};
};
//#endregion
//#region plugins/dsh-sidebar-watch/AlertEditor.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$1 = { class: "space-y-4" };
var _hoisted_2$1 = { class: "flex gap-2" };
var _hoisted_3$1 = ["onClick"];
var _hoisted_4$1 = { class: "flex gap-2" };
var _hoisted_5$1 = { class: "text-xs leading-relaxed text-text-tertiary" };
var _hoisted_6$1 = { class: "flex items-center justify-between gap-2 pt-1" };
var _hoisted_7$1 = { key: 1 };
//#endregion
//#region plugins/dsh-sidebar-watch/AlertEditor.vue
var AlertEditor_default = /* @__PURE__ */ defineComponent({
	__name: "AlertEditor",
	props: {
		rule: {},
		deps: {}
	},
	emits: ["save", "clear"],
	setup(__props, { emit: __emit }) {
		const props = __props;
		const emit = __emit;
		/** 当前选中的阈值类型（价格 / 涨跌幅；不提供「不提醒」，清除走单独按钮） */
		const kind = ref(WATCH_ALERT_KIND.PRICE);
		/** 比较方向是否为「涨到 / 涨幅达到」 */
		const above = ref(true);
		/** 阈值数值的输入原文（用字符串承接，避免输入中途被 Number 归一化吃掉小数点） */
		const valueText = ref("");
		/**
		* 用外部规则播种编辑器状态（首次进入 / 切换目标时）
		* @param rule 外部传入的阈值规则
		*/
		const seedFromRule = (rule) => {
			kind.value = rule.kind === WATCH_ALERT_KIND.CHANGE ? WATCH_ALERT_KIND.CHANGE : WATCH_ALERT_KIND.PRICE;
			above.value = rule.above;
			valueText.value = rule.value === null ? "" : String(rule.value);
		};
		watch(() => props.rule, seedFromRule, { immediate: true });
		/** 输入解析出的数值（非法为 null） */
		const parsedValue = computed(() => {
			const trimmed = valueText.value.trim();
			if (!trimmed) return null;
			const parsed = Number(trimmed);
			return Number.isFinite(parsed) && parsed > 0 ? parsed : null;
		});
		/** 是否可以保存 */
		const canSave = computed(() => parsedValue.value !== null);
		/** 目标是否为价格 */
		const isPrice = computed(() => kind.value === WATCH_ALERT_KIND.PRICE);
		/** 方向按钮文案（随阈值类型变化：价格说「涨到」、涨跌幅说「涨幅达到」） */
		const directionLabels = computed(() => isPrice.value ? {
			above: "涨到",
			below: "跌到"
		} : {
			above: "涨幅达到",
			below: "跌幅达到"
		});
		/** 数值输入框占位文案 */
		const valuePlaceholder = computed(() => isPrice.value ? WATCH_ALERT_INPUT_PLACEHOLDER_PRICE : WATCH_ALERT_INPUT_PLACEHOLDER_CHANGE);
		/** 已配置的阈值简述（未配置时为空串） */
		const currentSummary = computed(() => describeAlertRule(props.rule, props.deps.format));
		/** 保存：数值合法时上报 */
		const onSave = () => {
			const value = parsedValue.value;
			if (value === null) return;
			emit("save", {
				kind: kind.value,
				value,
				above: above.value
			});
		};
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", _hoisted_1$1, [
				createElementVNode("div", null, [
					_cache[4] || (_cache[4] = createElementVNode("p", { class: "mb-2 text-xs font-medium text-text-secondary" }, "提醒什么", -1)),
					createCommentVNode(" 阈值类型：价格 / 涨跌幅 "),
					createElementVNode("div", _hoisted_2$1, [(openBlock(true), createElementBlock(Fragment, null, renderList([unref(WATCH_ALERT_KIND).PRICE, unref(WATCH_ALERT_KIND).CHANGE], (item) => {
						return openBlock(), createElementBlock("button", {
							key: item,
							type: "button",
							class: normalizeClass(["pressable flex-1 rounded-md px-3 py-1.5 text-sm active:scale-[0.98]", kind.value === item ? "bg-primary-weak font-medium text-primary" : "bg-flat-weak/60 text-text-secondary hover:text-text"]),
							onClick: ($event) => kind.value = item
						}, toDisplayString(unref(WATCH_ALERT_KIND_LABEL)[item]), 11, _hoisted_3$1);
					}), 128))])
				]),
				createElementVNode("div", null, [
					_cache[5] || (_cache[5] = createElementVNode("p", { class: "mb-2 text-xs font-medium text-text-secondary" }, "往哪个方向", -1)),
					createCommentVNode(" 方向：涨到 / 跌到（涨跌幅态文案自动切换） "),
					createElementVNode("div", _hoisted_4$1, [createElementVNode("button", {
						type: "button",
						class: normalizeClass(["pressable flex-1 rounded-md px-3 py-1.5 text-sm active:scale-[0.98]", above.value ? "bg-up-weak font-medium text-up" : "bg-flat-weak/60 text-text-secondary hover:text-text"]),
						onClick: _cache[0] || (_cache[0] = ($event) => above.value = true)
					}, toDisplayString(directionLabels.value.above), 3), createElementVNode("button", {
						type: "button",
						class: normalizeClass(["pressable flex-1 rounded-md px-3 py-1.5 text-sm active:scale-[0.98]", !above.value ? "bg-down-weak font-medium text-down" : "bg-flat-weak/60 text-text-secondary hover:text-text"]),
						onClick: _cache[1] || (_cache[1] = ($event) => above.value = false)
					}, toDisplayString(directionLabels.value.below), 3)])
				]),
				createElementVNode("div", null, [_cache[6] || (_cache[6] = createElementVNode("p", { class: "mb-2 text-xs font-medium text-text-secondary" }, "阈值数值", -1)), (openBlock(), createBlock(resolveDynamicComponent(__props.deps.ui.Input), {
					modelValue: valueText.value,
					"onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => valueText.value = $event),
					placeholder: valuePlaceholder.value
				}, null, 8, ["modelValue", "placeholder"]))]),
				createElementVNode("p", _hoisted_5$1, toDisplayString(unref(WATCH_ALERT_EDITOR_HINT)), 1),
				createElementVNode("div", _hoisted_6$1, [unref(isAlertConfigured)(__props.rule) ? (openBlock(), createElementBlock("button", {
					key: 0,
					type: "button",
					class: "pressable text-xs text-text-tertiary hover:text-down active:scale-95",
					onClick: _cache[3] || (_cache[3] = ($event) => emit("clear"))
				}, " 清除提醒" + toDisplayString(currentSummary.value ? `（${currentSummary.value}）` : ""), 1)) : (openBlock(), createElementBlock("span", _hoisted_7$1)), (openBlock(), createBlock(resolveDynamicComponent(__props.deps.ui.Button), {
					variant: "primary",
					disabled: !canSave.value,
					onClick: onSave
				}, {
					default: withCtx(() => [..._cache[7] || (_cache[7] = [createTextVNode(" 保存 ", -1)])]),
					_: 1
				}, 8, ["disabled"]))])
			]);
		};
	}
});
//#endregion
//#region plugins/dsh-sidebar-watch/candidates.ts
/**
* 过滤出「仍在自选股里」的候选
*
* 候选池是用户逐只点出来的，但自选股会被删（删单只 / 删分组 / 清空）：
* 面板只渲染候选池与当前自选股的交集 —— 已删掉的票自然从面板消失，
* 既不会出现「盯盘里还挂着一只已不在自选的票」这种迷惑状态，
* 也不会因为取不到行情 / 名称而报错。
*
* 库里那条候选记录**保留**（不静默删数据）：用户重新把票加回自选，标记即自动恢复。
* @param candidates 候选池（按加入顺序）
* @param watchlistSymbols 当前自选股符号列表
* @returns 仍有效的候选（保持原顺序）
*/
var filterCandidatesByWatchlist = (candidates, watchlistSymbols) => {
	const known = new Set(watchlistSymbols);
	return candidates.filter((candidate) => known.has(candidate.symbol));
};
//#endregion
//#region plugins/dsh-sidebar-watch/WatchHeaderPanel.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1 = {
	key: 0,
	class: "mb-2 flex items-center justify-between gap-2 text-xs text-text-tertiary"
};
var _hoisted_2 = { key: 0 };
var _hoisted_3 = { class: "py-1 text-xs leading-relaxed text-text-tertiary" };
var _hoisted_4 = {
	key: 3,
	class: "max-h-[52vh] space-y-0.5 overflow-y-auto"
};
var _hoisted_5 = { class: "group flex items-center gap-0.5 rounded-md hover:bg-flat-weak" };
var _hoisted_6 = ["title", "onClick"];
var _hoisted_7 = { class: "min-w-0 flex-1 truncate text-xs text-text" };
var _hoisted_8 = { class: "shrink-0 text-xs tabular-nums text-text-secondary" };
var _hoisted_9 = [
	"aria-label",
	"title",
	"onClick"
];
var _hoisted_10 = {
	key: 0,
	class: "absolute right-0 top-0 h-1 w-1 rounded-full bg-current"
};
var _hoisted_11 = [
	"aria-label",
	"title",
	"onClick"
];
var _hoisted_12 = { class: "mt-2 border-t border-flat-weak pt-2" };
//#endregion
//#region plugins/dsh-sidebar-watch/WatchHeaderPanel.vue
var WatchHeaderPanel_default = /* @__PURE__ */ defineComponent({
	__name: "WatchHeaderPanel",
	props: {
		repo: {},
		monitor: {},
		deps: {},
		panelKey: {}
	},
	setup(__props) {
		const props = __props;
		/** 正在编辑阈值的候选符号（null = 弹窗关闭；同时只编辑一个） */
		const editingSymbol = ref(null);
		/** 阈值弹窗开关（挂在 editingSymbol 上：有目标即开，置空即关） */
		const editorOpen = computed({
			get: () => editingSymbol.value !== null,
			set: (open) => {
				if (!open) editingSymbol.value = null;
			}
		});
		/** 面板内渲染的一行盯盘数据 */
		const candidates = computed(() => filterCandidatesByWatchlist(props.repo.list(), props.deps.watchlist.symbols()));
		/** 是否首载中（引擎只在第一次拉取时为 true，后续刷新不闪） */
		const loading = computed(() => props.monitor.loading.value);
		/** 已设阈值的候选数量（顶部摘要） */
		const alertCount = computed(() => candidates.value.filter((candidate) => isAlertConfigured(candidate.alert)).length);
		/** 面板内展示的行 */
		const rows = computed(() => candidates.value.map((candidate) => {
			const quote = props.deps.format.findQuote(props.monitor.quotes.value, candidate.symbol);
			const changePercent = quote?.changePercent ?? null;
			const hasAlert = isAlertConfigured(candidate.alert);
			const alertClass = hasAlert ? WATCH_ALERT_TONE_LABEL_CLASS[candidate.alert.above ? WATCH_ALERT_TONE.UP : WATCH_ALERT_TONE.DOWN] : "";
			return {
				symbol: candidate.symbol,
				name: quote?.name || candidate.name || candidate.symbol,
				price: props.deps.format.price(quote?.price ?? null),
				change: props.deps.format.percent(changePercent),
				trendClass: props.deps.format.trendClass(props.deps.format.trend(changePercent ?? 0)),
				alertText: describeAlertRule(candidate.alert, props.deps.format),
				alertClass,
				hasAlert,
				fired: hasAlert && !candidate.alert.armed
			};
		}));
		/** 正在编辑的行（弹窗标题要用股票名；理论上恒存在，兜底 null） */
		const editingRow = computed(() => rows.value.find((row) => row.symbol === editingSymbol.value) ?? null);
		/**
		* 取某候选的阈值规则（记录已不在池里时回落到空规则）
		* @param symbol 完整符号
		* @returns 阈值规则
		*/
		const alertRuleOf = (symbol) => props.repo.get(symbol)?.alert ?? createEmptyAlertRule();
		/**
		* 盯盘候选 → 详情页左侧来源列表
		*
		* 价格 / 涨跌幅取引擎的报价快照（行情未返回时为 null，详情页列表会显示占位符）；
		* symbol 归一化为完整符号，保证与详情页路由符号同形态、当前股高亮可匹配
		* @returns 上下文股票列表
		*/
		const buildContextList = () => candidates.value.map((candidate) => {
			const quote = props.deps.format.findQuote(props.monitor.quotes.value, candidate.symbol);
			return {
				symbol: props.deps.format.normalizeCode(candidate.symbol),
				name: quote?.name || candidate.name || candidate.symbol,
				price: quote?.price ?? null,
				changePercent: quote?.changePercent ?? null
			};
		});
		/**
		* 单击一行：跳股票详情整页（左侧来源列表 = 全部盯盘候选），并收起下拉
		* @param symbol 完整符号
		*/
		const onOpenStock = (symbol) => {
			props.deps.stockOpen.openPage(symbol, buildContextList());
			props.deps.closePanel(props.panelKey);
		};
		/**
		* 把一只票移出盯盘候选（自选股本身不动，阈值设置一并丢弃）
		* @param symbol 完整符号
		*/
		const onRemoveCandidate = (symbol) => {
			if (editingSymbol.value === symbol) editingSymbol.value = null;
			props.repo.remove(symbol);
		};
		/**
		* 打开 / 关闭某行的阈值弹窗
		* @param symbol 完整符号
		*/
		const onToggleEditor = (symbol) => {
			editingSymbol.value = editingSymbol.value === symbol ? null : symbol;
		};
		/**
		* 保存阈值（弹窗随之关闭）
		* @param patch 阈值内容
		*/
		const onSaveAlert = (patch) => {
			const symbol = editingSymbol.value;
			if (!symbol) return;
			props.repo.setAlert(symbol, patch);
			editingSymbol.value = null;
		};
		/**
		* 清除阈值（弹窗随之关闭）
		*/
		const onClearAlert = () => {
			const symbol = editingSymbol.value;
			if (!symbol) return;
			props.repo.clearAlert(symbol);
			editingSymbol.value = null;
		};
		/** 去自选股页挑票（下拉随之收起，避免浮在自选表上） */
		const onOpenWatchlist = () => {
			props.deps.navigate(WATCHLIST_ROUTE_PATH);
			props.deps.closePanel(props.panelKey);
		};
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", null, [
				createCommentVNode(" 顶部摘要：候选数 + 已设阈值数（下拉里空间够，不必再靠 hover 表达） "),
				rows.value.length > 0 ? (openBlock(), createElementBlock("div", _hoisted_1, [createElementVNode("span", null, toDisplayString(rows.value.length) + " 只在盯", 1), alertCount.value > 0 ? (openBlock(), createElementBlock("span", _hoisted_2, toDisplayString(alertCount.value) + " 只设了阈值", 1)) : createCommentVNode("v-if", true)])) : createCommentVNode("v-if", true),
				loading.value && rows.value.length > 0 ? (openBlock(), createBlock(resolveDynamicComponent(__props.deps.ui.Skeleton), { key: 1 }, {
					default: withCtx(() => [(openBlock(true), createElementBlock(Fragment, null, renderList(unref(4), (index) => {
						return openBlock(), createElementBlock("div", {
							key: index,
							class: "h-7 rounded bg-flat-weak"
						});
					}), 128))]),
					_: 1
				})) : rows.value.length === 0 ? (openBlock(), createElementBlock(Fragment, { key: 2 }, [createCommentVNode(" 空态：说清候选从哪来（面板本身没坏，只是还没挑票） "), createElementVNode("p", _hoisted_3, toDisplayString(unref(WATCH_EMPTY_HINT)), 1)], 2112)) : (openBlock(), createElementBlock("ul", _hoisted_4, [(openBlock(true), createElementBlock(Fragment, null, renderList(rows.value, (row) => {
					return openBlock(), createElementBlock("li", {
						key: row.symbol,
						class: "rounded-md"
					}, [
						createElementVNode("div", _hoisted_5, [
							createElementVNode("button", {
								type: "button",
								class: "pressable flex min-w-0 flex-1 items-center gap-1.5 rounded-md px-2 py-1.5 text-left active:scale-[0.98]",
								title: `${row.name} ${row.price} ${row.change}`,
								onClick: ($event) => onOpenStock(row.symbol)
							}, [
								createElementVNode("span", _hoisted_7, toDisplayString(row.name), 1),
								createElementVNode("span", _hoisted_8, toDisplayString(row.price), 1),
								createElementVNode("span", { class: normalizeClass(["w-[52px] shrink-0 text-right text-xs tabular-nums", row.trendClass]) }, toDisplayString(row.change), 3)
							], 8, _hoisted_6),
							createCommentVNode(" 阈值提醒：已设阈值时铃铛按触发方向上色，一眼能看出这只票在等什么；\r\n               已触发过一次的加一个小点，表示要等价格回到内侧才重新生效 "),
							createElementVNode("button", {
								type: "button",
								class: normalizeClass(["pressable relative shrink-0 rounded p-0.5 transition-opacity hover:bg-flat-weak active:scale-90", [row.hasAlert ? row.alertClass : "text-text-tertiary opacity-0 hover:text-text group-hover:opacity-100", editingSymbol.value === row.symbol ? "bg-primary-weak text-primary opacity-100" : ""]]),
								"aria-label": `${row.hasAlert ? unref(WATCH_ALERT_BUTTON_ACTIVE_TITLE) : unref(WATCH_ALERT_BUTTON_TITLE)} ${row.name}`,
								title: row.hasAlert ? `阈值：${row.alertText}${row.fired ? "（已触发，待重新生效）" : ""}` : unref(WATCH_ALERT_BUTTON_TITLE),
								onClick: withModifiers(($event) => onToggleEditor(row.symbol), ["stop"])
							}, [(openBlock(), createBlock(resolveDynamicComponent(__props.deps.ui.Icon), {
								name: "bell",
								size: 12
							})), row.fired ? (openBlock(), createElementBlock("span", _hoisted_10)) : createCommentVNode("v-if", true)], 10, _hoisted_9),
							createElementVNode("button", {
								type: "button",
								class: "pressable shrink-0 rounded p-0.5 text-text-tertiary opacity-0 transition-opacity hover:bg-flat-weak hover:text-text group-hover:opacity-100 active:scale-90",
								"aria-label": `移出盯盘 ${row.name}`,
								title: `移出盯盘 ${row.name}`,
								onClick: withModifiers(($event) => onRemoveCandidate(row.symbol), ["stop"])
							}, [(openBlock(), createBlock(resolveDynamicComponent(__props.deps.ui.Icon), {
								name: "close",
								size: 12
							}))], 8, _hoisted_11)
						]),
						createCommentVNode(" 已设阈值：常显不藏 hover，否则等于没设 "),
						row.alertText ? (openBlock(), createElementBlock("p", {
							key: 0,
							class: normalizeClass(["px-2 pb-0.5 text-[10px]", row.alertClass])
						}, toDisplayString(row.alertText), 3)) : createCommentVNode("v-if", true)
					]);
				}), 128))])),
				createCommentVNode(" 底部入口：候选从自选股的「盯盘」按钮来，给一条直达路径 "),
				createElementVNode("div", _hoisted_12, [createElementVNode("button", {
					type: "button",
					class: "pressable flex w-full items-center justify-center gap-1.5 rounded-lg py-1.5 text-xs text-text-secondary hover:bg-flat-weak hover:text-text active:scale-[0.98]",
					onClick: onOpenWatchlist
				}, [(openBlock(), createBlock(resolveDynamicComponent(__props.deps.ui.Icon), {
					name: "star",
					size: 12
				})), _cache[1] || (_cache[1] = createTextVNode(" 打开自选股页挑票 ", -1))])]),
				createCommentVNode(" 阈值弹窗：下拉 320px 塞不下编辑器，点铃铛统一改为居中弹窗 "),
				(openBlock(), createBlock(resolveDynamicComponent(__props.deps.ui.Modal), {
					open: editorOpen.value,
					"onUpdate:open": _cache[0] || (_cache[0] = ($event) => editorOpen.value = $event),
					title: editingRow.value ? `${unref(WATCH_ALERT_EDITOR_TITLE)} · ${editingRow.value.name}` : unref(WATCH_ALERT_EDITOR_TITLE),
					"max-width-class": "max-w-sm"
				}, {
					default: withCtx(() => [editingSymbol.value ? (openBlock(), createBlock(AlertEditor_default, {
						key: 0,
						rule: alertRuleOf(editingSymbol.value),
						deps: __props.deps,
						onSave: onSaveAlert,
						onClear: onClearAlert
					}, null, 8, ["rule", "deps"])) : createCommentVNode("v-if", true)]),
					_: 1
				}, 40, ["open", "title"]))
			]);
		};
	}
});
//#endregion
//#region host/constants/plugin.constants.ts
/** 插件运行时状态 */
var PLUGIN_STATUS = {
	/** 已挂载（贡献点全部生效） */
	MOUNTED: "mounted",
	/** 挂载中：apply 返回了 Promise，尚未完成 */
	MOUNTING: "mounting",
	/** 等待依赖：inject 声明的插件尚未挂载 */
	PENDING: "pending",
	/** 被用户禁用（持久化黑名单命中，或依赖被禁用） */
	DISABLED: "disabled",
	/** 挂载失败（apply 抛错，贡献点已回滚） */
	FAILED: "failed"
};
PLUGIN_STATUS.MOUNTED, PLUGIN_STATUS.MOUNTING, PLUGIN_STATUS.PENDING, PLUGIN_STATUS.DISABLED, PLUGIN_STATUS.FAILED;
PLUGIN_STATUS.MOUNTED, PLUGIN_STATUS.MOUNTING, PLUGIN_STATUS.PENDING, PLUGIN_STATUS.DISABLED, PLUGIN_STATUS.FAILED;
/** 插件日志前缀（内核统一 `[plugin:<id>]` 形态） */
var PLUGIN_LOG_PREFIX = "[plugin]";
//#endregion
//#region plugins/dsh-sidebar-watch/service.ts
/**
* 插件 dsh-sidebar-watch · 盯盘候选仓储
*
* 本文件演示「通用数据层的第二个消费方」（第一个是 dsh-quick-note 的速记）：
* 候选落在本插件独立表 `plugin_dsh_sidebar_watch_watch_candidates`
* （Tauri 端 SQLite 动态表 / 浏览器端 appStorage JSON 表仿真，两端语义一致），
* 插件永不直接写 SQL，只做「声明式建表 + CRUD」。
*
* 每条候选自带一份**阈值提醒规则**（价格 / 涨跌幅 + 方向 + 待触发态），
* 与 symbol / name 同表落地 —— 重启后阈值与「已触发」状态都还在。
* 规则本身的判定逻辑在 `alerts.ts`（纯函数），本文件只管存取。
*
* 对外经 `watch:repo` 服务暴露：其他插件 `ctx.consume('watch:repo')` 即可读写
* 同一份候选池（服务声明见文件末尾的模块扩展）。
*/
/** 数据表名（物理表 = `plugin_dsh_sidebar_watch_watch_candidates`） */
var WATCH_CANDIDATE_TABLE = "watch_candidates";
/**
* 把库里的一行还原成阈值规则（老行缺列 / 脏值一律回落到「未设阈值」）
* @param row 候选表的一行
* @returns 阈值规则
*/
var parseAlertRule = (row) => {
	const kind = row.alert_kind === WATCH_ALERT_KIND.PRICE || row.alert_kind === WATCH_ALERT_KIND.CHANGE ? row.alert_kind : WATCH_ALERT_KIND.NONE;
	const raw = row.alert_value === null || row.alert_value === void 0 ? null : Number(row.alert_value);
	const value = raw !== null && Number.isFinite(raw) ? raw : null;
	return {
		kind: value === null ? WATCH_ALERT_KIND.NONE : kind,
		value,
		above: Number(row.alert_above ?? 1) !== 0,
		armed: Number(row.alert_armed ?? 1) !== 0
	};
};
/**
* 把阈值规则摊平成待写入的列
* @param rule 阈值规则
* @returns 列名 → 值
*/
var toAlertColumns = (rule) => ({
	alert_kind: rule.kind,
	alert_value: rule.value,
	alert_above: rule.above ? 1 : 0,
	alert_armed: rule.armed ? 1 : 0
});
/**
* 创建盯盘候选仓储（异步：先建表 / 水合，再返回可用的仓储）
*
* 内存用 `ref` 持有候选数组（面板 computed 自动跟随增删刷新），落库走 `ctx.db`。
* 写库排进**串行队列**：内存立即变、库操作按顺序执行 —— 这样「刚加入就移除」
* 也能先插后删（否则可能拿着还没生成的宿主主键去删）。落库失败只记日志，
* 不打断交互（内存态与库不一致时以重启后水合为准）。
* @param db 插件自有数据库句柄（`ctx.db`）
* @returns 盯盘候选仓储
*/
var createWatchCandidateRepo = async (db) => {
	await db.ensureTable(WATCH_CANDIDATE_TABLE, [
		{
			name: "symbol",
			type: "text",
			indexed: true
		},
		{
			name: "name",
			type: "text"
		},
		{
			name: "added_at",
			type: "integer",
			indexed: true
		},
		{
			name: "alert_kind",
			type: "text"
		},
		{
			name: "alert_value",
			type: "real"
		},
		{
			name: "alert_above",
			type: "integer"
		},
		{
			name: "alert_armed",
			type: "integer"
		}
	]);
	const items = ref([]);
	/** symbol → 数据表行主键（删除定位；内存记账，避免每次删除都先查库） */
	const rowIds = /* @__PURE__ */ new Map();
	const rows = await db.select(WATCH_CANDIDATE_TABLE, { orderBy: { column: "added_at" } });
	const hydrated = /* @__PURE__ */ new Set();
	for (const row of rows) {
		if (!row.symbol || hydrated.has(row.symbol)) continue;
		hydrated.add(row.symbol);
		items.value.push({
			symbol: row.symbol,
			name: row.name ?? row.symbol,
			addedAt: Number(row.added_at) || 0,
			alert: parseAlertRule(row)
		});
		rowIds.set(row.symbol, row.id);
	}
	/** 串行写队列（保证「先插后删」的顺序） */
	let writeChain = Promise.resolve();
	/**
	* 排一个库操作进队列
	* @param task 库操作
	*/
	const enqueue = (task) => {
		writeChain = writeChain.then(task).catch((error) => {
			console.error(`${PLUGIN_LOG_PREFIX} dsh-sidebar-watch 盯盘候选落库失败`, error);
		});
	};
	/**
	* 该符号是否已在候选池里
	* @param symbol 完整符号
	* @returns 是否已在池里
	*/
	const has = (symbol) => items.value.some((item) => item.symbol === symbol);
	/**
	* 取单条候选
	* @param symbol 完整符号
	* @returns 候选；不存在返回 undefined
	*/
	const get = (symbol) => items.value.find((item) => item.symbol === symbol);
	/**
	* 就地替换一条候选（数组换新引用以驱动面板 computed）并落库
	* @param symbol 完整符号
	* @param next 新的候选对象
	*/
	const replaceItem = (symbol, next) => {
		const index = items.value.findIndex((item) => item.symbol === symbol);
		if (index < 0) return;
		const copy = items.value.slice();
		copy[index] = next;
		items.value = copy;
		enqueue(async () => {
			const id = rowIds.get(symbol);
			if (id === void 0) return;
			await db.update(WATCH_CANDIDATE_TABLE, id, toAlertColumns(next.alert));
		});
	};
	/**
	* 改某条候选的阈值规则（候选不在池里则忽略）
	* @param symbol 完整符号
	* @param patch 阈值内容
	*/
	const setAlert = (symbol, patch) => {
		const current = get(symbol);
		if (!current) return;
		replaceItem(symbol, {
			...current,
			alert: {
				...patch,
				armed: true
			}
		});
	};
	/**
	* 改某条候选的「待触发」标记（只改 armed；候选不在池里则忽略）
	* @param symbol 完整符号
	* @param armed 是否待触发
	*/
	const setArmed = (symbol, armed) => {
		const current = get(symbol);
		if (!current || current.alert.armed === armed) return;
		replaceItem(symbol, {
			...current,
			alert: {
				...current.alert,
				armed
			}
		});
	};
	/**
	* 加入候选（已在池里或符号为空则忽略）
	* @param symbol 完整符号
	* @param name 股票名称
	*/
	const add = (symbol, name) => {
		if (!symbol || has(symbol)) return;
		const candidate = {
			symbol,
			name,
			addedAt: Date.now(),
			alert: createEmptyAlertRule()
		};
		items.value = [...items.value, candidate];
		enqueue(async () => {
			const id = await db.insert(WATCH_CANDIDATE_TABLE, {
				symbol: candidate.symbol,
				name: candidate.name,
				added_at: candidate.addedAt,
				...toAlertColumns(candidate.alert)
			});
			rowIds.set(candidate.symbol, id);
		});
	};
	/**
	* 移出候选（不在池里则忽略）
	* @param symbol 完整符号
	*/
	const remove = (symbol) => {
		if (!has(symbol)) return;
		items.value = items.value.filter((item) => item.symbol !== symbol);
		enqueue(async () => {
			const id = rowIds.get(symbol);
			if (id === void 0) return;
			await db.remove(WATCH_CANDIDATE_TABLE, id);
			rowIds.delete(symbol);
		});
	};
	return {
		list: () => items.value,
		get,
		has,
		add,
		remove,
		toggle: (symbol, name) => {
			if (has(symbol)) {
				remove(symbol);
				return false;
			}
			add(symbol, name);
			return true;
		},
		setAlert,
		clearAlert: (symbol) => {
			setAlert(symbol, createEmptyAlertRule());
		},
		markAlertFired: (symbol) => setArmed(symbol, false),
		rearmAlert: (symbol) => setArmed(symbol, true)
	};
};
//#endregion
//#region plugins/dsh-sidebar-watch/monitor.ts
/**
* 插件 dsh-sidebar-watch · 盯盘引擎
*
* 为什么不是「面板自己轮询 + 顺手判阈值」：面板挂在顶栏下拉里，
* 下拉一收起宿主就把内容组件整个卸载（`HeaderItemHost` 的 `v-if="open"`），
* 而**盯盘的全部意义就是「你没在看的时候替你盯着」** —— 告警不能随下拉一起停摆。
*
* 因此本模块把「取报价 → 判阈值 → 弹提醒」整体提到插件层，用宿主的调度器轮询
* （`app:polling`，无组件依赖；复用全站同一份交易窗口 / 退避 / 可见性策略）：
* - 面板与顶栏轮播都只消费 `quotes` / `loading`，是纯展示（见 marquee.ts）；
* - 收起下拉、切到别的页面，盯盘照常工作；
* - 全插件只有这一处报价请求，不会因为「面板也在轮」而把上游请求翻倍。
*
* 监控范围 = **候选池 ∩ 当前自选股**（与面板渲染同一集合，见 `candidates.ts`）：
* 看到的即盯着的。把票从自选股移除只让该行与它的告警一起停下，
* 候选记录与阈值仍保留在库里 —— 重新加回自选股即自动续上。
*/
/**
* 创建盯盘引擎
*
* 调度器与它的监听全部跑在独立 `effectScope` 里：插件卸载时一次 `stop()` 收干净，
* 不依赖任何组件生命周期。
* @param options 依赖（仓储 / 日志器 / 宿主能力容器）
* @returns 盯盘引擎
*/
var createWatchMonitor = (options) => {
	const { repo, logger, deps } = options;
	const notify = deps.notify;
	/** 报价快照（每次整份替换，行 key 不变 → 表格 DOM 原地复用） */
	const quotes = shallowRef({});
	/** 首载标记：只在第一次拉取前置 true（与自选股页刷新不闪是同一处理） */
	const loading = ref(true);
	/**
	* 当前监控的候选（候选池 ∩ 自选股）
	* @returns 仍在自选股里的候选（保持候选池顺序）
	*/
	const monitoredCandidates = () => filterCandidatesByWatchlist(repo.list(), deps.watchlist.symbols());
	/**
	* 阈值判定 + 提醒
	*
	* 顺序上**先落库、后弹窗**：反过来的话，若在弹窗与落库之间进程被杀，
	* 重启后会拿着旧的 armed 状态再弹一次（用户看到重复提醒）。
	* @param quotesMap 本轮报价快照
	*/
	const evaluateAlerts = (quotesMap) => {
		for (const candidate of monitoredCandidates()) {
			const rule = candidate.alert;
			if (!isAlertConfigured(rule)) continue;
			const quote = deps.format.findQuote(quotesMap, candidate.symbol);
			const snapshot = {
				price: quote?.price ?? null,
				changePercent: quote?.changePercent ?? null
			};
			const { fire, rearm } = evaluateAlert(rule, snapshot);
			if (fire) {
				repo.markAlertFired(candidate.symbol);
				const notice = buildAlertNotice(rule, quote?.name || candidate.name, snapshot, deps.format);
				notify?.notify({
					title: notice.title,
					body: notice.body,
					tone: notice.tone,
					source: WATCH_NOTIFY_SOURCE,
					dedupeKey: `${WATCH_NOTIFY_SOURCE}:${candidate.symbol}`,
					onClick: () => deps.stockOpen.openSidebar(candidate.symbol)
				});
				logger.info(`阈值提醒：${notice.title}`);
			} else if (rearm) repo.rearmAlert(candidate.symbol);
		}
	};
	/**
	* 一轮取数：拉当前监控集合的报价，覆盖快照并判阈值
	*/
	const fetchQuotes = async () => {
		const symbols = monitoredCandidates().map((candidate) => candidate.symbol);
		if (symbols.length === 0) {
			quotes.value = {};
			loading.value = false;
			return;
		}
		try {
			const list = await deps.quotes.fetchFullQuotes(symbols);
			const quotesMap = Object.fromEntries(list.map((quote) => [quote.code, quote]));
			quotes.value = quotesMap;
			evaluateAlerts(quotesMap);
		} finally {
			loading.value = false;
		}
	};
	const scope = effectScope();
	/** 取消待执行的补拉（scope.run 里赋值；插件卸载时随 scope 一起收尾） */
	let stopCatchUp;
	scope.run(() => {
		const scheduler = deps.polling.create({
			task: fetchQuotes,
			intervalMs: WATCH_POLL_INTERVAL_MS,
			tradingAware: true
		});
		/**
		* 新候选补拉报价
		*
		* 调度器是交易窗口感知的：窗口外启动时只取一次，之后不再轮询 ——
		* 那之后新加的候选永远拿不到报价，只能一直挂着 `--` 占位。
		* 这里监听监控集合，出现快照里还没有的 symbol 就**防抖补一轮**
		* （连续增删多只合并成一次；仍是单次批量请求，不碰频率红线）。
		*/
		const monitoredSymbols = computed(() => monitoredCandidates().map((candidate) => candidate.symbol));
		let catchUpTimer;
		const scheduleCatchUp = () => {
			if (catchUpTimer) clearTimeout(catchUpTimer);
			catchUpTimer = setTimeout(() => {
				catchUpTimer = void 0;
				scheduler.runNow();
			}, 800);
		};
		watch(monitoredSymbols, (symbols) => {
			if (symbols.some((symbol) => !deps.format.findQuote(quotes.value, symbol))) scheduleCatchUp();
		});
		stopCatchUp = () => {
			if (catchUpTimer) clearTimeout(catchUpTimer);
			catchUpTimer = void 0;
		};
	});
	return {
		quotes,
		loading,
		stop: () => {
			stopCatchUp?.();
			scope.stop();
			notify?.dismissBySource(WATCH_NOTIFY_SOURCE);
		}
	};
};
//#endregion
//#region plugins/dsh-sidebar-watch/marquee.ts
/**
* 插件 dsh-sidebar-watch · 顶栏轮播行
*
* 顶栏收起态展示的那一条「名称 现价 涨跌幅」，由这里构造。
*
* 单独成文件的原因：**它是纯函数**（只依赖几个纯 utils，不碰 pinia、不碰网络），
* 因此可以被冒烟脚本直跑 —— 文案格式与语气（涨 / 跌 / 平）一旦错了，
* 顶栏那条轮播就会长期挂着错信息，而它恰恰是用户扫得最多的一行。
* 引擎（monitor.ts）负责取数与判阈值，展示口径放在这里，各自单一职责。
*/
/**
* 造顶栏轮播行（收起态逐条展示的那一行：名称 + 现价 + 涨跌幅）
*
* **不做过滤**：还没取到报价的候选也出行（价格 / 涨跌幅用 `--` 占位）——
* 新加的票要立刻在轮播里露脸，而不是等引擎补拉完报价才出现；
* 占位只是暂时的，引擎对新候选会补一轮报价（见 monitor.ts），到时自动换成真实数字。
*
* @param candidates 候选（已过滤为仍在自选股里的）
* @param quotes 报价快照（key 为上游原始 `code`，查询走 `format.findQuote`）
* @param format 宿主格式化服务（价格 / 百分比 / 涨跌语气，口径只有宿主一份）
* @returns 轮播行（保持候选池顺序）
*/
var buildMarqueeLines = (candidates, quotes, format) => {
	const lines = [];
	for (const candidate of candidates) {
		const quote = format.findQuote(quotes, candidate.symbol);
		const name = quote?.name || candidate.name;
		const price = format.price(quote?.price ?? null);
		const percent = format.percent(quote?.changePercent ?? null);
		lines.push({
			text: [
				name,
				price,
				percent
			].join(" "),
			label: name,
			price,
			percent,
			tone: WATCH_MARQUEE_TONE_BY_TREND[format.trend(quote?.changePercent ?? 0)]
		});
	}
	return lines;
};
//#endregion
//#region plugins/dsh-sidebar-watch/plugin.ts
/**
* 插件 dsh-sidebar-watch · 自选盯盘
*
* 入口在**应用顶栏右侧工具条**（`ctx.header`）：收起态是「铃铛图标 + 一条轮播」
* （候选逐条轮播名称 / 现价 / 涨跌幅），点开才是完整清单 —— 盯盘要的是「一眼扫到」，
* 不需要长期占着侧栏版面。
*
* 一个插件同时演示五件事：
* - **通用数据层**：盯盘候选（含阈值规则）落在本插件独立表
*   `plugin_dsh_sidebar_watch_watch_candidates`（`ctx.db`，Tauri 端 SQLite / 浏览器端本地仿真），
*   插件永不直接写 SQL；
* - **顶栏贡献**：`ctx.header` 把入口挂到顶栏，并贡献收起态的轮播数据源；
* - **行操作贡献**：`ctx.stockRow` 往自选股表格「操作」列注入「盯盘」开关按钮，
*   宿主不硬编码本插件（只按注册表渲染图标 / 文案 / 激活态）；
* - **服务贡献**：`ctx.provide('watch:repo', …)`，其他插件可复用同一份候选池；
* - **宿主服务消费**：`ctx.consume('app:notify')` 弹右侧浮窗，做阈值到价提醒。
*
* 盯盘引擎（取报价 + 判阈值 + 弹提醒）跑在插件层而不是面板组件里，
* 所以下拉收起、切页面都不影响提醒（见 monitor.ts 的说明）。
* 卸载插件时，顶栏条目 / 行操作按钮 / 命令 / 服务 / 引擎一起消失，宿主代码零改动。
*
* 关于插件 id：入口从侧栏搬到顶栏后 id 仍是 `dsh-sidebar-watch`（名字里的 sidebar 已过时）——
* **故意不改**：插件 id 是数据表名与存储命名空间的一部分，改 id 等于让用户
* 已积累的盯盘候选与阈值一夜清空。改名的收益只是字面好看，代价是丢数据，不值得。
*/
/** 顶栏条目全局键（`<pluginId>#<itemId>`，点完收起下拉时经 `panel:close` 用） */
var WATCH_HEADER_PANEL_KEY = `dsh-sidebar-watch#${WATCH_HEADER_ITEM_ID}`;
/**
* 自选盯盘插件定义
*/
var sidebarWatchPlugin = {
	id: "dsh-sidebar-watch",
	name: "自选盯盘",
	version: "1.3.0",
	description: "顶栏常驻盯盘入口：收起态单条轮播候选的名称 / 现价 / 涨跌幅，点开是完整清单。在自选股「操作」列点「盯盘」逐只加入候选（候选与阈值存在插件自己的数据表里），可给每只票设价格 / 涨跌幅阈值，到价在右下角弹提醒；另附「打开自选股页」全局快捷键。",
	author: "内置",
	apply: async (ctx) => {
		const ui = ctx.consume("app:ui");
		const format = ctx.consume("app:format");
		const quotes = ctx.consume("app:quotes");
		const polling = ctx.consume("app:polling");
		const stockOpen = ctx.consume("app:stock-open");
		const watchlist = ctx.consume("app:watchlist");
		const navigate = ctx.consume("app:navigate");
		const closePanel = ctx.consume("panel:close");
		if (!ui || !format || !quotes || !polling || !stockOpen || !watchlist || !navigate || !closePanel) throw new Error("宿主未提供 app:ui / app:format / app:quotes / app:polling / app:stock-open / app:watchlist / app:navigate / panel:close 服务");
		const notify = ctx.consume("app:notify");
		if (!notify) ctx.logger.warn("宿主未提供 app:notify 服务，阈值提醒只在日志里体现");
		const deps = {
			ui,
			format,
			quotes,
			polling,
			stockOpen,
			watchlist,
			notify,
			navigate,
			closePanel
		};
		const repo = await createWatchCandidateRepo(ctx.db);
		ctx.provide("watch:repo", repo);
		const monitor = createWatchMonitor({
			repo,
			logger: ctx.logger,
			deps
		});
		ctx.onDispose(() => monitor.stop());
		ctx.header.add({
			id: WATCH_HEADER_ITEM_ID,
			title: WATCH_HEADER_ITEM_TITLE,
			icon: WATCH_HEADER_ITEM_ICON,
			component: WatchHeaderPanel_default,
			props: {
				repo,
				monitor,
				deps,
				panelKey: WATCH_HEADER_PANEL_KEY
			},
			marquee: () => buildMarqueeLines(filterCandidatesByWatchlist(repo.list(), deps.watchlist.symbols()), monitor.quotes.value, deps.format)
		});
		ctx.stockRow.add({
			id: STOCK_ROW_ACTION_ID,
			title: STOCK_ROW_ACTION_TITLE,
			activeTitle: STOCK_ROW_ACTION_ACTIVE_TITLE,
			icon: "eye",
			isActive: (row) => repo.has(row.symbol),
			run: (row) => {
				repo.toggle(row.symbol, row.name);
			}
		});
		ctx.command.add({
			id: "open-watchlist",
			title: "打开自选股页",
			keys: "Ctrl+Alt+W",
			run: () => {
				deps.navigate(WATCHLIST_ROUTE_PATH);
			}
		});
		ctx.logger.info("已注册顶栏条目（含轮播）、行操作、watch:repo 服务、盯盘引擎与 1 条命令");
	}
};
//#endregion
export { sidebarWatchPlugin as default, sidebarWatchPlugin };
