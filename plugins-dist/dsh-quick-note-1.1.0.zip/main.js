const __WHF_PLUGIN_RUNTIME__ = globalThis.__WHF_PLUGIN_RUNTIME__;
if (!__WHF_PLUGIN_RUNTIME__?.vue) {
  throw new Error('宿主运行时桥不可用：__WHF_PLUGIN_RUNTIME__（插件必须在该版本宿主里安装）');
}
const { Fragment, computed, createBlock, createCommentVNode, createElementBlock, createElementVNode, createTextVNode, defineComponent, openBlock, ref, renderList, resolveDynamicComponent, toDisplayString, unref, vModelText, withCtx, withDirectives } = __WHF_PLUGIN_RUNTIME__.vue;
//#region plugins/dsh-quick-note/constants.ts
/**
* 插件 dsh-quick-note · 文案与展示常量
*
* 面板 / 个股详情扩展区共用的文案集中于此（项目规范：禁止散落字面量）。
* 关联股票的挑选界面已复用全站统一的搜索弹窗（`StockSearchModal`），
* 其内部文案不在此维护。
*/
/** 关联股票按钮文案 */
var QUICK_NOTE_ASSOCIATE_BUTTON = "关联股票";
/** 已关联时按钮的提示（展示当前关联） */
var QUICK_NOTE_ASSOCIATED_TITLE = "点击更换关联股票";
/** 清除关联按钮的 aria 文案 */
var QUICK_NOTE_ASSOCIATE_CLEAR_ARIA = "清除关联股票";
/** 详情扩展区：快捷输入占位文案 */
var QUICK_NOTE_SECTION_PLACEHOLDER = "给这只股票记一笔…（Ctrl + Enter 保存）";
/** 详情扩展区：无速记空态 */
var QUICK_NOTE_SECTION_EMPTY = "这只股票还没有速记";
/** 详情扩展区：保存按钮文案 */
var QUICK_NOTE_SECTION_SAVE = "记下";
/** 删除速记的 aria 前缀（拼接股票名 / 时间由调用方处理） */
var QUICK_NOTE_REMOVE_ARIA = "删除这条速记";
//#endregion
//#region host/constants/plugin.constants.ts
/** 插件运行时状态 */
var PLUGIN_STATUS = {
	/** 已挂载（贡献点全部生效） */
	MOUNTED: "mounted",
	/** 挂载中：apply 返回了 Promise，尚未完成 */
	MOUNTING: "mounting",
	/** 等待依赖：inject 声明的插件尚未挂载 */
	PENDING: "pending",
	/** 被用户禁用（持久化黑名单命中，或依赖被禁用） */
	DISABLED: "disabled",
	/** 挂载失败（apply 抛错，贡献点已回滚） */
	FAILED: "failed"
};
PLUGIN_STATUS.MOUNTED, PLUGIN_STATUS.MOUNTING, PLUGIN_STATUS.PENDING, PLUGIN_STATUS.DISABLED, PLUGIN_STATUS.FAILED;
PLUGIN_STATUS.MOUNTED, PLUGIN_STATUS.MOUNTING, PLUGIN_STATUS.PENDING, PLUGIN_STATUS.DISABLED, PLUGIN_STATUS.FAILED;
/** 插件日志前缀（内核统一 `[plugin:<id>]` 形态） */
var PLUGIN_LOG_PREFIX = "[plugin]";
//#endregion
//#region plugins/dsh-quick-note/service.ts
/**
* 插件 dsh-quick-note · 私有类型与服务契约
*
* 本文件同时演示两件事：
* - **服务声明合并**：往 `AppServiceMap` 里追加 `note:repo`，之后任何插件
*   `ctx.consume('note:repo')` 都能拿到强类型实现（未启用本插件时返回 undefined）；
* - **通用数据层消费**：速记数据落在本插件独立表 `plugin_dsh_quick_note_notes`
*   （`ctx.db`，Tauri 端 SQLite / 浏览器端本地 JSON 表仿真），插件永不直接写 SQL。
*
* v1.1.0：速记可关联一只股票（自选股快选或全市场搜索），
* 个股详情面板经「个股详情扩展区」贡献点展示该股的速记。
*/
/** 旧版（ctx.storage 时期）存放速记数组的键 —— 仅用于一次性迁移，之后即清 */
var QUICK_NOTE_STORAGE_KEY = "notes";
/** 速记数据表名（物理表 = `plugin_dsh_quick_note_notes`） */
var QUICK_NOTE_TABLE = "notes";
/** 速记正文长度上限（超出截断，避免单条占满侧栏） */
var QUICK_NOTE_MAX_LENGTH = 2e3;
/**
* 创建速记仓储（异步：先建表 / 水合 / 迁移旧数据，再返回可用的仓储）
*
* 内存里用 `ref` 持有数组，面板里的 computed 自动跟随增删刷新；
* 落库走 `ctx.db`（宿主通用数据层），写失败只记日志、不打断交互。
* @param db 插件自有数据库句柄（`ctx.db`）
* @param legacyStorage 旧版插件存储（仅用于读取并迁移 ctx.storage 时期的历史数据）
* @param onCreated 新增成功后的回调（插件用它广播 `note:saved` 事件）
* @returns 速记仓储
*/
var createQuickNoteRepo = async (db, legacyStorage, onCreated) => {
	await db.ensureTable(QUICK_NOTE_TABLE, [
		{
			name: "note_id",
			type: "text",
			indexed: true
		},
		{
			name: "content",
			type: "text"
		},
		{
			name: "created_at_ms",
			type: "integer",
			indexed: true
		},
		{
			name: "symbol",
			type: "text",
			indexed: true
		},
		{
			name: "stock_name",
			type: "text"
		}
	]);
	const items = ref([]);
	/**
	* 库行 → QuickNote
	* @param row 数据表里读出的一行（含宿主维护字段）
	* @returns 插件侧的速记对象
	*/
	const toNote = (row) => ({
		id: row.note_id,
		text: row.content,
		createdAt: row.created_at_ms,
		symbol: row.symbol || null,
		stockName: row.stock_name || ""
	});
	const rows = await db.select(QUICK_NOTE_TABLE, { orderBy: {
		column: "created_at_ms",
		desc: true
	} });
	if (rows.length > 0) items.value = rows.map(toNote);
	else {
		const legacyNotes = legacyStorage.get(QUICK_NOTE_STORAGE_KEY, []);
		for (const note of legacyNotes) await db.insert(QUICK_NOTE_TABLE, {
			note_id: note.id,
			content: note.text.slice(0, QUICK_NOTE_MAX_LENGTH),
			created_at_ms: note.createdAt,
			symbol: null,
			stock_name: ""
		});
		if (legacyNotes.length > 0) items.value = legacyNotes.map((note) => ({
			id: note.id,
			text: note.text.slice(0, QUICK_NOTE_MAX_LENGTH),
			createdAt: note.createdAt,
			symbol: null,
			stockName: ""
		}));
	}
	legacyStorage.remove(QUICK_NOTE_STORAGE_KEY);
	/**
	* 静默落库（写失败只记录，不打断交互）
	* @param row 行数据
	*/
	const insertQuietly = async (row) => {
		try {
			await db.insert(QUICK_NOTE_TABLE, row);
		} catch (error) {
			console.error(`${PLUGIN_LOG_PREFIX} dsh-quick-note 速记落库失败`, error);
		}
	};
	return {
		list: () => items.value,
		listBySymbol: (symbol) => items.value.filter((note) => note.symbol === symbol),
		latest: () => items.value[0] ?? null,
		create: (text, stock) => {
			const trimmed = text.trim();
			if (!trimmed) return null;
			const note = {
				id: crypto.randomUUID(),
				text: trimmed.slice(0, QUICK_NOTE_MAX_LENGTH),
				createdAt: Date.now(),
				symbol: stock?.symbol ?? null,
				stockName: stock?.name ?? ""
			};
			items.value = [note, ...items.value];
			insertQuietly({
				note_id: note.id,
				content: note.text,
				created_at_ms: note.createdAt,
				symbol: note.symbol,
				stock_name: note.stockName
			});
			onCreated?.(note);
			return note;
		},
		remove: (id) => {
			const before = items.value.length;
			items.value = items.value.filter((note) => note.id !== id);
			if (items.value.length === before) return;
			(async () => {
				try {
					const [row] = await db.select(QUICK_NOTE_TABLE, { where: { note_id: id } });
					if (row) await db.remove(QUICK_NOTE_TABLE, row.id);
				} catch (error) {
					console.error(`${PLUGIN_LOG_PREFIX} dsh-quick-note 速记删除失败`, error);
				}
			})();
		}
	};
};
//#endregion
//#region plugins/dsh-quick-note/QuickNotePanel.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$1 = { class: "space-y-4" };
var _hoisted_2$1 = ["maxlength"];
var _hoisted_3$1 = { class: "mt-2" };
var _hoisted_4$1 = {
	key: 0,
	class: "flex items-center gap-2"
};
var _hoisted_5$1 = ["title"];
var _hoisted_6$1 = { class: "max-w-[180px] truncate" };
var _hoisted_7$1 = ["aria-label"];
var _hoisted_8$1 = { class: "mt-2 flex items-center justify-between gap-3" };
var _hoisted_9 = { class: "text-xs text-text-tertiary" };
var _hoisted_10 = { class: "flex items-center gap-2" };
var _hoisted_11 = { class: "border-t border-flat-weak pt-3" };
var _hoisted_12 = { class: "mb-2 text-xs font-medium text-text-secondary" };
var _hoisted_13 = {
	key: 1,
	class: "space-y-2"
};
var _hoisted_14 = { class: "whitespace-pre-wrap break-words text-sm text-text" };
var _hoisted_15 = { class: "mt-1 flex items-center justify-between gap-2" };
var _hoisted_16 = { class: "flex min-w-0 items-center gap-2" };
var _hoisted_17 = { class: "text-xs text-text-tertiary" };
var _hoisted_18 = ["title", "onClick"];
var _hoisted_19 = { class: "max-w-[140px] truncate" };
var _hoisted_20 = ["onClick"];
//#endregion
//#region plugins/dsh-quick-note/QuickNotePanel.vue
var QuickNotePanel_default = /* @__PURE__ */ defineComponent({
	__name: "QuickNotePanel",
	props: {
		repo: {},
		deps: {},
		panelKey: {}
	},
	setup(__props) {
		const props = __props;
		/** 草稿正文 */
		const draft = ref("");
		/** 已保存的速记（新的在前；repo.list() 返回响应式数组，增删自动跟随） */
		const notes = computed(() => props.repo.list());
		/** 是否还有可删除的条目 */
		const hasNotes = computed(() => notes.value.length > 0);
		/** 当前选中的关联股票（null = 不关联） */
		const pickedStock = ref(null);
		/**
		* 打开宿主选股弹窗挑一只作为关联
		*
		* 弹窗由宿主渲染（`app:stock-picker`，与顶栏搜索同一组件）：面板被折叠 / 组件被卸载
		* 都不影响结果回传，插件也不必自己写一个更差且样式不统一的搜索框。
		*/
		const onAssociate = async () => {
			const picked = await props.deps.stockPicker.pick();
			if (picked) pickedStock.value = {
				symbol: picked.code,
				name: picked.name
			};
		};
		/** 清除当前关联 */
		const onClearPicked = () => {
			pickedStock.value = null;
		};
		/** 保存当前草稿（空白内容不落库；关联随笔记一并写入） */
		const onSave = () => {
			if (!props.repo.create(draft.value, pickedStock.value ?? void 0)) return;
			draft.value = "";
			pickedStock.value = null;
		};
		/** 保存并关闭抽屉（drawer 形态下的快捷动作，按面板 key 关，不依赖宿主 inject 上下文） */
		const onSaveAndClose = () => {
			onSave();
			props.deps.closePanel(props.panelKey);
		};
		/**
		* 删除一条速记
		* @param id 速记 id
		*/
		const onRemove = (id) => {
			props.repo.remove(id);
		};
		/**
		* 点速记上的关联标签：打开该股的个股详情（右侧详情侧栏）
		* @param symbol 完整符号
		*/
		const onOpenStock = (symbol) => {
			props.deps.stockOpen.openSidebar(symbol);
		};
		/**
		* 编辑区内快捷键：Ctrl/Cmd + Enter 保存
		* @param event 键盘事件
		*/
		const onKeydown = (event) => {
			if ((event.ctrlKey || event.metaKey) && event.key === "Enter") {
				event.preventDefault();
				onSave();
			}
		};
		/**
		* 完整符号 → 裸代码（标签里只展示 6 位代码，宿主口径）
		* @param symbol 完整符号
		* @returns 裸代码
		*/
		const bareCode = (symbol) => props.deps.format.toBareCode(symbol);
		/**
		* 相对时间（`3分钟前` / `昨天` / `9-18`）
		* @param timestamp 毫秒时间戳
		* @returns 相对时间文案
		*/
		const relativeTime = (timestamp) => props.deps.format.relativeTime(timestamp);
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", _hoisted_1$1, [createElementVNode("div", null, [
				withDirectives(createElementVNode("textarea", {
					"onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => draft.value = $event),
					maxlength: unref(QUICK_NOTE_MAX_LENGTH),
					rows: "5",
					placeholder: "记点什么…（Ctrl + Enter 保存）",
					class: "w-full resize-y rounded-card border border-flat-weak bg-surface px-3 py-2 text-sm text-text placeholder:text-text-tertiary focus:border-primary focus:outline-none",
					onKeydown
				}, null, 40, _hoisted_2$1), [[vModelText, draft.value]]),
				createCommentVNode(" 股票关联：宿主选股弹窗（app:stock-picker），确认后落为 pickedStock "),
				createElementVNode("div", _hoisted_3$1, [pickedStock.value ? (openBlock(), createElementBlock("div", _hoisted_4$1, [createElementVNode("button", {
					type: "button",
					class: "pressable flex items-center gap-1.5 rounded-full bg-primary-weak px-2.5 py-1 text-xs text-primary active:scale-95",
					title: unref(QUICK_NOTE_ASSOCIATED_TITLE),
					onClick: onAssociate
				}, [(openBlock(), createBlock(resolveDynamicComponent(__props.deps.ui.Icon), {
					name: "pencil",
					size: 12
				})), createElementVNode("span", _hoisted_6$1, toDisplayString(pickedStock.value.name) + " " + toDisplayString(bareCode(pickedStock.value.symbol)), 1)], 8, _hoisted_5$1), createElementVNode("button", {
					type: "button",
					class: "pressable rounded p-0.5 text-text-tertiary hover:text-text active:scale-90",
					"aria-label": unref(QUICK_NOTE_ASSOCIATE_CLEAR_ARIA),
					onClick: onClearPicked
				}, [(openBlock(), createBlock(resolveDynamicComponent(__props.deps.ui.Icon), {
					name: "close",
					size: 12
				}))], 8, _hoisted_7$1)])) : (openBlock(), createElementBlock("button", {
					key: 1,
					type: "button",
					class: "pressable flex items-center gap-1.5 rounded-full border border-flat-weak px-2.5 py-1 text-xs text-text-tertiary hover:border-primary hover:text-primary active:scale-95",
					onClick: onAssociate
				}, [(openBlock(), createBlock(resolveDynamicComponent(__props.deps.ui.Icon), {
					name: "plus",
					size: 12
				})), createTextVNode(" " + toDisplayString(unref(QUICK_NOTE_ASSOCIATE_BUTTON)), 1)]))]),
				createElementVNode("div", _hoisted_8$1, [createElementVNode("span", _hoisted_9, toDisplayString(draft.value.length) + " / " + toDisplayString(unref(QUICK_NOTE_MAX_LENGTH)), 1), createElementVNode("div", _hoisted_10, [(openBlock(), createBlock(resolveDynamicComponent(__props.deps.ui.Button), {
					variant: "ghost",
					disabled: draft.value.trim().length === 0,
					onClick: onSaveAndClose
				}, {
					default: withCtx(() => [..._cache[1] || (_cache[1] = [createTextVNode(" 保存并关闭 ", -1)])]),
					_: 1
				}, 8, ["disabled"])), (openBlock(), createBlock(resolveDynamicComponent(__props.deps.ui.Button), {
					disabled: draft.value.trim().length === 0,
					onClick: onSave
				}, {
					default: withCtx(() => [..._cache[2] || (_cache[2] = [createTextVNode(" 保存 ", -1)])]),
					_: 1
				}, 8, ["disabled"]))])])
			]), createElementVNode("div", _hoisted_11, [createElementVNode("p", _hoisted_12, "已保存（" + toDisplayString(notes.value.length) + "）", 1), !hasNotes.value ? (openBlock(), createBlock(resolveDynamicComponent(__props.deps.ui.Empty), {
				key: 0,
				text: "还没有速记"
			})) : (openBlock(), createElementBlock("ul", _hoisted_13, [(openBlock(true), createElementBlock(Fragment, null, renderList(notes.value, (note) => {
				return openBlock(), createElementBlock("li", {
					key: note.id,
					class: "group rounded-card border border-flat-weak px-3 py-2"
				}, [createElementVNode("p", _hoisted_14, toDisplayString(note.text), 1), createElementVNode("div", _hoisted_15, [createElementVNode("span", _hoisted_16, [
					createElementVNode("span", _hoisted_17, toDisplayString(relativeTime(note.createdAt)), 1),
					createCommentVNode(" 关联标签：点了直达该股详情（右侧详情侧栏） "),
					note.symbol ? (openBlock(), createElementBlock("button", {
						key: 0,
						type: "button",
						class: "pressable min-w-0 rounded-full bg-flat-weak px-2 py-0.5 text-xs text-text-secondary hover:text-primary active:scale-95",
						title: `打开 ${note.stockName || note.symbol} 详情`,
						onClick: ($event) => onOpenStock(note.symbol)
					}, [createElementVNode("span", _hoisted_19, toDisplayString(note.stockName || bareCode(note.symbol)), 1)], 8, _hoisted_18)) : createCommentVNode("v-if", true)
				]), createElementVNode("button", {
					type: "button",
					class: "pressable rounded p-1 text-text-tertiary opacity-0 transition-opacity hover:bg-flat-weak hover:text-text group-hover:opacity-100 active:scale-90",
					"aria-label": "删除这条速记",
					onClick: ($event) => onRemove(note.id)
				}, [(openBlock(), createBlock(resolveDynamicComponent(__props.deps.ui.Icon), {
					name: "trash",
					size: 12
				}))], 8, _hoisted_20)])]);
			}), 128))]))])]);
		};
	}
});
//#endregion
//#region plugins/dsh-quick-note/StockNotesSection.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1 = { class: "space-y-3" };
var _hoisted_2 = { class: "flex items-end gap-2" };
var _hoisted_3 = ["maxlength", "placeholder"];
var _hoisted_4 = {
	key: 1,
	class: "space-y-2"
};
var _hoisted_5 = { class: "whitespace-pre-wrap break-words text-sm text-text" };
var _hoisted_6 = { class: "mt-1 flex items-center justify-between gap-2" };
var _hoisted_7 = { class: "text-xs text-text-tertiary" };
var _hoisted_8 = ["aria-label", "onClick"];
//#endregion
//#region plugins/dsh-quick-note/StockNotesSection.vue
var StockNotesSection_default = /* @__PURE__ */ defineComponent({
	__name: "StockNotesSection",
	props: {
		symbol: {},
		repo: {},
		deps: {}
	},
	setup(__props) {
		const props = __props;
		/** 就地输入的草稿 */
		const draft = ref("");
		/** 关联了当前股票的速记（新的在前，响应式） */
		const notes = computed(() => props.repo.listBySymbol(props.symbol));
		/**
		* 解析当前股票的名称（落库用，速记面板的关联标签读它展示）
		*
		* 自选股里有就直接取（零请求）；不在自选里才向行情源取一次快照兜底 ——
		* 名称只在这一次保存时用得上，取不到就退回符号，绝不因为改名失败而丢笔记。
		* @returns 股票名称（兜底为完整符号）
		*/
		const resolveStockName = async () => {
			const fromWatchlist = props.deps.watchlist.nameOf(props.symbol);
			if (fromWatchlist) return fromWatchlist;
			try {
				const [quote] = await props.deps.quotes.fetchFullQuotes([props.symbol]);
				if (quote?.name) return quote.name;
			} catch {}
			return props.symbol;
		};
		/**
		* 保存草稿：自动关联当前股票
		*
		* 先清空草稿（手感即时），名称异步补齐 —— 用户不会感知到那一次查名请求。
		*/
		const onSave = async () => {
			const text = draft.value;
			if (!text.trim()) return;
			draft.value = "";
			const name = await resolveStockName();
			const stock = {
				symbol: props.symbol,
				name
			};
			props.repo.create(text, stock);
		};
		/**
		* 编辑区快捷键：Ctrl/Cmd + Enter 保存
		* @param event 键盘事件
		*/
		const onKeydown = (event) => {
			if ((event.ctrlKey || event.metaKey) && event.key === "Enter") {
				event.preventDefault();
				onSave();
			}
		};
		/**
		* 删除一条速记
		* @param id 速记 id
		*/
		const onRemove = (id) => {
			props.repo.remove(id);
		};
		/**
		* 相对时间（`3分钟前` / `昨天` / `9-18`）
		* @param timestamp 毫秒时间戳
		* @returns 相对时间文案
		*/
		const relativeTime = (timestamp) => props.deps.format.relativeTime(timestamp);
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", _hoisted_1, [createElementVNode("div", _hoisted_2, [withDirectives(createElementVNode("textarea", {
				"onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => draft.value = $event),
				maxlength: unref(QUICK_NOTE_MAX_LENGTH),
				rows: "2",
				placeholder: unref(QUICK_NOTE_SECTION_PLACEHOLDER),
				class: "w-full resize-y rounded-card border border-flat-weak bg-surface px-2.5 py-2 text-sm text-text placeholder:text-text-tertiary focus:border-primary focus:outline-none",
				onKeydown
			}, null, 40, _hoisted_3), [[vModelText, draft.value]]), (openBlock(), createBlock(resolveDynamicComponent(__props.deps.ui.Button), {
				variant: "primary",
				disabled: draft.value.trim().length === 0,
				onClick: onSave
			}, {
				default: withCtx(() => [createTextVNode(toDisplayString(unref(QUICK_NOTE_SECTION_SAVE)), 1)]),
				_: 1
			}, 8, ["disabled"]))]), notes.value.length === 0 ? (openBlock(), createBlock(resolveDynamicComponent(__props.deps.ui.Empty), {
				key: 0,
				text: unref(QUICK_NOTE_SECTION_EMPTY)
			}, null, 8, ["text"])) : (openBlock(), createElementBlock("ul", _hoisted_4, [(openBlock(true), createElementBlock(Fragment, null, renderList(notes.value, (note) => {
				return openBlock(), createElementBlock("li", {
					key: note.id,
					class: "group rounded-card border border-flat-weak px-3 py-2"
				}, [createElementVNode("p", _hoisted_5, toDisplayString(note.text), 1), createElementVNode("div", _hoisted_6, [createElementVNode("span", _hoisted_7, toDisplayString(relativeTime(note.createdAt)), 1), createElementVNode("button", {
					type: "button",
					class: "pressable rounded p-1 text-text-tertiary opacity-0 transition-opacity hover:bg-flat-weak hover:text-text group-hover:opacity-100 active:scale-90",
					"aria-label": unref(QUICK_NOTE_REMOVE_ARIA),
					onClick: ($event) => onRemove(note.id)
				}, [(openBlock(), createBlock(resolveDynamicComponent(__props.deps.ui.Icon), {
					name: "trash",
					size: 12
				}))], 8, _hoisted_8)])]);
			}), 128))]))]);
		};
	}
});
//#endregion
//#region plugins/dsh-quick-note/plugin.ts
/**
* 插件 dsh-quick-note · 速记
*
* 这个插件把插件体系里除「贡献点」之外的四件事一次性演示完整：
* - **通用数据层**：`ctx.db` 在本插件独立表 `plugin_dsh_quick_note_notes` 里存速记
*   （Tauri 端 SQLite / 浏览器端本地仿真），插件永不直接写 SQL；
* - **服务贡献**：`ctx.provide('note:repo', …)`，其他插件可 `consume` 复用；
* - **事件**：保存后广播 `note:saved`（插件之间不互相 import 也能协作）；
* - **命令 + 宿主服务**：快捷键经 `panel:open` 服务唤醒自己的面板。
*/
/** 该插件注册的面板 id */
var QUICK_NOTE_PANEL_ID = "notes";
/** 面板全局键（`<pluginId>#<panelId>`，命令经 `panel:open` 唤醒它） */
var QUICK_NOTE_PANEL_KEY = `dsh-quick-note#${QUICK_NOTE_PANEL_ID}`;
/**
* 速记插件定义
*/
var quickNotePlugin = {
	id: "dsh-quick-note",
	name: "速记",
	version: "1.1.0",
	description: "左侧栏底部新增「速记」入口（抽屉形态）：随手记一条，随写随存，可关联一只股票（宿主选股弹窗），关联后的速记展示在该股的个股详情里；对外提供 note:repo 服务与 note:saved 事件供其他插件复用。",
	author: "内置",
	apply: async (ctx) => {
		const ui = ctx.consume("app:ui");
		const format = ctx.consume("app:format");
		const stockOpen = ctx.consume("app:stock-open");
		const stockPicker = ctx.consume("app:stock-picker");
		const watchlist = ctx.consume("app:watchlist");
		const quotes = ctx.consume("app:quotes");
		const closePanel = ctx.consume("panel:close");
		if (!ui || !format || !stockOpen || !stockPicker || !watchlist || !quotes || !closePanel) throw new Error("宿主未提供 app:ui / app:format / app:stock-open / app:stock-picker / app:watchlist / app:quotes / panel:close 服务");
		const deps = {
			ui,
			format,
			stockOpen,
			stockPicker,
			watchlist,
			quotes,
			closePanel
		};
		const repo = await createQuickNoteRepo(ctx.db, ctx.storage, (note) => {
			ctx.emit("note:saved", note);
		});
		ctx.provide("note:repo", repo);
		ctx.sidebar.add({
			id: QUICK_NOTE_PANEL_ID,
			title: "速记",
			icon: "pencil",
			mode: "drawer",
			position: "footer",
			order: 10,
			component: QuickNotePanel_default,
			props: {
				repo,
				deps,
				panelKey: QUICK_NOTE_PANEL_KEY
			}
		});
		ctx.stockDetail.add({
			id: "stock-notes",
			title: "速记",
			component: StockNotesSection_default,
			props: {
				repo,
				deps
			}
		});
		ctx.command.add({
			id: "open",
			title: "打开速记",
			keys: "Ctrl+Alt+N",
			run: () => {
				ctx.consume("panel:open")?.(QUICK_NOTE_PANEL_KEY);
			}
		});
		ctx.logger.info("已注册抽屉面板、个股详情速记扩展区、note:repo 服务与 1 条命令");
	}
};
//#endregion
export { QUICK_NOTE_PANEL_ID, QUICK_NOTE_PANEL_KEY, quickNotePlugin as default, quickNotePlugin };
